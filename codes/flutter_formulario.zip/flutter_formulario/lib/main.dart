import 'package:flutter/material.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Formulario()
    );
  }
}


class Formulario extends StatefulWidget {
  const Formulario({super.key});

  @override
  State<Formulario> createState() => _FormularioState();
}

class _FormularioState extends State<Formulario> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  String boleta = "";
  String correo = "";

  void submit(){
    if(formKey.currentState!.validate()){
      formKey.currentState!.save();
      setState((){});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Formulario - Flutter"), backgroundColor: Colors.blue),
      body: Form(
        key: formKey,
        child: Padding(
          padding: EdgeInsets.all(16.0),
          child: Column(
            children: [
              TextFormField(
                decoration: InputDecoration(labelText: "Boleta"),
                validator: (value){
                  if(value!.isEmpty){
                    return "Falta tu número de boleta";
                  }return null;
                },
                onSaved: (value){
                  boleta = value!;
                }
              ),
              TextFormField(
                decoration: InputDecoration(labelText: "Correo"),
                validator: (value){
                  if(value!.isEmpty){
                    return "Falta tu correo electrónico";
                  }return null;
                },
                onSaved: (value){
                  correo = value!;
                }
              ),
              SizedBox(height: 20.0),
              ElevatedButton(
                onPressed: submit,
                child: Text("Entrar")
              ),
              SizedBox(height: 20.0),
              Text("Boleta: $boleta --- Correo: $correo")
            ]
          )
        )
      )
    );
  }
}