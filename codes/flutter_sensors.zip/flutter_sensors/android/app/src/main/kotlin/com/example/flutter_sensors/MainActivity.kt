package com.example.flutter_sensors

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
