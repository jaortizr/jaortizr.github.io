<?php
  $conexion = mysqli_connect("localhost","root","","sem20252");
  $sql = "SELECT * FROM alumno";
  $resultado = mysqli_query($conexion, $sql);
  
  $respAX = [];
  $respAX["code"] = 1;
  $respAX["log"] = date("Y-m-d H:i:s");
  $infAlumnos = [];
  while($fila = mysqli_fetch_assoc($resultado)){
    $infAlumnos[] = $fila;
  }
  $respAX["data"] = $infAlumnos;

  echo json_encode($respAX);
?>