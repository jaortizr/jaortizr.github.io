<?php
  session_start();
  date_default_timezone_set("America/Mexico_City");
  $respAX = [];
  // Conexión y consulta a BD (supuesto)
  $numFilasConsulta = 1;
  if($numFilasConsulta == 1){
    $respAX["code"] = 1;
    $respAX["icono"] = "success";
    $respAX["data"] = "Bienvenido al sistema :)";
    $_SESSION["boleta"] = "2025630001";
  }else{
    $respAX["code"] = 0;
    $respAX["icono"] = "error";
    $respAX["data"] = "Favor de revisar tus dato";
  }

  $respAX["log"] = date("Y-m-d H:i:s");
  echo json_encode($respAX);
?>