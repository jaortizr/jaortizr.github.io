# flutter_sqlflite

A new Flutter project.
