package com.example.flutter_sqlflite

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
