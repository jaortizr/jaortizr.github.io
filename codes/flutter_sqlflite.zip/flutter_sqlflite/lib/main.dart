import 'package:flutter/material.dart';
import 'package:flutter_sqlflite/sql_helper.dart';


void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "SQLITE - Flutter",
      theme: ThemeData(
        primarySwatch: Colors.purple,
      ),
      home: const HomePage()
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Map<String, dynamic>> _diario = [];
  bool _isLoading = true;
  
  void _refreshDiario() async {
    final data = await SQLHelper.obtenerItems();
    setState(() {
      _diario = data;
      _isLoading = false;
    });
  }

  @override
  void initState() {
    super.initState();
    _refreshDiario();
  }

  final TextEditingController _tituloController = TextEditingController();
  final TextEditingController _descripcionController = TextEditingController();

  void _showForm(int? id) async {
    if (id != null) { /* id == null -> create new item || id != null -> update an existing item */
      final hojaDiario = _diario.firstWhere((element) => element["id"] == id);
      _tituloController.text = hojaDiario["titulo"];
      _descripcionController.text = hojaDiario["descripcion"];
    }

    showModalBottomSheet(
        context: context,
        elevation: 5,
        isScrollControlled: true,
        builder: (_) => Container(
          padding: EdgeInsets.only(top: 15, left: 15, right: 15, bottom: MediaQuery.of(context).viewInsets.bottom + 120),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              TextField(
                controller: _tituloController,
                decoration: const InputDecoration(hintText: "Título"),
              ),
              const SizedBox(
                height: 10,
              ),
              TextField(
                controller: _descripcionController,
                decoration: const InputDecoration(hintText: "Descripción"),
              ),
              const SizedBox(
                height: 20,
              ),
              ElevatedButton(
                onPressed: () async {
                  if (id == null) {
                    await _addItem();
                  }

                  if (id != null) {
                    await _updateItem(id);
                  }

                  _tituloController.text = "";
                  _descripcionController.text = "";

                  Navigator.of(context).pop();
                },
                child: Text(id == null ? "Nuevo" : "Actualizar")
              )
            ],
          ),
        ));
  }

  Future<void> _addItem() async {
    await SQLHelper.crearItem(_tituloController.text, _descripcionController.text);
    _refreshDiario();
  }

  Future<void> _updateItem(int id) async {
    await SQLHelper.actualizarItem(
        id, _tituloController.text, _descripcionController.text);
    _refreshDiario();
  }

  void _deleteItem(int id) async {
    await SQLHelper.borrarItem(id);
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text("Se eliminó correctamente"),
    ));
    _refreshDiario();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("SQLITE - Flutter"),
        centerTitle: true,
        backgroundColor: Colors.purple
      ),
      body: _isLoading
          ? const Center(
        child: CircularProgressIndicator(),
      )
          : ListView.builder(
        itemCount: _diario.length,
        itemBuilder: (context, index) => Card(
          color: Colors.purple[50],
          margin: const EdgeInsets.all(15),
          child: ListTile(
              title: Text(_diario[index]["titulo"]),
              subtitle: Text(_diario[index]["descripcion"]),
              trailing: SizedBox(
                width: 100,
                child: Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.edit),
                      onPressed: () => _showForm(_diario[index]["id"]),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete),
                      onPressed: () =>
                          _deleteItem(_diario[index]["id"]),
                    ),
                  ],
                ),
              )),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () => _showForm(null),
      ),
    );
  }
}