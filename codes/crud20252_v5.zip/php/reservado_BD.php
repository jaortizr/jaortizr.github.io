<?php
  session_start();
  include("./configBD.php");

  $boleta = $_SESSION["boleta"];
  $respAX = [];
  $infAlumnos = [];

  $sqlGetAlumno = "SELECT * FROM alumno WHERE boleta = '$boleta'";
  $resGetAlumno = mysqli_query($conexion, $sqlGetAlumno);
  $infAlumno = mysqli_fetch_assoc($resGetAlumno);

  $sqlSelAlumnos = "SELECT * FROM alumno";
  $resSelAlumnos = mysqli_query($conexion, $sqlSelAlumnos);
  while($fila = mysqli_fetch_assoc($resSelAlumnos)){
    $infAlumnos[] = $fila;
  }

  $respAX["code"] = 1;
  $respAX["data"] = $infAlumnos;
  $respAX["alumno"] = $infAlumno;

  echo json_encode($respAX);

?>