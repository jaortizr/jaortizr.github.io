<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CRUD/UPDATE - TDAW - 20252</title>
  <link href="./../libs/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="./../libs/jquery-3.7.1.min.js"></script>
  <script src="./../libs/bootstrap/js/bootstrap.min.js"></script>
  <script src="./../libs/justValidate.min.js"></script>
  <script src="./../libs/sweetAlert2.min.js"></script>
  <script src="./../js/reservado_update.js"></script>
</head>
<body>
  <header>
    <div class="container">
      
    </div>
  </header>
  <main class="container d-flex align-items-center justify-content-center min-vh-100">
    <div>
      <h3>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Laborum, tempore.</h3>
      <form id="formUpdate" class="row">
        <div class="col-xs-12 col-md-6 mb-3">
          <div class="d-grid">
            <label for="correo">Correo</label>
            <input type="text" class="form-control" id="correo" name="correo">
          </div>
        </div>
        <div class="col-xs-12 mb-3 d-grid">
          <button type="submit" class="btn btn-primary mb-3">Actualizar</button>
        </div>
      </form>
      <div class="row text-center">
        <a href="./reservado.php">Regresar</a>
      </div>
    </div>
  </main>
  <footer>

  </footer>
</body>
</html>