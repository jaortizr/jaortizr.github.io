<?php
  $servidorBD = "localhost";
  $usuarioBD = "root";
  $contrasenaUsrBD = "";
  $nombreBD = "sem20252";

  $conexion = mysqli_connect($servidorBD, $usuarioBD, $contrasenaUsrBD, $nombreBD);

	if(mysqli_connect_errno()){
		die("Problemas con la conexión al servidor MySQL: ".mysqli_connect_error());
	}else{
		mysqli_query($conexion, "SET NAMES 'utf8'");
	}

?>