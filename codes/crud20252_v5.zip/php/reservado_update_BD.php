<?php
  include("./configBD.php");

  $respAX = [];
  $boleta = $_REQUEST["boleta"];
  $sqlGetAlumno = "SELECT * FROM alumno WHERE boleta = '$boleta'";
  $resGetAlumno = mysqli_query($conexion, $sqlGetAlumno);
  $infGetAlumno = mysqli_fetch_assoc($resGetAlumno);

  $respAX["code"] = 1;
  $respAX["icono"] = "success";
  $respAX["data"] = $infGetAlumno;
  
  echo json_encode($respAX); 
?>