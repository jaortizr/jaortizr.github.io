$(document).ready(()=>{
  $.ajax({
    url:"./reservado_BD.php",
    method:"post",
    cache:"false",
    success:(respAX)=>{
      let objAX_selAlumnos = JSON.parse(respAX);
      let alumnos = objAX_selAlumnos.data;
      let alumno = objAX_selAlumnos.alumno;
      let filasAlumnos = "";
      alumnos.forEach((elemento) => {
        filasAlumnos += `
          <tr>
            <td>${elemento.boleta}</td>
            <td>${elemento.nombre} ${elemento.apellidos}</td>
            <td>${elemento.fechaNacimiento}</td>
            <td>${elemento.correo}</td>
            <td>
              <i class="fas fa-eye fa-2x ver" data-boleta='${elemento.boleta}'></i>&nbsp;&nbsp;
              <i class="fas fa-pen fa-2x editar" data-boleta='${elemento.boleta}'></i>&nbsp;&nbsp;
              <i class="fas fa-file-pdf fa-2x pdf" data-boleta='${elemento.boleta}'></i>&nbsp;&nbsp;
              <i class="fas fa-trash fa-2x eliminar" data-boleta='${elemento.boleta}'></i>
            </td>
          </tr>
        `;
      });
      $("span#nombreUsr").text(alumno.nombre);
      $("tbody#respAXAlumnos").html(filasAlumnos);
    }
  });


  $("#tblAlumnos tbody").on("click", ".editar", function(){
    alert($(this).attr("data-boleta"));
    let boleta = $(this).attr("data-boleta");
    sessionStorage.setItem("boleta", boleta);
    window.location.href = "./reservado_update.php";
  });

  $("#tblAlumnos tbody").on("click", ".ver", function(){
    alert("Ver boleta: " + $(this).attr("data-boleta"));
    let boleta = $(this).attr("data-boleta");
    sessionStorage.setItem("boleta", boleta);
  });

  $("#tblAlumnos tbody").on("click", ".pdf", function(){
    alert("PDF de la boleta: " + $(this).attr("data-boleta"));
    let boleta = $(this).attr("data-boleta");
    sessionStorage.setItem("boleta", boleta);
  });

  $("#tblAlumnos tbody").on("click", ".eliminar", function(){
    alert("Eliminar la boleta: " + $(this).attr("data-boleta"));
    let boleta = $(this).attr("data-boleta");
    sessionStorage.setItem("boleta", boleta);
  });

});