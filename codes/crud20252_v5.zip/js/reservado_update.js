$(document).ready(()=>{
  let boleta = sessionStorage.getItem("boleta");
  $.ajax({
    url:"reservado_update_BD.php",
    method:"post",
    data:{boleta:boleta},
    cache:false,
    success:(respAX)=>{
      console.log(respAX);
      let objAXAlumno = JSON.parse(respAX);
      $("#correo").val(objAXAlumno.data.correo);
    }
  });

  $("#formUpdate").on("submit", (e)=>{
    e.preventDefault();
    console.log("SUBMITTTT");
  });
});