import 'package:flutter/material.dart';
import 'package:sqlite_flutter_escom/models/model_alumno.dart';
import 'package:sqlite_flutter_escom/services/alumno_service.dart';

class AddAlumno extends StatefulWidget {
  const AddAlumno({super.key});

  @override
  State<AddAlumno> createState() => _AddAlumnoState();
}

class _AddAlumnoState extends State<AddAlumno> {
  final AlumnoService _alumnoService = AlumnoService();
  late Alumno _alumno;
  var resultado;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          TextButton(
            onPressed: () async {
              _alumno = Alumno.fromMap({"boleta":"2024630002", "nombre":"Diana", "apellidos":"Cazadora Cazadora", "email":"diana@diana.com"});
              //resultado =  await _alumnoService.saveAlumnos(_alumno);
              resultado =  await _alumnoService.readAllAlumnos();
              setState(() {});
            },
            child: const Text("Operación X")
          ),
          Text(resultado.toString())
        ],
      ),
    );
  }
}