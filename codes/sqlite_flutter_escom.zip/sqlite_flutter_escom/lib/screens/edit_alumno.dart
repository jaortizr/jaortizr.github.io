import 'package:art_sweetalert/art_sweetalert.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:form_builder_validators/form_builder_validators.dart';
import 'package:sqlite_flutter_escom/models/model_alumno.dart';
import 'package:sqlite_flutter_escom/screens/view_alumno.dart';
import 'package:sqlite_flutter_escom/services/alumno_service.dart';

class EditAlumno extends StatefulWidget {
  final Alumno alumno;
  const EditAlumno({super.key, required this.alumno});

  @override
  State<EditAlumno> createState() => _EditAlumnoState();
}

class _EditAlumnoState extends State<EditAlumno> {
  final _formKey = GlobalKey<FormBuilderState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Flutter & SQLITE"),
        centerTitle: true,
        actions: [
          IconButton(
            onPressed: (){
              Navigator.push(context,
                MaterialPageRoute(builder: (context) => const ViewAlumno())
              );
            },
            icon: const Icon(Icons.home)
          )
        ]
      ),
      body: Column(
        children: [
          const Text("Actualizar alumno", style: TextStyle(fontSize: 25, fontWeight: FontWeight.w500)),
          const SizedBox(height: 20),
          FormBuilder(key: _formKey,
            initialValue: {"boleta":widget.alumno.boleta, "nombre":widget.alumno.nombre, "apellidos":widget.alumno.apellidos, "email":widget.alumno.email},
            child: Column(
              children: [
                FormBuilderTextField(name: "boleta",
                  decoration: const InputDecoration(labelText: "Boleta"),
                  readOnly: true,
                ),
                const SizedBox(height: 20),
                FormBuilderTextField(name: "nombre",
                  decoration: const InputDecoration(labelText: "Nombre(s)"),
                  validator: FormBuilderValidators.compose([
                    FormBuilderValidators.required(errorText: "Falta el nombre"),
                  ])
                ),
                const SizedBox(height: 20),
                FormBuilderTextField(name: "apellidos",
                  decoration: const InputDecoration(labelText: "Apellidos"),
                  validator: FormBuilderValidators.compose([
                    FormBuilderValidators.required(errorText: "Falta el nombre"),
                  ])
                ),
                const SizedBox(height: 20),
                FormBuilderTextField(name: "email",
                  decoration: const InputDecoration(labelText: "Correo electrónico"),
                  validator: FormBuilderValidators.compose([
                    FormBuilderValidators.required(errorText: "Falta el correo electrónico"),
                    FormBuilderValidators.email(errorText: "Formato incorrecto")
                  ]),
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed:() async {

                    if (_formKey.currentState!.saveAndValidate()) {
                          Alumno alumno = Alumno.fromMap(_formKey.currentState!.value);
                          AlumnoService alumnoService = AlumnoService();
                          var resultado = await alumnoService.updateAlumnos(alumno);
                          if(resultado == 1){
                            _formKey.currentState!.reset();
                            ArtSweetAlert.show(
                              context: context,
                              artDialogArgs: ArtDialogArgs(
                                type: ArtSweetAlertType.success,
                                title: "DAMN - 20251",
                                text: "Los datos se actualizaron correctamente"
                              )
                            );
                          }else{

                            ArtSweetAlert.show(
                              context: context,
                              artDialogArgs: ArtDialogArgs(
                                type: ArtSweetAlertType.danger,
                                title: "DAMN - 20251",
                                text: "Favor de intentarlo nuevamente"
                              )
                            );

                          }
                        }

                  },
                  child: const Text("Editar")
                )
              ],
            )
          ),
        ],
      )
    );
  }
}

