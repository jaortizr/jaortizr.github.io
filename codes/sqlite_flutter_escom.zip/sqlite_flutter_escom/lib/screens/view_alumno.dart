import 'package:art_sweetalert/art_sweetalert.dart';
import 'package:flutter/material.dart';
import 'package:sqlite_flutter_escom/models/model_alumno.dart';
import 'package:sqlite_flutter_escom/screens/add_alumno.dart';
import 'package:sqlite_flutter_escom/screens/edit_alumno.dart';
import 'package:sqlite_flutter_escom/services/alumno_service.dart';

class ViewAlumno extends StatefulWidget {
  const ViewAlumno({super.key});

  @override
  State<ViewAlumno> createState() => _ViewAlumnoState();
}

class _ViewAlumnoState extends State<ViewAlumno> {
  AlumnoService alumnoService = AlumnoService();

  Future<List> fetchAlumnos() async{
    return await alumnoService.readAllAlumnos();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Flutter & SQLITE"),
        centerTitle: true,
        actions: [
          IconButton(
            onPressed: (){
              Navigator.push(context,
                MaterialPageRoute(builder: (context) => const AddAlumno())
              );
            },
            icon: const Icon(Icons.person_add_rounded)
          )
        ],
      ),
      body: FutureBuilder(
        future: fetchAlumnos(),
        builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot){
          if(snapshot.hasError){
            return const Text("Error");
          }else if(snapshot.hasData){
            return ListView.builder(
              itemCount: snapshot.data.length,
              itemBuilder: (BuildContext context, int index) {
                Alumno alumno = Alumno.fromMap(snapshot.data[index]);
                return ListTile(
                  leading: CircleAvatar(child: Text(alumno.nombre.substring(0,1))),
                  title: Text("${alumno.nombre} ${alumno.apellidos}"),
                  subtitle: Text(alumno.email),
                  trailing: const Icon(Icons.alt_route),
                  onTap: () async {

                    ArtDialogResponse respUsr = await ArtSweetAlert.show(
                      barrierDismissible: false,
                      context: context,
                      artDialogArgs: ArtDialogArgs(
                        type: ArtSweetAlertType.question,
                        title: "DAMN - 20251",
                        text: "¿Qué desea hacer con la boleta ${alumno.boleta}?",
                        confirmButtonText: "Eliminar",
                        denyButtonText: "Editar",
                        showCancelBtn: true
                      )
                    );

                    if(respUsr.isTapConfirmButton){
                      alumnoService.deleteAlumnos(alumno.boleta);
                      setState((){});
                    }

                    if(respUsr.isTapDenyButton){
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => EditAlumno(alumno: alumno))
                      );
                    }

                  },
                );
              },
            );
          }
          return const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircularProgressIndicator(),
              ]
            )
          );
        }
      )
    );
  }
}