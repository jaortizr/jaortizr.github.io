import 'package:art_sweetalert/art_sweetalert.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:form_builder_validators/form_builder_validators.dart';
import 'package:sqlite_flutter_escom/models/model_alumno.dart';
import 'package:sqlite_flutter_escom/screens/view_alumno.dart';
import 'package:sqlite_flutter_escom/services/alumno_service.dart';

class AddAlumno extends StatefulWidget {
  const AddAlumno({super.key});

  @override
  State<AddAlumno> createState() => _AddAlumnoState();
}

class _AddAlumnoState extends State<AddAlumno> {
  final _formKey = GlobalKey<FormBuilderState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Flutter & SQLITE"),
        centerTitle: true,
        actions: [
          IconButton(
            onPressed: (){
              Navigator.push(context,
                MaterialPageRoute(builder: (context) => const ViewAlumno())
              );
            },
            icon: const Icon(Icons.home)
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Center(
          child: Column(
            children: [
              const Text("Nuevo Alumno", style: TextStyle(fontSize: 25, fontWeight: FontWeight.w500)),
              const SizedBox(height: 20),
              FormBuilder(key: _formKey,
                child: Column(
                  children: [
                    FormBuilderTextField(name: "boleta",
                      decoration: const InputDecoration(labelText: "Número de boleta"),
                      validator: FormBuilderValidators.compose([
                        FormBuilderValidators.required(errorText: "Falta el número de boleta"),
                        FormBuilderValidators.integer(errorText: "Deben ser solo digitos"),
                        FormBuilderValidators.minLength(8, errorText: "Deben ser al menos 8 digitos"),
                        FormBuilderValidators.maxLength(10, errorText: "Deben ser máximo 10 digitos")
                      ]),
                    ),
                    const SizedBox(height: 20),
                    FormBuilderTextField(name: "nombre",
                      decoration: const InputDecoration(labelText: "Nombre(s)"),
                      validator: FormBuilderValidators.compose([
                        FormBuilderValidators.required(errorText: "Falta el nombre"),
                      ]),
                    ),
                    const SizedBox(height: 20),
                    FormBuilderTextField(name: "apellidos",
                      decoration: const InputDecoration(labelText: "Apellidos"),
                      validator: FormBuilderValidators.compose([
                        FormBuilderValidators.required(errorText: "Faltan los apellidos"),
                      ]),
                    ),
                    const SizedBox(height: 20),
                    FormBuilderTextField(name: "email",
                      decoration: const InputDecoration(labelText: "Correo electrónico"),
                      validator: FormBuilderValidators.compose([
                        FormBuilderValidators.required(errorText: "Falta el correo electrónico"),
                        FormBuilderValidators.email(errorText: "Formato incorrecto")
                      ]),
                    ),
                    const SizedBox(height: 20),
                    ElevatedButton(
                      onPressed: () async{
                        if (_formKey.currentState!.saveAndValidate()) {
                          Alumno alumno = Alumno.fromMap(_formKey.currentState!.value);
                          AlumnoService alumnoService = AlumnoService();
                          var resultado = await alumnoService.saveAlumnos(alumno);
                          if(resultado > 0){
                            _formKey.currentState!.reset();
                            ArtSweetAlert.show(
                              context: context,
                              artDialogArgs: ArtDialogArgs(
                                type: ArtSweetAlertType.success,
                                title: "DAMN - 20251",
                                text: "Los datos se guardaron correctamente"
                              )
                            );

                          }else{

                            ArtSweetAlert.show(
                              context: context,
                              artDialogArgs: ArtDialogArgs(
                                type: ArtSweetAlertType.danger,
                                title: "DAMN - 20251",
                                text: "Favor de intentarlo nuevamente"
                              )
                            );

                          }
                        }
                      },
                      child: const Text("Agregar Alumno")
                    )
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}