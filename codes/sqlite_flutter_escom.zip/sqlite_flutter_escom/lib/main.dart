import 'package:flutter/material.dart';
import 'package:sqlite_flutter_escom/screens/add_alumno.dart';
import 'package:sqlite_flutter_escom/screens/view_alumno.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "SQFLITE",
      home: ViewAlumno()
    );
  }
}