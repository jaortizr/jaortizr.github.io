import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseConnection{
	Future<Database> setDatabase() async {
		var directory = await getApplicationDocumentsDirectory();
		var path = join(directory.path, 'dbAlumnos.db');
		var database = await openDatabase(path, version: 1, onCreate: _createDatabase);
		return database;
	}
	Future<void>_createDatabase(Database database, int version) async {
		String sql= """
      CREATE TABLE alumno(
        boleta TEXT PRIMARY KEY,
        nombre TEXT,
        apellidos TEXT,
        email TEXT
      );
    """;
		await database.execute(sql);
  }
}