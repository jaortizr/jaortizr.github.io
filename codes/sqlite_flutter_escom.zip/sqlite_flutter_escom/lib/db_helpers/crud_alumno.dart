import 'package:sqflite/sqflite.dart';
import 'package:sqlite_flutter_escom/db_helpers/db_connection.dart';

class CrudAlumno{
  late DatabaseConnection _databaseConnection;
  static Database? _database;

  CrudAlumno(){
    _databaseConnection = DatabaseConnection();
  }

  Future<Database?> get database async{
    if(_database != null){
      return _database;
    }else{
      _database = await _databaseConnection.setDatabase();
      return _database;
    }
  }

  insertData(table, data) async{
    var connection = await database;
    return connection?.insert(table, data);
  }

  readData(table) async{
    var connection = await database;
    return await connection?.query(table);
  }

  readDataById(table, itemId) async{
    var connection = await database;
    return await connection?.query(table, where: "boleta = ?", whereArgs: [itemId]);
  }

  updateData(table, data) async{
    var connection = await database;
    return await connection?.update(table, data, where: "boleta = ?", whereArgs: [data["boleta"]]);
  }

  deleteDataById(table, itemId) async{
    var connection = await database;
    return await connection?.rawDelete("DELETE FROM $table WHERE boleta = $itemId");
  }

}