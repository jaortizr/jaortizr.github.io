class Alumno {
  final String boleta;
  final String nombre;
  final String apellidos;
  final String email;

  Alumno({
    required this.boleta,
    required this.nombre,
    required this.apellidos,
    required this.email,
  });

  factory Alumno.fromMap(Map<String, dynamic> json) => Alumno(
    boleta: json["boleta"],
    nombre: json["nombre"],
    apellidos: json["apellidos"],
    email: json["email"],
  );

  Map<String, dynamic> toMap() => {
    "boleta": boleta,
    "nombre": nombre,
    "apellidos": apellidos,
    "email": email,
  };
}