import 'package:sqlite_flutter_escom/db_helpers/crud_alumno.dart';
import 'package:sqlite_flutter_escom/models/model_alumno.dart';

class AlumnoService{
  late CrudAlumno _crudAlumno;

  AlumnoService(){
    _crudAlumno = CrudAlumno();
  }

  saveAlumnos(Alumno alumno) async{
    return await _crudAlumno.insertData("alumno", alumno.toMap());
  }

  readAllAlumnos() async{
    return await _crudAlumno.readData("alumno");
  }

  updateAlumnos(Alumno alumno) async{
    return await _crudAlumno.updateData("alumno", alumno.toMap());
  }

  deleteAlumnos(boleta) async{
    return await _crudAlumno.deleteDataById("alumno", boleta);
  }

}