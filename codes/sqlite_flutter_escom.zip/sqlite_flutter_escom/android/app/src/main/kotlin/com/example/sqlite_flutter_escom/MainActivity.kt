package com.example.sqlite_flutter_escom

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
