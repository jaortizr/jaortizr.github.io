import 'package:flutter/material.dart';

class IIA extends StatelessWidget {
  const IIA({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("IIA"),
      ),
      body: Center(
        child: Column(
          children: [
            Text("Pantalla de IIA"),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                foregroundColor: Colors.white
              ),
              onPressed: (){
                Navigator.pop(context);
              }, 
              child: Text("Regresar")
            )
          ],
        ),
      ),
    );
  }
}