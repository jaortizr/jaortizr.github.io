import 'package:flutter/material.dart';

class ISC extends StatelessWidget {
  const ISC({super.key});

  @override
  Widget build(BuildContext context) {
    final tituloPantalla = ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;

    return Scaffold(
      appBar: AppBar(
        title: Text(tituloPantalla["titulo"]),
      ),
      body: Center(
        child: Column(
          children: [
            Text("Pantalla de ISC"),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                foregroundColor: Colors.white
              ),
              onPressed: (){
                Navigator.pop(context);
              }, 
              child: Text("Regresar")
            )
          ],
        ),
      ),
    );
  }
}