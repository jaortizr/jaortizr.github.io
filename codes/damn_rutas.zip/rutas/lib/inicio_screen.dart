import 'package:flutter/material.dart';

class Inicio extends StatelessWidget {
  const Inicio({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Inicio"),
      ),
      body: Center(
        child: Column(
          children: [
            Text("Pantalla de Incio"),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                foregroundColor: Colors.white
              ),
              onPressed: (){
                Navigator.pushNamed(context, "/ISC",
                  arguments: {"titulo":"Ing. en Sistemas"}
                );
              }, 
              child: Text("ir a ISC")
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue.shade300,
                foregroundColor: Colors.white
              ),
              onPressed: (){
                Navigator.pushNamed(context, "/IIA");
              }, 
              child: Text("ir a IIA")
            )
          ],
        ),
      ),
    );
  }
}