import 'package:flutter/material.dart';
import 'package:rutas/iia_screen.dart';
import 'package:rutas/inicio_screen.dart';
import 'package:rutas/isc_screen.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Rutas",
      debugShowCheckedModeBanner: false,
      initialRoute: "/",
      routes: {
        "/" : (context) => const Inicio(),
        "/ISC" : (context) => const ISC(),
        "/IIA" : (context) => const IIA()
      },
    );
  }
}
