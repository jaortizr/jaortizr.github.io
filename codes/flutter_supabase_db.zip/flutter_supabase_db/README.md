# flutter_supabase_db

A new Flutter project.
