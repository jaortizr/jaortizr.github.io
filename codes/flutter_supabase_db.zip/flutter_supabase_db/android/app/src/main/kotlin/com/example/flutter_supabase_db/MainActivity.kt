package com.example.flutter_supabase_db

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
