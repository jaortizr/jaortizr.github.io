import 'package:flutter/material.dart';
import 'package:flutter_supabase_db/materia.dart';
import 'package:flutter_supabase_db/materia_database.dart';

class MateriaPage extends StatefulWidget {
  const MateriaPage({super.key});

  @override
  State<MateriaPage> createState() => _MateriaPageState();
}

class _MateriaPageState extends State<MateriaPage> {
  // materia table
  final materiaDatabase = MateriaDatabase();

  //text controller
  var materiaController = TextEditingController();

  //add new materia
  void addNvaMateria(){
    showDialog(
      context: context, 
      builder: (context) => AlertDialog(
        title: const Text("Nueva Materia"),
        content: TextField(
          controller: materiaController,
        ),
        actions: [
          TextButton(
            onPressed: (){
              Navigator.pop(context);
              materiaController.clear();
            },
            child: Text("Cancelar")
          ),
          TextButton(
            onPressed: (){
              final nvaMateria = Materia(nombre: materiaController.text);
              materiaDatabase.crearMateria(nvaMateria);
              Navigator.pop(context);
              materiaController.clear();
            },
            child: Text("Guardar")
          ),
        ],
      )
    );
  }

  //update materia
  void updateMateria(Materia materia){
    materiaController.text = materia.nombre;

    showDialog(
      context: context, 
      builder: (context) => AlertDialog(
        title: const Text("Actualizar Materia"),
        content: TextField(
          controller: materiaController,
        ),
        actions: [
          TextButton(
            onPressed: (){
              Navigator.pop(context);
              materiaController.clear();
            },
            child: Text("Cancelar")
          ),
          TextButton(
            onPressed: (){
              materiaDatabase.updateMateria(materia, materiaController.text);
              Navigator.pop(context);
              materiaController.clear();
            },
            child: Text("Actualizar")
          ),
        ],
      )
    );
  }

  //delete materia
  void borrarMateria(Materia materia){
    showDialog(
      context: context, 
      builder: (context) => AlertDialog(
        title: const Text("Borrar Materia?"),
        actions: [
          TextButton(
            onPressed: (){
              Navigator.pop(context);
              materiaController.clear();
            },
            child: Text("Cancelar")
          ),
          TextButton(
            onPressed: (){
              materiaDatabase.deleteMateria(materia);
              Navigator.pop(context);
              materiaController.clear();
            },
            child: Text("Borrar")
          ),
        ],
      )
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Materias")),
      floatingActionButton: FloatingActionButton(
        onPressed: addNvaMateria,
        child: const Icon(Icons.add)
      ),
      body: StreamBuilder(
        stream: materiaDatabase.stream, 
        builder: (context, snapshot){
          if(!snapshot.hasData){
            return const Center(child: CircularProgressIndicator());
          }

          final materias = snapshot.data!.toList();

          return ListView.builder(
            itemCount: materias.length,
            itemBuilder: (context, index){
              final materia = materias[index];
              return ListTile(
                title: Text(materia.nombre),
                trailing: SizedBox(
                  width: 100,
                  child: Row(
                    children: [
                      IconButton(
                        onPressed: () => updateMateria(materia),
                        icon: Icon(Icons.edit)
                      ),
                      IconButton(
                        onPressed:() => borrarMateria(materia),
                        icon: Icon(Icons.delete)
                      )
                    ],
                  ),
                ),
              );
            },

          );
          
        }
      ),
    );
  }
}