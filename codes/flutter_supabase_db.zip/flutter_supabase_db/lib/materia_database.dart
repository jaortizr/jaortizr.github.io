import 'package:flutter_supabase_db/materia.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class MateriaDatabase {
  //Get DB -> materia
  final tblMateria = Supabase.instance.client.from("materia");

  //create
  Future crearMateria(Materia nvaMateria) async{
    await tblMateria.insert(nvaMateria.toMap());
  }

  //read
  final stream = Supabase.instance.client.from("materia").stream(primaryKey: ["id"]).map((materias) => materias.map((materia) => Materia.fromMap(materia)));

  //update
  Future updateMateria(Materia oldMateria, String newMateria) async{
    await tblMateria.update({"nombre":newMateria}).eq("id", oldMateria.id!);
  }

  //delete
  Future deleteMateria(Materia materia) async{
    await tblMateria.delete().eq("id", materia.id!);
  }
}