class Materia{
  int? id;
  late String nombre;

  Materia({
    this.id, required this.nombre
  });

  //map -> materia
  factory Materia.fromMap(Map<String, dynamic> map){
    return Materia(
      id:map["id"] as int,
      nombre: map["nombre"] as String
    );
  }

  //materia -> note
  Map<String, dynamic> toMap(){
    return{
      "nombre": nombre
    };
  }
}