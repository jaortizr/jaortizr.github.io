package com.example.flutter_splash_screen

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
