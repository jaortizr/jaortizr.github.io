# flutter_splash_screen

A new Flutter project.
