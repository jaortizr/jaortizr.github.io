import 'dart:convert';

void main(){
  final jsonRestaurant = '{ "name": "Pizza da Mario", "cuisine": "Italian" }';

  final mapRestaurant = jsonDecode(jsonRestaurant);
  
  final classRestaurant = Restaurant.fromJSON(mapRestaurant);

  print(classRestaurant.name);
  print(classRestaurant.cuisine);
}

// Class for parsing JSON to a Dart Model Class //
class Restaurant {
  final String name;
  final String cuisine;

  Restaurant({
    required this.name,
    required this.cuisine
  });

  factory Restaurant.fromJSON(Map<String, dynamic> json){
    final name = json["name"] as String;
    final cuisine = json["cuisine"] as String;
    return Restaurant(name: name, cuisine: cuisine);
  }
}

