import 'dart:convert';

void main(){
  final jsonRestaurant = '''
    {
      "name": "Pizza da Mario",
      "cuisine": "Italian",
      "reviews": [
        {
          "score": 4.5,
          "review": "The pizza was amazing!"
        },
        {
          "score": 5.0,
          "review": "Very friendly staff, excellent service!"
        }
      ]
    }
  ''';
  final mapRestaurant = jsonDecode(jsonRestaurant);
  
  final classRestaurant = ClassRestaurant.fromJson(mapRestaurant);

  print(classRestaurant.name);
  print(classRestaurant.cuisine);
  print(classRestaurant.reviews[0].score);  
  print(classRestaurant.reviews[0].review);  
}

// Class for parsing JSON to a Dart Model Class //
class ClassRestaurant {
    final String name;
    final String cuisine;
    final List<Review> reviews;

    ClassRestaurant({
        required this.name,
        required this.cuisine,
        required this.reviews,
    });

    factory ClassRestaurant.fromJson(Map<String, dynamic> json) => ClassRestaurant(
        name: json["name"] as String,
        cuisine: json["cuisine"] as String,
        reviews: List<Review>.from(json["reviews"].map((x) => Review.fromJson(x))), //List<T>.from(),  constructor nombrado
    );

    Map<String, dynamic> toJson() => {
        "name": name,
        "cuisine": cuisine,
        "reviews": List<dynamic>.from(reviews.map((x) => x.toJson())),
    };
}

class Review {
    final double score;
    final String review;

    Review({
        required this.score,
        required this.review,
    });

    factory Review.fromJson(Map<String, dynamic> json) => Review(
        score: json["score"]?.toDouble(),
        review: json["review"] as String,
    );

    Map<String, dynamic> toJson() => {
        "score": score,
        "review": review,
    };
}