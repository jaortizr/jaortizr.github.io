import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AvisosPage extends StatefulWidget {
  const AvisosPage({super.key});

  @override
  State<AvisosPage> createState() => _AvisosPageState();
}

class _AvisosPageState extends State<AvisosPage> {
  final supabase = Supabase.instance.client;
  List<Map<String, dynamic>> _avisos = [];

  @override
  void initState() {
    super.initState();
    _cargarAvisos();

    // Suscripción en tiempo real a la tabla "avisos"
    supabase
        .from('avisos')
        .stream(primaryKey: ['id'])
        .listen((data) {
      setState(() {
        _avisos = List<Map<String, dynamic>>.from(data);
      });
    });
  }

  Future<void> _cargarAvisos() async {
    final response = await supabase.from('avisos').select().order('id');
    setState(() {
      _avisos = List<Map<String, dynamic>>.from(response);
    });
  }

  Future<void> _agregarAviso() async {
    await supabase.from('avisos').insert({
      'mensaje': 'Nuevo aviso en ${DateTime.now()}',
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Avisos en tiempo real')),
      body: Column(
        children: [
          ElevatedButton(
            onPressed: _agregarAviso,
            child: const Text('Agregar Aviso'),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _avisos.length,
              itemBuilder: (context, index) {
                final aviso = _avisos[index];
                return ListTile(
                  title: Text(aviso['mensaje']),
                  subtitle: Text('ID: ${aviso['id']}'),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}