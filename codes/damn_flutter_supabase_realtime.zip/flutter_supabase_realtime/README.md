# flutter_supabase_realtime

A new Flutter project.
