package com.example.flutter_geoloc_maps

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
