import 'dart:io';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class PerfilPage extends StatefulWidget {
  const PerfilPage({super.key});

  @override
  State<PerfilPage> createState() => _PerfilPageState();
}

class _PerfilPageState extends State<PerfilPage> {
  File? imageFile;
  bool isUploading = false;

  Future<void> pickImage() async{
    try{
      if(Platform.isAndroid){
        await requestPermission();
      }

      final ImagePicker picker = ImagePicker();
      final XFile? image = await picker.pickImage(source: ImageSource.camera);
      if(image != null){
        setState(() {
          imageFile = File(image.path);
        });
      }
    }catch(e){
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error al seleccionar la imagen: $e"))
      );
    }
  }

  Future<void> uploadImage() async {
    if (imageFile == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Por favor selecciona una imagen"))
      );
      return;
    }

    setState(() {
      isUploading = true;
    });

    try {
      final fileName = DateTime.now().millisecondsSinceEpoch.toString();
      final path = "sem20252/$fileName";

      await Supabase.instance.client.storage
          .from("intro.supabase")
          .upload(path, imageFile!);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("OK. Se actualizó tu imagen de perfil: $path"))
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error al subir la imagen:: ${e.toString()}"))
      );
    } finally {
      setState(() {
        isUploading = false;
      });
    }
  }

  Future<void> requestPermission() async {
    if (Platform.isAndroid) {
      if (await Permission.photos.isDenied ||
          await Permission.photos.isPermanentlyDenied) {
        await Permission.photos.request();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Perfil de usuario")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 50,
              backgroundImage: imageFile != null ? FileImage(imageFile!) : null,
              child: imageFile == null
                  ? const Icon(Icons.person, size: 50)
                  : null,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: pickImage,
              child: const Text("Seleccionar imagen"),
            ),
            ElevatedButton(
              onPressed: isUploading ? null : uploadImage,
              child: isUploading
                  ? const CircularProgressIndicator()
                  : const Text("Actualizar perfil"),
            ),
          ],
        ),
      )
    );
  }
}