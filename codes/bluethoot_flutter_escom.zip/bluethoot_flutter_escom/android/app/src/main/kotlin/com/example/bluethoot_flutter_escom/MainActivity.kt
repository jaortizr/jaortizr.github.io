package com.example.bluethoot_flutter_escom

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
