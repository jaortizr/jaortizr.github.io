import 'package:dio/dio.dart';

Future<void> main() async {
  GetHTTP solicitud = GetHTTP(url:"https://jsonplaceholder.typicode.com/posts/3");
  Post post = await solicitud.getJson();
  print(post.body);
  print("Holaaaaa");
}

class GetHTTP{
  final String url;
  GetHTTP({required this.url});

  Future<Post> getJson() async {
    final dio = Dio();
    final response = await dio.get(url);
    return Post.fromJson(response.data);
  }
}

class Post{
  final int userId;
  final int id;
  final String title;
  final String body;

  Post({required this.userId, required this.id, required this.title, required this.body});

  factory Post.fromJson(Map<String, dynamic> json){
    final userId = json["userId"] as int;
    final id = json["id"] as int;
    final title = json["title"] as String;
    final body = json["body"] as String;

    return Post(userId: userId, id: id, title: title, body: body);
  }
}