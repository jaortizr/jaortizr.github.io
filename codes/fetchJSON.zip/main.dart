import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  late Future<List<dynamic>> futureUsers;

  @override
  void initState() {
    super.initState();
    futureUsers = fetchData(url: "https://reqres.in/api/users");
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Fetch JSON',
      home: Scaffold(
        appBar: AppBar(
          title: const Text("Fetch JSON"),
          centerTitle: true,
        ),
        body:FutureBuilder(
          future: futureUsers,
          builder: (BuildContext context, AsyncSnapshot snapshot){
            if(snapshot.hasError){
              return const Text("Error...");
            }else if(snapshot.hasData){
              return ListView.builder(
                itemCount: snapshot.data.length,
                itemBuilder: (BuildContext context, int index){
                  String nombre = snapshot.data[index].firstName + " " + snapshot.data[index].lastName;
                  String correo = snapshot.data[index].email;
                  return ListTile(
                    leading: Image.network(snapshot.data[index].avatar),
                    title: Text(nombre),
                    titleTextStyle: const TextStyle(color: Colors.blue, fontWeight: FontWeight.w800),
                    subtitle: Text(correo),
                    trailing: const Icon(Icons.check),
                    contentPadding: const EdgeInsetsDirectional.all(7.5),
                  );
                }
              );
            }else{
              return const Center(
                child: CircularProgressIndicator()
              );
            }
          } 
        )
      ),
    );
  }
}


Future<List<dynamic>> fetchData({required String url}) async{
  final dio = await Dio().get(url);
  return dio.data["data"].map((item)=>User.fromJson(item)).toList();
}


class User {
    final int id;
    final String email;
    final String firstName;
    final String lastName;
    final String avatar;

    User({
        required this.id,
        required this.email,
        required this.firstName,
        required this.lastName,
        required this.avatar,
    });

    factory User.fromJson(Map<String, dynamic> json) => User(
        id: json["id"],
        email: json["email"],
        firstName: json["first_name"],
        lastName: json["last_name"],
        avatar: json["avatar"],
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "email": email,
        "first_name": firstName,
        "last_name": lastName,
        "avatar": avatar,
    };
}

/* ******** Versión con GridView ******** */

// GridView.builder(
//                 gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
//                   crossAxisCount: 2,
//                   mainAxisSpacing: 6.0,
//                   crossAxisSpacing: 6.0
//                 ),
//                 itemCount: snapshot.data.length,
//                 itemBuilder: (BuildContext context, int index){
//                   String nombre = snapshot.data[index].firstName + " " + snapshot.data[index].lastName;
//                   String correo = snapshot.data[index].email;
//                   return Card(
//                     shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
//                     child: Column(
//                       children: [
//                         Image(image: NetworkImage(snapshot.data[index].avatar)),
//                         Text(nombre, style: const TextStyle(fontWeight:FontWeight.w700, color: Colors.blue)),
//                         Text(correo)
//                       ],
//                     )
//                   );
//                 });

/* ******** /Versión con GridView ******** */