package com.example.flutter_barcodes

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
