# flutter_barcodes

A new Flutter project.
