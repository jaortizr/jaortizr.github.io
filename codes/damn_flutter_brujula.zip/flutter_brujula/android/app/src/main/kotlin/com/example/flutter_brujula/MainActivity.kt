package com.example.flutter_brujula

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
