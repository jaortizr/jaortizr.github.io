<?php
  include("./configBD.php");

  $sql_SelEstudiante = "SELECT * FROM estudiante";
  $statement = $conexion -> prepare($sql_SelEstudiante);
  if($statement === false){
    die("Error al preparar la declaración: " . $conexion -> error);
  }
  $statement -> execute();  
  $resultado = $statement -> get_result();
  echo "Número de filas: " . $resultado -> num_rows;
  echo "<br>";

  $allRows = $resultado -> fetch_all(MYSQLI_ASSOC);
  foreach($allRows as $estudiante){
    echo "Nombre: " . $estudiante["nombre"] . " " . $estudiante["primerApe"] . " " .$estudiante["segundoApe"] ."<br>";
  }

  echo "<br>";
  $formJson = json_encode($allRows);
  echo $formJson;

  echo "<br><br>";
  $respJson = [];
  $respJson["cod"] = 1;
  $respJson["msj"] = "Respuesta a la solicitud";
  $respJson["data"] = $allRows;
  echo json_encode($respJson);

   $statement -> close();
   $conexion -> close();
?>