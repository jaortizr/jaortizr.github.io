<?php
  include("./configBD.php");

  $sql_InsEstudiante = "INSERT INTO estudiante VALUES(?,?,?,?,?,NOW())";
  $statement = $conexion -> prepare($sql_InsEstudiante);
  if($statement === false){
    die("Error al preparar la declaración: " . $conexion -> error);
  }
  $statement -> bind_param("sssss", $boleta, $nombre, $primerApe, $segundoApe, $correo);
  
  $boleta = "2026630006";
  $nombre = "Pato";
  $primerApe = "Lucas";
  $segundoApe = "Lucas";
  $correo = "pato@pato.com";
  
  $statement -> execute();

  $boleta = "2026630007";
  $nombre = "Bugs";
  $primerApe = "Buny";
  $segundoApe = "Buny";
  $correo = "bugs@bugs.com";

  $statement -> execute();

  echo "Filas afectadas: " . $statement -> affected_rows;
  echo "<br><br>";

  $respJson = [];
  $respJson["cod"] = 1;
  $respJson["msj"] = "Se insertaron registros";
  $respJson["data"] = $statement -> affected_rows;
  echo (json_encode($respJson));

  $statement -> close();
  $conexion -> close();
?>