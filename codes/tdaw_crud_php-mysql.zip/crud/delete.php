<?php
  include("./configBD.php");

  $sqlDelEstudiante = "DELETE FROM estudiante WHERE boleta = ?";
  $statement = $conexion -> prepare($sqlDelEstudiante);
  $statement -> bind_param("s", $boleta);

  $boleta = "2026630010";
  $statement -> execute();

  echo "Filas afectadas: " . $statement -> affected_rows;
  echo "<br><br>";

  $respJson = [];
  $respJson["cod"] = 1;
  $respJson["msj"] = "Se eliminaron registros";
  $respJson["data"] = $statement -> affected_rows;
  echo (json_encode($respJson));

  $statement -> close();
  $conexion -> close();

?>