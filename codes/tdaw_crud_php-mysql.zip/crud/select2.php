<?php
  include("./configBD.php");

  $sqlSelAlumno = "SELECT * FROM alumno WHERE boleta = ? AND nombre = ?";
  $statement = $conexion -> prepare($sqlSelAlumno);
  $statement -> bind_param("ss",$boleta, $x);

  $boleta = "2026630002";
  $x = "Diana";

  $statement -> execute();
  $resultadoSelAlumno = $statement -> get_result();

  echo $resultadoSelAlumno->num_rows . "<br>";  
  
  $detallesSelAlumno = $resultadoSelAlumno -> fetch_all(MYSQLI_ASSOC);

  foreach ($detallesSelAlumno as $alumno) {
    echo "Boleta: " . $alumno["boleta"] . " " . $alumno["nombre"] . "<br>";
  };

  echo "<br><br>";

  $respServ = [];
  $respServ["cod"] = 1;
  $respServ["msj"] = "Información del alumno";
  $respServ["data"] = $detallesSelAlumno;

  echo json_encode($respServ);

?>