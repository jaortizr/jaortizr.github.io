<?php
  include("./configBD.php");

  $sqlUpdEstudiante = "UPDATE estudiante SET nombre = ?, correo = ?, auditoria = NOW() WHERE boleta = ?";
  $statement = $conexion -> prepare($sqlUpdEstudiante);
  $statement -> bind_param("sss", $nombre, $correo, $boleta);

  $nombre = "Juan Luis";
  $correo = "juan@gmail.com";
  $boleta = "2026630001";
  $statement -> execute();

  echo "Filas actualizadas: " . $statement -> affected_rows;
  echo "<br><br>";

  $respJson = [];
  $respJson["cod"] = 1;
  $respJson["msj"] = "Se eliminaron registros";
  $respJson["data"] = $statement -> affected_rows;
  echo (json_encode($respJson));

  $statement -> close();
  $conexion -> close();
?>