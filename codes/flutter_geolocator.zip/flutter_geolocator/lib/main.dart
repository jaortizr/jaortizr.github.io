import 'dart:async';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Geolocator Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: LocationScreen(),
    );
  }
}

class LocationScreen extends StatefulWidget {
  const LocationScreen({super.key});

  @override
  _LocationScreenState createState() => _LocationScreenState();
}

class _LocationScreenState extends State<LocationScreen> {
  String _locationMessage = 'No location data';
  String _permissionMessage = 'Location permission not verified';

  @override
  void initState() {
    super.initState();
    // Ask for location permission when the app starts
    checkAndRequestPermission();
  }

  // 1. Get current location
  Future<void> getCurrentLocation() async {
    try {
      final LocationSettings locationSettings = LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 100,
      );
      Position position = await Geolocator.getCurrentPosition(locationSettings: locationSettings);
      setState(() {
        _locationMessage = 'Latitude: ${position.latitude}, Longitude: ${position.longitude}';
      });
    } catch (e) {
      setState(() {
        _locationMessage = 'Error: $e';
      });
    }
  }

  // 2. Get last known position
  Future<void> getLastKnownLocation() async {
    try {
      Position? position = await Geolocator.getLastKnownPosition();
      if (position != null) {
        setState(() {
          _locationMessage = 'Last known position: Latitude: ${position.latitude}, Longitude: ${position.longitude}';
        });
      } else {
        setState(() {
          _locationMessage = 'No previous position available.';
        });
      }
    } catch (e) {
      setState(() {
        _locationMessage = 'Error: $e';
      });
    }
  }

  // 3. Listen to location updates
  Future<void> listenToLocationUpdates() async {
    final LocationSettings locationSettings = LocationSettings(
      accuracy: LocationAccuracy.high,
      distanceFilter: 100,
    );
    StreamSubscription<Position> positionStream = Geolocator.getPositionStream(locationSettings: locationSettings).listen(
      (Position? position) {
        setState(() {
          _locationMessage = position == null
              ? 'Unknown'
              : 'Latitude: ${position.latitude}, Longitude: ${position.longitude}';
        });
      },
    );
  }

  // 4. Check if location services are enabled
  Future<void> checkLocationService() async {
    bool isLocationServiceEnabled = await Geolocator.isLocationServiceEnabled();
    setState(() {
      _locationMessage = isLocationServiceEnabled
          ? 'Location services are enabled.'
          : 'Location services are disabled.';
    });
  }

  // 5. Check and request location permission
  Future<void> checkAndRequestPermission() async {
    LocationPermission permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      setState(() {
        _permissionMessage = 'Location permission denied. Requesting permission...';
      });
      permission = await Geolocator.requestPermission();
    }

    setState(() {
      if (permission == LocationPermission.whileInUse || permission == LocationPermission.always) {
        _permissionMessage = 'Location permission granted.';
      } else {
        _permissionMessage = 'Location permission permanently denied.';
      }
    });
  }

  // 6. Calculate distance between two points
  Future<void> calculateDistance() async {
    double distanceInMeters = Geolocator.distanceBetween(
      52.2165157, 6.9437819, 52.3546274, 4.8285838,
    );
    setState(() {
      _locationMessage = 'Calculated distance: $distanceInMeters meters';
    });
  }

  // 7. Open app or location settings
  Future<void> openSettings() async {
    await Geolocator.openAppSettings();
    await Geolocator.openLocationSettings();
  }

  // 8. Check location accuracy
  Future<void> checkLocationAccuracy() async {
    var accuracy = await Geolocator.getLocationAccuracy();
    setState(() {
      _locationMessage = 'Location accuracy: $accuracy';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Geolocator Example'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(_permissionMessage),
            SizedBox(height: 20),
            Text(_locationMessage),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: getCurrentLocation,
              child: Text('Get current location'),
            ),
            ElevatedButton(
              onPressed: getLastKnownLocation,
              child: Text('Get last known position'),
            ),
            ElevatedButton(
              onPressed: listenToLocationUpdates,
              child: Text('Listen to location updates'),
            ),
            ElevatedButton(
              onPressed: checkLocationService,
              child: Text('Check if location services are enabled'),
            ),
            ElevatedButton(
              onPressed: checkAndRequestPermission,
              child: Text('Check and request permissions'),
            ),
            ElevatedButton(
              onPressed: calculateDistance,
              child: Text('Calculate distance between two points'),
            ),
            ElevatedButton(
              onPressed: openSettings,
              child: Text('Open settings'),
            ),
            ElevatedButton(
              onPressed: checkLocationAccuracy,
              child: Text('Check location accuracy'),
            ),
          ],
        ),
      ),
    );
  }
}
