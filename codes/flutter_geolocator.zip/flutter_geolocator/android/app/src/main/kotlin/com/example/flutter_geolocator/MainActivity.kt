package com.example.flutter_geolocator

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
