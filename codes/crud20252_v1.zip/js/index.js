$(document).ready(()=>{
  const validarFormLogin = new JustValidate("#formLogin",{
    errorFieldCssClass:"is-invalid",
    successFieldCssClass:"is-valid"
  });
  validarFormLogin
  .addField("#correo", [
    {
      rule:"required",
      errorMessage:"Falta tu correo"
    },
    {
      rule:"email",
      errorMessage:"Debe ser un formato de correo valido"
    }
  ])
  .addField("#contrasena",[
    {
      rule:"required"
    },
    {
      rule:"strongPassword"
    }
  ]).
  onSuccess((e)=>{
    console.log($("#formLogin").serialize());
    $.ajax({
      url:"./php/index_AX.php",
      method:"post",
      data:$("#formLogin").serialize(),
      cache:false,
      success:(respAX)=>{
        console.log(respAX);
        let objAX = JSON.parse(respAX);
        Swal.fire({
          title:"TDAW - 20252",
          text:objAX.data,
          icon:objAX.icono,
          footer:objAX.log,
          didDestroy:()=>{
            window.location.href = "https://www.ipn.mx"
          }
        });
      }
    });
  })
  ;

});