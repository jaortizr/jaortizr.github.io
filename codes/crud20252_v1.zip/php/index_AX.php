<?php
  date_default_timezone_set("America/Mexico_City");
  $respAX = [];
  $respAX["code"] = 1;
  $respAX["log"] = date("Y-m-d H:i:s");
  $respAX["icono"] = "success";
  $respAX["data"] = $_REQUEST["contrasena"];

  echo json_encode($respAX);
?>