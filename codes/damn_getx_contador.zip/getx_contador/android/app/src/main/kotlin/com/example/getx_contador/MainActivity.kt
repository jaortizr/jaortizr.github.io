package com.example.getx_contador

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
