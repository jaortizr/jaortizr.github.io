import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:getx_contador/contador_controller.dart';

class CounterPage extends StatelessWidget {
      
      final CounterController counterController = Get.put(CounterController()); // Initialize the controller

      CounterPage({super.key});

      @override
      Widget build(BuildContext context) {
        return Scaffold(
          appBar: AppBar(
            title: const Text('GetX Counter'),
          ),
          body: Center(
            child: Column(
              mainAxisAlignment:MainAxisAlignment.center,
              children: [
                Obx(
                  () => Text(
                    'Count: ${counterController.count.value}', // Access the observable value
                    style: const TextStyle(fontSize: 24),
                  ),
                ),
                TextButton(
                  onPressed: (){
                    counterController.decrement();
                  }, 
                  child: Text("Disminuir")
                )
              ],
            ),
          ),
          floatingActionButton: FloatingActionButton(
            onPressed: counterController.increment,
            child: const Icon(Icons.add),
          ),
        );
      }
    }