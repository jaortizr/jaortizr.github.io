    import 'package:get/get.dart';

    class CounterController extends GetxController {
      var count = 0.obs; // .obs makes the variable observable

      void increment() {
        count++;
      }

      void decrement() {
        if(count > 0){
          count--;
        }
      }
    }