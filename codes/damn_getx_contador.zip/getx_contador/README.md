# getx_contador

A new Flutter project.
