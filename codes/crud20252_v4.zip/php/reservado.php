<?php
  session_start();
  if(isset($_SESSION["boleta"])){
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Reservado CRUD 20252</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" />
  <link href="./../libs/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="./../libs/jquery-3.7.1.min.js"></script>
  <script src="./../libs/bootstrap/js/bootstrap.min.js"></script>
  <script src="./../js/reservado.js"></script>
  <style>
    .ver{cursor:pointer;}
  </style>
</head>
<body>
  <header>

  </header>
  <main>
    <div class="container">
      <div class="row mb-3">
        <h2>Bienvenido :) <span id="nombreUsr"></span></h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet rerum animi placeat numquam eligendi autem libero culpa facere inventore dolore possimus maxime cumque consectetur perspiciatis incidunt ipsa corrupti, praesentium repellat minus magni, dolores nostrum aperiam dolorum. Eos, quia. Laboriosam neque ut doloremque quia at nostrum magni dolorum ipsa. Magni, iste?</p>
      </div>
      <table class="table table-striped">
        <thead>
          <tr><th>Boleta</th><th>Nombre</th><th>Cumpleaños</th><th>Correo</th><th>Opciones</th></tr>
        </thead>
        <tbody id="respAXAlumnos">

        </tbody>
      </table>
      <a href="./cerrarSesion.php?nombreSesion=boleta" class="btn btn-primary">Cerrar Sesión</a>
    </div>
  </main>
  <footer>

  </footer>
</body>
</html>
<?php
  }else{
    header("location:./../index.html");
  }
?>
