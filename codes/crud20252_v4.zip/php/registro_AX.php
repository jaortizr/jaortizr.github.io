<?php
  include("./configBD.php");

  date_default_timezone_set("America/Mexico_City");
  extract($_REQUEST);
  $contrasena = md5($contrasena);

  $respAX = [];
  $sqlCheckAlumno = "SELECT * FROM alumno  WHERE boleta = '$boleta'";
  $resCheckAlumno = mysqli_query($conexion, $sqlCheckAlumno);
  if(mysqli_num_rows($resCheckAlumno) >= 1){
    $respAX["code"] = 2;  
    $respAX["msj"] = "Datos ya están registrados. Favor de intentarlo nuevamente";
    $respAX["icono"] = "info";
    $respAX["data"] = "";
    $respAX["log"] = date("Y-m-d H:i:s");
  }else{
    $sqlInsAlumno = "INSERT INTO alumno VALUES('$boleta','$nombre','$apellidos','$fechaNacimiento', '$correo', '$contrasena', NOW())";
    $resInsAlumno = mysqli_query($conexion, $sqlInsAlumno);
    if(mysqli_affected_rows($conexion) == 1){
      $respAX["code"] = 1;
      $respAX["msj"] = "Gracias. Tus datos fueron registrados correctamente";
      $respAX["icono"] = "success";
      $respAX["data"] = "";
      $respAX["log"] = date("Y-m-d H:i:s");
    }else{
      $respAX["code"] = 0;
      $respAX["msj"] = "Error de BD. Favor de intentarlo nueva,emente";
      $respAX["icono"] = "error";
      $respAX["data"] = "";
      $respAX["log"] = date("Y-m-d H:i:s");
    }
  }

  echo json_encode($respAX);

?>