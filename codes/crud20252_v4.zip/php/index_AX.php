<?php
  session_start();
  include("./configBD.php");
  
  date_default_timezone_set("America/Mexico_City");
  $respAX = [];
  
  $correo = $_REQUEST["correo"];
  $contrasena = md5($_REQUEST["contrasena"]);

  $sqlGetAlumno = "SELECT * FROM alumno WHERE correo = '$correo' AND contrasena = '$contrasena'";
  $resGetAlumno = mysqli_query($conexion, $sqlGetAlumno);
  if(mysqli_num_rows($resGetAlumno) == 1){
    $alumno = mysqli_fetch_assoc($resGetAlumno);
    $respAX["code"] = 1;
    $respAX["icono"] = "success";
    $respAX["data"] = "Bienvenido ".$alumno["nombre"] ;
    $_SESSION["boleta"] = $alumno["boleta"];
  }else{
    $respAX["code"] = 0;
    $respAX["icono"] = "error";
    $respAX["data"] = "Favor de revisar tus dato";
  }

  $respAX["log"] = date("Y-m-d H:i:s");
  echo json_encode($respAX);
?>