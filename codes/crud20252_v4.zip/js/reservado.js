$(document).ready(()=>{
  $.ajax({
    url:"./reservado_BD.php",
    method:"post",
    cache:"false",
    success:(respAX)=>{
      let objAX_selAlumnos = JSON.parse(respAX);
      let alumnos = objAX_selAlumnos.data;
      let alumno = objAX_selAlumnos.alumno;
      let filasAlumnos = "";
      alumnos.forEach((elemento) => {
        filasAlumnos += `
          <tr>
            <td>${elemento.boleta}</td>
            <td>${elemento.nombre} ${elemento.apellidos}</td>
            <td>${elemento.fechaNacimiento}</td>
            <td>${elemento.correo}</td>
            <td>
              <i class="fas fa-eye fa-2x ver" data-boleta='${elemento.boleta}'></i>&nbsp;&nbsp;
              <i class="fas fa-pen fa-2x"></i>&nbsp;&nbsp;
              <i class="fas fa-trash fa-2x"></i>
            </td>
          </tr>
        `;
      });
      $("span#nombreUsr").text(alumno.nombre);
      $("tbody#respAXAlumnos").html(filasAlumnos);
    }
  });

});