package com.example.flutter_camera

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
