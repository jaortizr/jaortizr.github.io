import 'package:flutter/material.dart';
import 'steps_page.dart';
import 'notifications_page.dart';
import 'settings_page.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final opciones = [
      {"titulo": "Pasos", "pagina": const StepsPage()},
      {"titulo": "Notificaciones", "pagina": const NotificationsPage()},
      {"titulo": "Ajustes", "pagina": const SettingsPage()},
    ];

    return Scaffold(
      body: Center(
        child: ListView.builder(
          itemCount: opciones.length,
          itemBuilder: (context, index) {
            final opcion = opciones[index];
            return ListTile(
              title: Text(opcion["titulo"] as String),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => opcion["pagina"] as Widget),
                );
              },
            );
          },
        ),
      ),
    );
  }
}