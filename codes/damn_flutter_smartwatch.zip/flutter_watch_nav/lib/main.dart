import 'package:flutter/material.dart';
import 'home_page.dart';

void main() {
  runApp(const MyWatchApp());
}

class MyWatchApp extends StatelessWidget {
  const MyWatchApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Wear OS Navegación',
      theme: ThemeData(primarySwatch: Colors.indigo),
      home: const HomePage(),
    );
  }
}