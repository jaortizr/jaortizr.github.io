import 'package:flutter/material.dart';

class NotificationsPage extends StatelessWidget {
  const NotificationsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final notificaciones = ["Mensaje de Ana", "Reunión a las 7pm", "Batería baja"];

    return Scaffold(
      body: ListView.builder(
        itemCount: notificaciones.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(notificaciones[index]),
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text("Abriste: ${notificaciones[index]}")),
              );
            },
          );
        },
      ),
    );
  }
}