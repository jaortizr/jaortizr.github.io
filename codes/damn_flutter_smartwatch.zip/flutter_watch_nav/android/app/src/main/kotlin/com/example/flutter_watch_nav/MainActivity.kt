package com.example.flutter_watch_nav

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
