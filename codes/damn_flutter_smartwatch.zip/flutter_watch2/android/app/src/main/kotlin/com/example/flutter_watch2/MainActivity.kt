package com.example.flutter_watch2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
