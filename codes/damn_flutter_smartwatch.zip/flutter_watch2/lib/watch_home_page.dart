import 'package:flutter/material.dart';

class WatchHomePage extends StatelessWidget {
  const WatchHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final opciones = ["Mensajes", "Notificaciones", "Ajustes", "Salir"];

    return Scaffold(
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // 1. Pantalla circular principal
              ClipOval(
                child: Container(
                  color: Colors.indigo,
                  width: 180,
                  height: 180,
                  child: const Center(
                    child: Text(
                      "Smartwatch Demo",
                      style: TextStyle(color: Colors.white, fontSize: 14),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
        
              // 2. Indicador circular de progreso
              SizedBox(
                width: 150,
                height: 150,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    const CircularProgressIndicator(
                      value: 0.65, // 65% completado
                      strokeWidth: 8,
                      color: Colors.indigo,
                    ),
                    const Text("Pasos: 6500", style: TextStyle(fontSize: 14)),
                  ],
                ),
              ),
              const SizedBox(height: 20),
        
              // 3. Menú circular con botones
              Wrap(
                spacing: 15,
                runSpacing: 15,
                alignment: WrapAlignment.center,
                children: opciones.map((opcion) {
                  return ClipOval(
                    child: Material(
                      color: Colors.indigo,
                      child: InkWell(
                        onTap: () {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text("Seleccionaste: $opcion")),
                          );
                        },
                        child: SizedBox(
                          width: 70,
                          height: 70,
                          child: Center(
                            child: Text(
                              opcion,
                              style: const TextStyle(
                                  color: Colors.white, fontSize: 11),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}