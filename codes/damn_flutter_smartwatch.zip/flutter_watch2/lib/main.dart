import 'package:flutter/material.dart';
import 'watch_home_page.dart';

void main() {
  runApp(const MyWatchApp());
}

class MyWatchApp extends StatelessWidget {
  const MyWatchApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Smartwatch Demo',
      theme: ThemeData(primarySwatch: Colors.indigo),
      home: const WatchHomePage(),
    );
  }
}