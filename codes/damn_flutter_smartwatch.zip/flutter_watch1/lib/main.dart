import 'package:flutter/material.dart';

void main() {
  runApp(const MyWatchApp());
}

class MyWatchApp extends StatelessWidget {
  const MyWatchApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Wear OS Demo',
      theme: ThemeData(primarySwatch: Colors.indigo),
      home: const MenuPage()
    );
  }
}

/* ********** Caratula rectangular ********** */
class WatchHomePage extends StatelessWidget {
  const WatchHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text("Hola desde tu smartwatch!",
                style: TextStyle(fontSize: 14)),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text("Botón presionado")),
                );
              },
              child: const Text("Presionar"),
            ),
          ],
        ),
      ),
    );
  }
}

class MenuPage extends StatelessWidget {
  const MenuPage({super.key});

  @override
  Widget build(BuildContext context) {
    final opciones = ["Conócenos", "Oferta Educativa", "Mensajes", "Notificaciones", "Configuración", "Salir"];

    return Scaffold(
      body: ListView.builder(
        itemCount: opciones.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(opciones[index]),
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text("Seleccionaste: ${opciones[index]}")),
              );
            },
          );
        },
      ),
    );
  }
}


/* ********** Caratula circular ********** */
class CircularTextPage extends StatelessWidget {
  const CircularTextPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: ClipOval(
          child: Container(
            color: Colors.indigo,
            width: 200,
            height: 200,
            child: const Center(
              child: Text(
                "Smartwatch",
                style: TextStyle(color: Colors.white, fontSize: 16),
                textAlign: TextAlign.center,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class CircularMenuPage extends StatelessWidget {
  const CircularMenuPage({super.key});

  @override
  Widget build(BuildContext context) {
    final opciones = ["Conócenos", "Oferta Educativa", "Mensajes", "Notificaciones", "Ajustes", "Salir"];

    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          child: Wrap(
            spacing: 20,
            runSpacing: 20,
            alignment: WrapAlignment.center,
            children: opciones.map((opcion) {
              return ClipOval(
                child: Material(
                  color: Colors.indigo,
                  child: InkWell(
                    onTap: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text("Seleccionaste: $opcion")),
                      );
                    },
                    child: SizedBox(
                      width: 80,
                      height: 80,
                      child: Center(
                        child: Text(
                          opcion,
                          style: const TextStyle(color: Colors.white, fontSize: 12),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }
}

class CircularProgressPage extends StatelessWidget {
  const CircularProgressPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SizedBox(
          width: 150,
          height: 150,
          child: Stack(
            alignment: Alignment.center,
            children: [
              const CircularProgressIndicator(
                value: 0.79, // 79% completado
                strokeWidth: 6,
                color: Colors.indigo,
              ),
              const Text("70%", style: TextStyle(fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }
}