package com.example.flutter_watch1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
