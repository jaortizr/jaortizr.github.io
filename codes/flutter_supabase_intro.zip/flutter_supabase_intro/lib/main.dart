import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';


Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: "",
    anonKey: ""
  );
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      title: 'Alumnos',
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _future = Supabase.instance.client
      .from("alumno")
      .select();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder(
        future: _future,
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final alumnos = snapshot.data!;
          return ListView.builder(
            itemCount: alumnos.length,
            itemBuilder: ((context, index) {
              final alumno = alumnos[index];
              return ListTile(
                title: Text(alumno["nombre"]),
                subtitle: Text("DAMN-20252"),
                leading: Icon(Icons.account_circle),
              );
            }),
          );
        },
      ),
    );
  }
}