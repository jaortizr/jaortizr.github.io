package com.example.flutter_supabase_intro

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
