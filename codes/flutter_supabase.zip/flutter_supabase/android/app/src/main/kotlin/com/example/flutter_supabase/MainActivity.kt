package com.example.flutter_supabase

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
