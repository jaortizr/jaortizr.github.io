package com.example.dio_vesp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
