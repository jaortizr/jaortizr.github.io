import 'package:flutter/material.dart';
import 'package:dio/dio.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  void getHttp() async {
    final dio = Dio();
    Response response = await dio.post(
      "https://jsonplaceholder.typicode.com/posts",
      data: {
        "title": "IPN",
        "body": "ESCOM",
        "userId": 29
      }
    );
    dio.close();
    print(response.data);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("DIO"),
          backgroundColor: Colors.black,
          foregroundColor: Colors.white,
        ),
        body: Center(
          child: TextButton(
            onPressed: (){
              getHttp();
            },
            child: Text("DIO"),
          ),
        ),
      ),
    );
  }
}
