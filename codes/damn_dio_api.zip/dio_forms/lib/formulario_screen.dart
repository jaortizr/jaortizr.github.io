import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:form_builder_validators/form_builder_validators.dart';
import 'package:art_sweetalert/art_sweetalert.dart';

class FormularioScreen extends StatefulWidget {
  const FormularioScreen({super.key});

  @override
  State<FormularioScreen> createState() => _FormularioScreenState();
}

class _FormularioScreenState extends State<FormularioScreen> {
  final GlobalKey<FormBuilderState> formKey = GlobalKey();

  void getHttp(String json) async {
    final dio = Dio();
    Response response = await dio.post(
      "https://jsonplaceholder.typicode.com/posts",
      data: json 
    );

    if(response.statusCode == 201){
      ArtSweetAlert.show(
        context: context,
        artDialogArgs: ArtDialogArgs(
          type: ArtSweetAlertType.success,
          title: "DAMN 20261",
          text: "Se registró correctamente la información (${response.statusCode})", 
        )
      );
    }else{
      ArtSweetAlert.show(
        context: context,
        artDialogArgs: ArtDialogArgs(
          type: ArtSweetAlertType.danger,
          title: "DAMN 20261",
          text: "Error. (${response.statusCode})", 
        )
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("DIO-FORMS"),
        backgroundColor: Colors.blueAccent,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: FormBuilder(
          key: formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              FormBuilderTextField(
                name: "title",
                decoration: InputDecoration(labelText: "Title"),
                validator: FormBuilderValidators.compose([
                  FormBuilderValidators.required(errorText: "Falta el título del post")
                ])
              ),
              SizedBox(height: 20,),
              FormBuilderTextField(
                name: "body",
                decoration: InputDecoration(labelText: "Body"),
                validator: FormBuilderValidators.compose([
                  FormBuilderValidators.required(errorText: "Falta el contenido del post")
                ])
              ),
              SizedBox(height: 20,),
              FormBuilderTextField(
                name: "userId",
                decoration: InputDecoration(labelText: "User Id"),
                validator: FormBuilderValidators.compose([
                  FormBuilderValidators.required(errorText: "falat el id del post")
                ])
              ),
              SizedBox(height: 20,),
              ElevatedButton(
                onPressed: (){
                  if(formKey.currentState!.saveAndValidate()){
                    Map<String,dynamic> unMapa = formKey.currentState!.value;
                    String unJson = jsonEncode(unMapa);
                    print(unMapa);
                    print(unJson);
                    getHttp(unJson);
                  }
                },
                child: Text("/posts")
              )
            ],
          )
        ),
      ),
    );
  }
}