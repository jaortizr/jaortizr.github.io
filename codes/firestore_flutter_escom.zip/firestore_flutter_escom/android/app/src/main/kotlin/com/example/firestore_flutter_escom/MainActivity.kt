package com.example.firestore_flutter_escom

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
