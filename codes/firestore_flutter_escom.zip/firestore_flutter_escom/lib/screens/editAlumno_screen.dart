import 'package:firestore_flutter_escom/services/alumnos_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:form_builder_validators/form_builder_validators.dart';

class EditAlumno extends StatefulWidget {
  const EditAlumno({super.key});

  @override
  State<EditAlumno> createState() => _EditAlumnoState();
}

class _EditAlumnoState extends State<EditAlumno> {
  final _formKey = GlobalKey<FormBuilderState>();

  @override
  Widget build(BuildContext context) {
    final Map arguments = ModalRoute.of(context)!.settings.arguments as Map;

    return Scaffold(
      appBar: AppBar(title: const Text("Editar Alumno"), centerTitle: true),
      body: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Center(
          child: Column(
            children: [
              const Text("Editar Alumno", style: TextStyle(fontSize: 25, fontWeight: FontWeight.w500)),
              const SizedBox(height: 15),
              FormBuilder(
                key: _formKey,
                initialValue: {"nombre": arguments["nombre"]},
                child: Column(
                  children: [
                    FormBuilderTextField(
                      name: "nombre",
                      decoration: const InputDecoration(labelText: "Nombre"),
                      validator: FormBuilderValidators.compose([
                        FormBuilderValidators.required(errorText: "Falta el nombre")
                      ]),
                    ),
                    const SizedBox(height: 15),
                    ElevatedButton(
                      onPressed: () async{
                        if(_formKey.currentState!.saveAndValidate()){
                          await editAlumno(arguments["id"], _formKey.currentState!.value["nombre"]).then((_)=>Navigator.pop(context));
                        }
                      },
                      child: const Text("Actualizar"))
                  ]
                )
              )
            ],
          ),
        ),
      ),
    );
  }
}