import 'package:art_sweetalert/art_sweetalert.dart';
import 'package:firestore_flutter_escom/services/alumnos_service.dart';
import 'package:flutter/material.dart';

class Home extends StatefulWidget {
  const Home({
    super.key,
  });

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Flutter & Firestore"),
        centerTitle: true,
      ),
      body: FutureBuilder(
        future: getAlumnos(),
        builder: ((context, snapshot){
          if(snapshot.hasData){
            return ListView.builder(
              itemCount: snapshot.data?.length,
              itemBuilder: (context, index){
                return Dismissible(
                  key: Key(snapshot.data?[index]["id"]),
                  confirmDismiss: (_) async{
                    bool respuesta = false;
                    ArtDialogResponse response = await ArtSweetAlert.show(
                      barrierDismissible: false,
                      context: context,
                      artDialogArgs: ArtDialogArgs(
                        title: "Flutter & Firestore",
                        text: "¿Eliminar alumno?",
                        type: ArtSweetAlertType.question,
                        confirmButtonText: "Sí",
                        denyButtonText: "No"
                      )
                    );
                    if(response.isTapConfirmButton) {
                      respuesta = true;
                    }
                    if(response.isTapDenyButton){
                      respuesta = false;
                    }
                    return respuesta;
                  },
                  onDismissed: (_) async{
                    await deleteAlumno(snapshot.data?[index]["id"]);
                    snapshot.data?.removeAt(index);
                  },
                  background: Container(
                    color: Colors.red,
                    child: const Icon(Icons.delete, color: Colors.white),
                  ),
                  direction: DismissDirection.endToStart,
                  child: ListTile(
                    title: Text(snapshot.data?[index]["nombre"]),
                    onTap:() async{
                      await Navigator.pushNamed(context, "/editAlumno", arguments: {
                        "nombre":snapshot.data?[index]["nombre"],
                        "id":snapshot.data?[index]["id"]
                      });
                      setState(() {});
                    }
                  ),
                );
              }
            );
          }else{
            return const Center(
              child: CircularProgressIndicator()
            );
          }
        })
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async{
          await Navigator.pushNamed(context, "/addAlumno");
          setState(() {});
        },
        child: const Icon(Icons.add)
      ),
    );
  }
}