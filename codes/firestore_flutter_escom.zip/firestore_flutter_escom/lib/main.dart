import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
//Screens
import 'package:firestore_flutter_escom/screens/home_screen.dart';
import 'package:firestore_flutter_escom/screens/addAlumno_screen.dart';
import 'package:firestore_flutter_escom/screens/editAlumno_screen.dart';

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "Flutter & Firestore",
      initialRoute: "/",
      routes: {
        "/" : (context) => const Home(),
        "/addAlumno" : (context) => const AddAlumno(),
        "/editAlumno" : (context) => const EditAlumno()
      },
    );
  }
}

