import 'package:cloud_firestore/cloud_firestore.dart';

FirebaseFirestore db = FirebaseFirestore.instance;

Future<List> getAlumnos() async{
  List alumnos = [];
  CollectionReference collectionReferenceAlumnos = db.collection("alumnos");
  QuerySnapshot queryAlumnos = await collectionReferenceAlumnos.get();
  for (var alumno in queryAlumnos.docs) {
    final Map<String, dynamic> data = alumno.data() as Map<String, dynamic>;
    final dataAlumno = {
      "nombre":data["nombre"],
      "id":alumno.id
    };
    alumnos.add(dataAlumno);
  }
  return alumnos;
}

Future<void> addAlumno(String nombre) async{
  await db.collection("alumnos").add({"nombre":nombre});
}

Future<void> editAlumno(String id, String nombre) async{
  await db.collection("alumnos").doc(id).set({"nombre":nombre});
}

Future<void> deleteAlumno(String id) async{
  await db.collection("alumnos").doc(id).delete();
}