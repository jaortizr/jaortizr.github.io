import 'package:flutter/material.dart';
import 'package:flutter_authlocal/authlocal_services.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatefulWidget {
  const MainApp({super.key});

  @override
  State<MainApp> createState() => _MainAppState();
}

class _MainAppState extends State<MainApp> {
  final AuthlocalServices authlocalservices = AuthlocalServices();
  var msj = "";

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(title: Text("Acceso:"), centerTitle: true),
        body: Center(
          child: Column(children: [
            Text("Desbloquear para acceder"),
            SizedBox(height: 20),
            Text(msj)
          ],),
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () async{
            final isAuth = await authlocalservices.authConBiometricos();
            if(isAuth){
              setState(() {
                msj = "Biometricos correctos...";
              });
            }          
          },
          child: const Icon(Icons.lock_person_outlined)
        ),
      )
    );
  }
}


