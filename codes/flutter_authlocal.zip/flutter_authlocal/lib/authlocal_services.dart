import 'package:local_auth/local_auth.dart';

class AuthlocalServices {
  final LocalAuthentication localAuthentication = LocalAuthentication();

  authConBiometricos() async{
    final isAuth = await localAuthentication.authenticate(
      localizedReason: "Desbloquear para acceder",
      options: AuthenticationOptions(
        useErrorDialogs: true,
        stickyAuth: true,
        biometricOnly: false
      )
    );

    return isAuth;
  }
}