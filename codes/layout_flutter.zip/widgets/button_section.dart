import 'package:flutter/material.dart';
import 'package:layout_20251/widgets/button_with_text.dart';

class ButtonSection extends StatelessWidget {
  const ButtonSection({super.key});

  @override
  Widget build(BuildContext context) {
    return const Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        ButtonWithText(color: Colors.blueGrey, icon: Icons.mail, label: "Correo"),
        ButtonWithText(color: Colors.blueGrey, icon: Icons.verified_user_outlined, label: "Usuario"),
        ButtonWithText(color: Colors.blueGrey, icon: Icons.map, label: "Ubicación")
      ],
    );
  }
}