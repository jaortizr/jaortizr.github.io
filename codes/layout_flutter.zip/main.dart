import 'package:flutter/material.dart';
import 'package:layout_20251/widgets/button_section.dart';
import 'package:layout_20251/widgets/image_section.dart';
import 'package:layout_20251/widgets/text_section.dart';
import 'package:layout_20251/widgets/title_section.dart';

void main(){
  runApp(const Layout());
}

class Layout extends StatelessWidget {
  const Layout({super.key});

  @override
  Widget build(BuildContext context) {
    const String appTitle = "Demo ESCOM";
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: appTitle,
      home: Scaffold(
        appBar: AppBar(
          title: const Text(appTitle),
          centerTitle: true
        ),
        body: const SingleChildScrollView(
          child: Column(
            children: [
              ImageSection(image: "lib/assets/lake.jpg"),
              TitleSection(name: "Diana Cazadora", location: "CDMX"),
              ButtonSection(),
              TextSection(
                description: """También puede proporcionar a los consumidores productos más duraderos e innovadores que brinden ahorros monetarios y una mayor calidad de vida, por ejemplo, si los teléfonos móviles fuesen más fáciles de desmontar el coste de volverlo a fabricar podría reducirse a la mitad.""")
            ],
          ),
        )
      ),
    );
  }
}