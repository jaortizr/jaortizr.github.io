package com.example.flutter_go_router

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
