import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  MyApp({super.key});

  final _router = GoRouter(routes: [
    GoRoute(path: "/", builder: (context, state) => Inicio()),
    GoRoute(path: "/detalles/:param", name:"parametro", builder: (context, state){
      return Detalles(parametro: state.pathParameters["param"]!);
    }),
    GoRoute(path: "/contacto/:func/:nombre", name: "funcionario", builder: (context, state){
      return Contacto(parametro: state.pathParameters["func"]!, nombre: state.pathParameters["nombre"]!);
    })
  ]);

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(routerConfig: _router, debugShowCheckedModeBanner: false);
  }
}

// ******************************************************* //

class Inicio extends StatelessWidget {
  const Inicio({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Inicio"), backgroundColor: Colors.lightBlueAccent),
      body: Center(
        child: Row(
          children: [
            ElevatedButton(
              onPressed: (){
                context.goNamed("parametro", pathParameters: {"param":"ESCOM IPN"});
              },
              child: const Text("Ir a Deatalles")
            ),
            ElevatedButton(
              onPressed: (){
                context.goNamed("funcionario", pathParameters: {"func":"Subdirector de Extensión", "nombre":"Jose Asunción Zarate"});
              },
              child: const Text("Ir a Contacto")
            )
          ],
        )
      )
    );
  }
}

class Detalles extends StatelessWidget {
  final String parametro;
  const Detalles({super.key, required this.parametro});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Detalles"), backgroundColor: Colors.yellow),
      body: Center(
        child: Column(
          children: [
            ElevatedButton(
              onPressed: (){
                context.go("/");
              },
              child:Text("Ir al Inicio") 
            ),
            Text(parametro)
          ],
        )
      )
    );
  }
}

class Contacto extends StatelessWidget {
  final String parametro;
  final String nombre;
  const Contacto({super.key, required this.parametro, required this.nombre});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Contacto"), backgroundColor: Colors.green),
      body: Center(
        child: Column(
          children: [
            ElevatedButton(
              onPressed: (){
                context.go("/");
              },
              child:Text("Ir al Inicio") 
            ),
            Text("$parametro y $nombre")
          ],
        )
      )
    );
  }
}