package com.example.flutter_maps_geolocation

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
