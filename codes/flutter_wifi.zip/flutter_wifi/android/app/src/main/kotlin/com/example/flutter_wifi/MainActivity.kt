package com.example.flutter_wifi

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
