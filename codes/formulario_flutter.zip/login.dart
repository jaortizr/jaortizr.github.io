import 'package:flutter/material.dart';

class Login extends StatelessWidget {
  final Function togScreen;
  const Login({super.key, required this.togScreen});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(25),
        child: Center(
          child: SingleChildScrollView(
            child: Column(
              children: [
                const SizedBox(height: 40),
                const Icon(Icons.person_outline_outlined, color: Colors.grey, size: 140),
                const SizedBox(height: 13),
                const Text("Wellcome Back", style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
                const Text("sign in to continue", style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500, color: Colors.grey)),
                const SizedBox(height: 20),
                Container(
                  child:TextFormField(
                    style: TextStyle(color: Theme.of(context).primaryColor, fontSize: 22, fontWeight: FontWeight.bold),
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      prefixIcon: Icon(Icons.mail, size: 30,),
                      labelText: "EMAIL",
                      labelStyle: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)
                    ),
                  )
                ),
                const SizedBox(height: 10),
                Container(
                  child:TextFormField(
                    obscureText: true,
                    style: TextStyle(color: Theme.of(context).primaryColor, fontSize: 22, fontWeight: FontWeight.bold),
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      prefixIcon: Icon(Icons.security, size: 30,),
                      labelText: "Password",
                      labelStyle: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)
                    ),
                  )
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TextButton(
                      onPressed: (){},
                      child: Text("Forgot password", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Theme.of(context).primaryColor))
                    )
                  ]),
                const SizedBox(height: 10),
                SizedBox(
                  height: 55,
                  width: double.infinity,
                  child: MaterialButton(
                    onPressed: (){},
                    color: Theme.of(context).primaryColor,
                    textColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    child: const Text("Login")
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text("Don't have a count ", style: TextStyle(fontSize: 18)),
                    GestureDetector(
                      onTap: (){togScreen();},
                      child: Text("Register", style: TextStyle(fontSize: 20, color: Theme.of(context).primaryColor, fontWeight: FontWeight.bold)))
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}