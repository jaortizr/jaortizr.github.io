import 'package:flutter/material.dart';

class Register extends StatelessWidget {
  final Function togScreen;
  const Register({super.key, required this.togScreen});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        body: Padding(
          padding: const EdgeInsets.all(25),
          child: Center(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      IconButton(onPressed: (){togScreen();}, icon: const Icon(Icons.arrow_back), color: Theme.of(context).primaryColor, iconSize: 30),
                    ],
                  ),
                  const SizedBox(height: 40),
                  const Text("Create Account", style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
                  const Text("Create a new account", style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500, color: Colors.grey)),
                  const SizedBox(height: 20),
                  Container(
                    child:TextFormField(
                      style: TextStyle(color: Theme.of(context).primaryColor, fontSize: 22, fontWeight: FontWeight.bold),
                      decoration: const InputDecoration(
                        border: InputBorder.none,
                        prefixIcon: Icon(Icons.person_outline, size: 30,),
                        labelText: "NAME",
                        labelStyle: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)
                      ),
                    )
                  ),
                  Container(
                    child:TextFormField(
                      style: TextStyle(color: Theme.of(context).primaryColor, fontSize: 22, fontWeight: FontWeight.bold),
                      decoration: const InputDecoration(
                        border: InputBorder.none,
                        prefixIcon: Icon(Icons.email, size: 30,),
                        labelText: "EMAIL",
                        labelStyle: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)
                      ),
                    )
                  ),
                  Container(
                    child:TextFormField(
                      style: TextStyle(color: Theme.of(context).primaryColor, fontSize: 22, fontWeight: FontWeight.bold),
                      decoration: const InputDecoration(
                        border: InputBorder.none,
                        prefixIcon: Icon(Icons.phone, size: 30,),
                        labelText: "PHONE NUMBER",
                        labelStyle: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)
                      ),
                    )
                  ),
                  const SizedBox(height: 10),
                  Container(
                    child:TextFormField(
                      obscureText: true,
                      style: TextStyle(color: Theme.of(context).primaryColor, fontSize: 22, fontWeight: FontWeight.bold),
                      decoration: const InputDecoration(
                        border: InputBorder.none,
                        prefixIcon: Icon(Icons.security, size: 30,),
                        labelText: "PASSWORD",
                        labelStyle: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)
                      ),
                    )
                  ),
                  Container(
                    child:TextFormField(
                      obscureText: true,
                      style: TextStyle(color: Theme.of(context).primaryColor, fontSize: 22, fontWeight: FontWeight.bold),
                      decoration: const InputDecoration(
                        border: InputBorder.none,
                        prefixIcon: Icon(Icons.security, size: 30,),
                        labelText: "CONFIRM PASSWORD",
                        labelStyle: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)
                      ),
                    )
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    height: 55,
                    width: double.infinity,
                    child: MaterialButton(
                      onPressed: (){},
                      color: Theme.of(context).primaryColor,
                      textColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      child: const Text("Create account")
                    ),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text("Already have a acount ", style: TextStyle(fontSize: 18)),
                      GestureDetector(
                        onTap: (){togScreen();},
                        child: Text("Login", style: TextStyle(fontSize: 20, color: Theme.of(context).primaryColor, fontWeight: FontWeight.bold)))
                    ],
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}