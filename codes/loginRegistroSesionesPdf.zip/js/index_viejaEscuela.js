document.addEventListener("DOMContentLoaded", ()=>{
  const validator = new JustValidate("form#formRegistro",{
    //tooltip: {position:"top"}
    errorFieldCssClass:"is-invalid",
    successFieldCssClass:"is-valid",
    submitFormAutomatically: true
  });
  validator
    .addField("#boleta", [
      {
        rule: "required",
        errorMessage:"Falta tu boleta"
      },
      {
        rule:"integer",
        errorMessage:"Deben ser solo digitos"
      },
      {
        rule:"minLength",
        value:8,
        errorMessage:"Deben ser al menos 8 digitos"
      },
      {
        rule:"maxLength",
        value:10,
        errorMessage:"No deben ser más de 10 digitos"
      }
    ])
    .addField("#nombre",[
      {
        rule:"required",
        errorMessage:"Falta tu nombre"
      }
    ])
    .addField("#primerApe",[
      {
        rule:"required",
        errorMessage:"Falta tu primer apellido"
      }
    ])
    .addField("#segundoApe",[
      {
        rule:"required",
        errorMessage:"Falta tu segundo apellido"
      }
    ])
    .onSuccess((e)=>{
      console.log("OK FORM");
    });
});

