$(document).ready(()=>{
  const validator = new JustValidate("form#formLogin",{
    errorFieldCssClass:"is-invalid",
    successFieldCssClass:"is-valid"
  });
  validator
    .addField("#boleta", [
      {
        rule: "required",
        errorMessage:"Falta tu boleta"
      },
      {
        rule:"integer",
        errorMessage:"Deben ser solo digitos"
      },
      {
        rule:"minLength",
        value:8,
        errorMessage:"Deben ser al menos 8 digitos"
      },
      {
        rule:"maxLength",
        value:10,
        errorMessage:"No deben ser más de 10 digitos"
      }
    ])
    .addField("#contrasena",[
      {
        rule:"required",
        errorMessage:"Falta tu contraseña"
      },
      {
        rule:"password",
        errorMessage:"Mínimo 8 caracteres, letras y numeros"
      }
    ])
    .onSuccess((e)=>{
      $.ajax({
        url:"./php/index_AX.php",
        method:"post",
        data:$("form#formLogin").serialize(),
        cache:false,
        success:(respAX)=>{
          console.log(respAX);
          let objAX = JSON.parse(respAX);
          Swal.fire({
            title:"Alumnos",
            html:objAX.msj,
            icon:objAX.icono,
            footer:objAX.extra,
            didDestroy:()=>{
              if(objAX.cod == 1)
                window.location.href = "./php/reservado.php";
              else
              window.location.reload();
            }
          });
        }
      });
    });
});