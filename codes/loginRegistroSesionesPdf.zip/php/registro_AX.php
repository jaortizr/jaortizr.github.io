<?php
  $boleta = $_REQUEST["boleta"];
  $nombre = $_REQUEST["nombre"];
  $primerApe = $_REQUEST["primerApe"];
  $segundoApe = $_REQUEST["segundoApe"];
  $contrasena = md5($_REQUEST["contrasena"]);

  $respAX = [];
  $hoy = date("j M Y / h:i:s");

  $conexion = mysqli_connect("localhost", "root", "", "sem20251");
  $sqlCheckBoleta = "SELECT * FROM alumno WHERE boleta = '$boleta'";
  $resCheckBoleta = mysqli_query($conexion, $sqlCheckBoleta);
  if(mysqli_num_rows($resCheckBoleta) == 0){
    $sql = "INSERT INTO alumno VALUES('$boleta','$nombre','$primerApe','$segundoApe', '$contrasena')";
    $resultado = mysqli_query($conexion, $sql); 
    if(mysqli_affected_rows($conexion) == 1){
      $respAX["cod"] = 1;
      $respAX["msj"] = "Se registró correctamente tu información";
      $respAX["icono"] = "success";
      $respAX["extra"] = $hoy;
    }else{  
      $respAX["cod"] = 0;
      $respAX["msj"] = "Favor de intentarlo nuevamente";
      $respAX["icono"] = "error";
      $respAX["extra"] = $hoy;
    }
  }else{
    $respAX["cod"] = 2;
    $respAX["msj"] = "La boleta ya está registrada";
    $respAX["icono"] = "error";
    $respAX["extra"] = $hoy;
  }

  echo json_encode($respAX);
?>