<?php
  session_start();

  include("mpdfV8/vendor/autoload.php");

  $conexion = mysqli_connect("localhost", "root", "", "sem20251");
  $boleta = $_SESSION["boleta"];
  $sqlGetAlumno = "SELECT * FROM alumno WHERE boleta = '$boleta'";
  $resGetAlumno = mysqli_query($conexion, $sqlGetAlumno);
  $infGetAlumno = mysqli_fetch_row($resGetAlumno);

  $mpdf = new \Mpdf\Mpdf([
    "orientation"=>"P",
    "format"=>"Letter",
    "default_font_size"=>14
  ]);

  $footer = "
    <table width='100%'>
      <tr>
        <td width='33%'>{DATE j-m-Y}</td>
        <td width='33%' align='center'>{PAGENO}/{nbpg}</td>
        <td width='33%' style='text-align: right;'>TDAW</td>
      </tr>
    </table>
  ";

  $html = "
    <h1>Reporte</h1>
    <p>
      Hola <b>$infGetAlumno[1] $infGetAlumno[2] $infGetAlumno[3]</b> <br>
      Tu numero de boleta es: <b>$infGetAlumno[0]</b> <br>
      Tu contraseña es: <b>$infGetAlumno[4]</b>
    </p>
  ";

  $mpdf->SetWatermarkText("TDAW",0.1);
  $mpdf->showWatermarkText = true;

  $mpdf->WriteHTML($html);
  $mpdf->SetHTMLFooter($footer);
  $mpdf->Output();

?>