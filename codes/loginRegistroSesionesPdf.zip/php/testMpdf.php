<?php

  include("mpdfV8/vendor/autoload.php");

  $mpdf = new \Mpdf\Mpdf([
    "orientation"=>"P",
    "format"=>"Letter",
    "default_font_size"=>14
  ]);

  $estilos = "
    <style>
      p{color:blue; text-align:justify}
    </style>
  ";

  $html = "
    $estilos
    <h1>PDFs con mPDF</h1>
    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quam quae illum exercitationem autem, odio ipsa, ut ullam laboriosam laborum non asperiores. Architecto explicabo repudiandae, est magni repellat consectetur rem earum dolore? Dolorem ipsa aut optio ullam quos porro quo non assumenda similique, libero at cumque provident saepe amet nobis eos a consequuntur voluptates fuga magni? Eius quam ad corporis cum repudiandae, laudantium fugiat nulla earum. Excepturi asperiores numquam libero non maiores quibusdam placeat! Rem dicta exercitationem repellat distinctio pariatur nostrum nulla quia. Doloremque nisi impedit, facilis odit alias assumenda iste minima, non quas pariatur architecto, exercitationem corporis? Hic, voluptatibus aperiam.</p>
    <p><a href='https://www.escom.ipn.mx'>Web ESCOM</a></p>
    <table width='100%'>
      <thead>
        <tr>
          <th>Boleta</th>
          <th>Nombre</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>2005630001</td>
          <td>Juan Perez Perez</td>
        </tr>
        <tr>
          <td>2025630002</td>
          <td>Diana Cazadora Cazadora</td>
        </tr>
      </tbody>
    </table>
    <form>
      <label for='boleta'>Boleta</label>
      <input type='text' id='boleta' name='boleta'>
    </form>
  ";

 
  $mpdf->WriteHTML($html);
  $mpdf->Output();

?>

