<?php
  session_start();

  $boleta = $_REQUEST["boleta"];
  $contrasena = md5($_REQUEST["contrasena"]);

  $respAX = [];
  $hoy = date("j M Y / h:i:s");

  $conexion = mysqli_connect("localhost", "root", "", "sem20251");
  $sqlCheckAlumno = "SELECT * FROM alumno WHERE boleta = '$boleta' AND contrasena = '$contrasena'";
  $resCheckAlumno = mysqli_query($conexion, $sqlCheckAlumno);
  if(mysqli_num_rows($resCheckAlumno) == 1){
    $_SESSION["boleta"] = $boleta;
    $respAX["cod"] = 1;
    $respAX["msj"] = "Bienvenido :)";
    $respAX["icono"] = "success";
    $respAX["extra"] = $hoy;
  }else{
    $respAX["cod"] = 0;
    $respAX["msj"] = "Error. Favor de intentarlo nuevamente";
    $respAX["icono"] = "error";
    $respAX["extra"] = $hoy;
  }

  echo json_encode($respAX);
?>

