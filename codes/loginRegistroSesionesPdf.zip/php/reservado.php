<?php
  session_start();
  if(isset($_SESSION["boleta"])){
    require("./reservado_BD.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="./../bootstrap-5.0.2/css/bootstrap.min.css" rel="stylesheet">
  <script src="./../bootstrap-5.0.2/js/bootstrap.min.js"></script>
  <script src="./js/../jquery.min.js"></script>
  <title>Alumnos. Reservado</title>
</head>
<body>

  <header>
    <img src="./../imgs/headerMain.jpg" class="img-fluid">
  </header>
  <main class="mt-5 mb-5">
    <div class="container">
      <div class="row">
        <h2>Área reservada...</h2>
      </div>
      <div class="row">
        <h3>Bienvenido <?php echo $infGetAlumno[2]; ?></h3>

        <p><a href="./reporte.php">Reporte PDF</a></p>

        
        <p><a href="./cerrarSesion.php?nombreSesion=boleta">Cerrar sesión</a></p>
      </div>
    </div> <!-- //container-->
  </main>
  <footer class="fixed-bottom text-center">
    <p><b>&COPY; Copyright. Todos los derechos reservados. 2024.</b></p>
  </footer>

</body>
</html>
<?php
  }else{
    header("location:./../");
  }
?>