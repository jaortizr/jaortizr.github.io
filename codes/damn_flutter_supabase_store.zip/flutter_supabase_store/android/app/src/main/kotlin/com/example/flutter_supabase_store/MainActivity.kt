package com.example.flutter_supabase_store

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
