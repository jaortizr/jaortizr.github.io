import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class StoragePage extends StatefulWidget {
  const StoragePage({super.key});

  @override
  State<StoragePage> createState() => _StoragePageState();
}

class _StoragePageState extends State<StoragePage> {
  final supabase = Supabase.instance.client;
  String? imageUrl;

  Future<void> _pickAndUploadImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.camera);

    if (pickedFile != null) {
      final file = File(pickedFile.path);
      final fileName = 'imagenes/${DateTime.now().millisecondsSinceEpoch}.jpg';

      try {
        // Subir archivo al bucket "imagenes"
        await supabase.storage.from('imagenes').upload(fileName, file);

        // Obtener URL pública
        final url = supabase.storage.from('imagenes').getPublicUrl(fileName);

        setState(() {
          imageUrl = url;
        });
      } catch (e) {
        print('Error al subir imagen: $e');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Supabase Storage')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            imageUrl == null
                ? const Text('No hay imagen seleccionada')
                : Image.network(imageUrl!),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _pickAndUploadImage,
              child: const Text('Subir Imagen'),
            ),
          ],
        ),
      ),
    );
  }
}