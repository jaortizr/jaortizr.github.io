# flutter_supabase_store

A new Flutter project.
