package com.example.statefulwidget

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
