import 'package:flutter/material.dart';

class Ejemplo2 extends StatefulWidget {
  const Ejemplo2({super.key});

  @override
  State<Ejemplo2> createState() => _Ejemplo2State();
}

class _Ejemplo2State extends State<Ejemplo2> {
  int b1 = 0;
  int b2 = 0;
  int b3 = 0;
  int total = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("StatefulWidget - E2"),
        backgroundColor: Colors.blueGrey,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextButton(
              onPressed: (){
                b1++;
                total++;
                setState(() {});
              },
              child: Text("Boton 1: $b1")
            ),
            SizedBox(height: 10,),
            TextButton(
              onPressed: (){
                setState(() {
                  b2++;
                  total++;
                });
              },
              child: Text("Boton 2: $b2")
            ),
            SizedBox(height: 10,),
            TextButton(
              onPressed: (){
                setState(() {
                  b3++;
                  total++;
                });
              },
              child: Text("Boton 3: $b3")
            ),
            SizedBox(height: 10,),
            Text("Total: $total"),
            SizedBox(height: 10,),
            Divider(
              thickness: 2,
            ),
            TextButton(
              style: TextButton.styleFrom(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(0)
                ),
                backgroundColor: Colors.orange,
                foregroundColor: Colors.white,
              ),
              onPressed: (){
                setState(() {
                  b1 = b2 = b3 = total = 0;
                });
              },
              child: Text(("Reset"))
            )
          ],
        ),
      ),
    );
  }
}