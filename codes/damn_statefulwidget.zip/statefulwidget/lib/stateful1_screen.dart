import 'package:flutter/material.dart';

class Ejemplo1 extends StatefulWidget {
  const Ejemplo1({super.key});

  @override
  State<Ejemplo1> createState() => _Ejemplo1State();
}

class _Ejemplo1State extends State<Ejemplo1> {
  double ancho = 10;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("StatefulWidget - E1"),
        backgroundColor: Colors.blue,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("$ancho"),
            SizedBox(height: 15,),
            Container(
              color: Colors.black,
              height: 50,
              width: ancho,
            ),
            SizedBox(
              height: 15,
            ),
            TextButton(
              onPressed: (){
                ancho += 10;
                setState((){           
                });
              },
              child: Text("Aumentar")
            ),
          ],
        ),
      ),
    );
  }
}