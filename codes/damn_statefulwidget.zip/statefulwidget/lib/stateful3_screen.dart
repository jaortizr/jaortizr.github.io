import 'package:flutter/material.dart';
import 'dart:math';

class Ejemplo3 extends StatefulWidget {
  const Ejemplo3({super.key});

  @override
  State<Ejemplo3> createState() => _Ejemplo3State();
}

class _Ejemplo3State extends State<Ejemplo3> {
  double ancho = 400;

  void aumentarAncho(int valor){
    setState(() {
      ancho += valor;
    });
  }

  void disminuirAncho(int valor){
    ancho -= valor;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("StatefulWidget - E3"),
        backgroundColor: Colors.lightBlue,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              color: Colors.black,
              height: 20,
              width: ancho,
              child: Text("$ancho", style: TextStyle(color: Colors.red),),
            ),
            SizedBox(height: 10,),
            UnBoton(aumentarContador: disminuirAncho)
          ],
        ),
      ),
    );
  }
}

class UnBoton extends StatelessWidget {
  Function aumentarContador;

  // ignore: use_super_parameters
  UnBoton({super.key, required this.aumentarContador});

  @override
  Widget build(BuildContext context) {
    return TextButton(
      onPressed: (){
        aumentarContador(20);
      },
      child: Text(Random().nextInt(10).toString())
    );
  }
}