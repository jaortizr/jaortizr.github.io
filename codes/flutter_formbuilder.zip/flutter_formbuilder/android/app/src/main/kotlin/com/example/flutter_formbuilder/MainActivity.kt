package com.example.flutter_formbuilder

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
