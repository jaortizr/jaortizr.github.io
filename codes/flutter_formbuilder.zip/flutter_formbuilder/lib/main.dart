import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:form_builder_validators/form_builder_validators.dart';


void main() => runApp(MyApp());

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  String mensaje = "";
  final GlobalKey<FormBuilderState> _formKey = GlobalKey<FormBuilderState>();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(title: Text("Form Builder - Flutter"), backgroundColor: Colors.blue,centerTitle: true),
        body: Padding(
          padding: const EdgeInsets.all(20.0),
          child: FormBuilder(
            key: _formKey,
            child: Column(
              children: [
                FormBuilderTextField(
                  name: 'email',
                  decoration: const InputDecoration(labelText: 'Email'),
                  validator: FormBuilderValidators.compose([
                    FormBuilderValidators.required(errorText: "Falta tu correo electrónico"),
                    FormBuilderValidators.email(errorText: "El formato es incorrecto")
                  ]),
                ),
                const SizedBox(height: 10),
                FormBuilderDropdown(
                  name: 'genero',
                  decoration: const InputDecoration(labelText: 'Género'),
                  items: ['Masculino', 'Femenino', 'Otro'].map(
                    (genero) => DropdownMenuItem(value: genero, child: Text(genero))
                  ).toList(),
                  validator: FormBuilderValidators.compose([
                    FormBuilderValidators.required(errorText: "Falta tu género")
                  ])
                ),
                const SizedBox(height: 10),
                FormBuilderDateTimePicker(
                  name: 'cumpleanos',
                  decoration: const InputDecoration(labelText: 'Cumpleaños'),
                  inputType: InputType.date,
                  initialDate: DateTime.now(),
                  initialValue: DateTime.now(),
                  firstDate: DateTime(2000),
                  lastDate: DateTime.now(),
                  validator: FormBuilderValidators.compose([
                    FormBuilderValidators.required(errorText: "Falta la fecha de tu cumpleaños"),
                    FormBuilderValidators.dateTime()
                  ]),
                ),
                const SizedBox(height: 10),
                FormBuilderCheckbox(
                  name: 'tyc',
                  title: const Text("Acepto terminos y condiciones"),
                  initialValue: false,
                  onChanged: (bool? value) {}
                ),
                const SizedBox(height: 20.0),
                ElevatedButton(
                  onPressed: () {
                    if (_formKey.currentState!.saveAndValidate()) {
                      mensaje = _formKey.currentState!.value["email"];
                      setState((){});
                    }
                  },
                  child: const Text('Submit'),
                ),
              ],
            ),
          ),
        ),
        bottomNavigationBar: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(mensaje)
          ],
        )
      ),
    );
  }
}