import 'package:flutter/material.dart';
void main() {
  runApp(const MyApp());
}

// ----- Version 1. Uso de Navigator.push() y Navigator.pop() ----- //

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "Navigator Routes",
      home:Pantalla1()
    );
  }
}

class Pantalla1 extends StatelessWidget {
  const Pantalla1({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Pantalla 1"),
        centerTitle: true
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: (){
            Navigator.push(context,
            MaterialPageRoute(builder: (context) => const Pantalla2(parametro: "Mensaje desde la Pantalla 1")));
          },
          child: const Text("Ir a Pantalla 2"))
      ),
    );
  }
}

class Pantalla2 extends StatelessWidget {
  final String parametro;
  const Pantalla2({super.key, required this.parametro});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Pantalla 2"),
        centerTitle: true
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(parametro),
            ElevatedButton(
              onPressed: (){
                Navigator.pop(context);
              },
              child: const Text("Regresar a Pantalla 1")
            )
          ]
        )
      )
    );
  }
}




// ----- Version 2. Rutas nombradas. mediante la definición del argumento routes de MaterialApp() ----- //

// class MyApp extends StatelessWidget {
//   const MyApp({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       title: "Navigator Routes",
//       initialRoute: "/",
//       routes: {
//         "/": (context) => const Pantalla1(),
//         "/pantalla2": (context) => const Pantalla2()
//       }
//     );
//   }
// }

// class Pantalla1 extends StatelessWidget {
//   const Pantalla1({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text("Pantalla 1"),
//         centerTitle: true
//       ),
//       body: Center(
//         child: ElevatedButton(
//           onPressed: (){
//             Navigator.pushNamed(context, "/pantalla2", arguments: "Mensaje desde la Pantalla 1b");
//           },
//           child: const Text("Ir a Pantalla 2"))
//       ),
//     );
//   }
// }

// class Pantalla2 extends StatelessWidget {

//   const Pantalla2({super.key});

//   @override
//   Widget build(BuildContext context) {
//     final argumento = ModalRoute.of(context)!.settings.arguments as String;
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text("Pantalla 2"),
//         centerTitle: true
//       ),
//       body: Center(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             Text(argumento),
//             ElevatedButton(
//               onPressed: (){
//                 Navigator.pop(context);
//               },
//               child: const Text("Regresar a Pantalla 1")
//             )
//           ]
//         )
//       )
//     );
//   }
// }




// ----- Version 3. Paso de datos más estructurados entre pantallas ----- //

// class MyApp extends StatelessWidget {
//   const MyApp({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       title: "Navigator Routes",
//       initialRoute: "/",
//       routes: {
//         "/": (context) => const Pantalla1(),
//         "/pantalla2": (context) => const Pantalla2(),
//         ExtraerArgumentosPantalla.routeName: (context) => const ExtraerArgumentosPantalla()
//       }
//     );
//   }
// }

// class ArgumentosPantalla{
//   final String title;
//   final String message;

//   ArgumentosPantalla(this.title, this.message);
// }

// class ExtraerArgumentosPantalla extends StatelessWidget {
//   static const routeName = "/extraerArgumentos";
//   const ExtraerArgumentosPantalla({super.key});

//   @override
//   Widget build(BuildContext context) {
//     final args = ModalRoute.of(context)!.settings.arguments as ArgumentosPantalla;
//     return Scaffold(
//       appBar: AppBar(
//         title: Text(args.title),
//       ),
//       body: Center(
//         child: Text(args.message),
//       )
//     );
//   }
// }

// class Pantalla1 extends StatelessWidget {
//   const Pantalla1({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text("Pantalla 1"),
//         centerTitle: true
//       ),
//       body: Center(
//         child: ElevatedButton(
//           onPressed: (){
//             Navigator.pushNamed(
//               context,
//               ExtraerArgumentosPantalla.routeName,
//               arguments: ArgumentosPantalla("IPN", "Instituto Politécnico Nacional")
//             );
//           },
//           child: const Text("Ir a Pantalla 2 - Extraer Argumentos"))
//       ),
//     );
//   }
// }

// class Pantalla2 extends StatelessWidget {

//   const Pantalla2({super.key});

//   @override
//   Widget build(BuildContext context) {
//     final argumento = ModalRoute.of(context)!.settings.arguments as String;
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text("Pantalla 2"),
//         centerTitle: true
//       ),
//       body: Center(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             Text(argumento),
//             ElevatedButton(
//               onPressed: (){
//                 Navigator.pop(context);
//               },
//               child: const Text("Regresar a Pantalla 1")
//             )
//           ]
//         )
//       )
//     );
//   }
// }


