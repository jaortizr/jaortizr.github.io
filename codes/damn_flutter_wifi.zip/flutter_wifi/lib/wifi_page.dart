import 'package:flutter/material.dart';
import 'package:wifi_scan/wifi_scan.dart';
import 'package:permission_handler/permission_handler.dart';

class WifiPage extends StatefulWidget {
  const WifiPage({super.key});

  @override
  State<WifiPage> createState() => _WifiPageState();
}

class _WifiPageState extends State<WifiPage> {
  List<WiFiAccessPoint> _networks = [];

  Future<void> _scanNetworks() async {
    // Solicitar permisos de ubicación (necesarios en Android 10+)
    var status = await Permission.location.request();
    if (status.isGranted) {
      final canScan = await WiFiScan.instance.canStartScan();
      if (canScan == CanStartScan.yes) {
        await WiFiScan.instance.startScan();
        final results = await WiFiScan.instance.getScannedResults();
        setState(() {
          _networks = results;
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("No se puede iniciar el escaneo")),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Permiso de ubicación denegado")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Escaneo de WiFi')),
      body: Column(
        children: [
          ElevatedButton(
            onPressed: _scanNetworks,
            child: const Text('Escanear redes WiFi'),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _networks.length,
              itemBuilder: (context, index) {
                final net = _networks[index];
                return ListTile(
                  title: Text(net.ssid.isNotEmpty ? net.ssid : "<SSID oculto>"),
                  subtitle: Text("BSSID: ${net.bssid} | Nivel: ${net.level} dBm"),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}