package com.example.notes_app_supabase

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
