package com.example.flutter_gps

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
