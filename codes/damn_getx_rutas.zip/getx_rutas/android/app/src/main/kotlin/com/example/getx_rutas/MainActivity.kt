package com.example.getx_rutas

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
