import 'package:flutter/material.dart';

class IIA extends StatelessWidget {
  const IIA({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("IIA"), backgroundColor: Colors.purple, foregroundColor: Colors.white,),
      body: Center(
        child: Column(children: [
          TextButton(
            onPressed: (){}, 
            child: Text("inicio")
          )
        ]),
      ),
    );
  }
}