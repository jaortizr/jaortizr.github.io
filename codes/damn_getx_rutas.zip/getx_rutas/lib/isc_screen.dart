import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ISC extends StatelessWidget {
  const ISC({super.key});

  @override
  Widget build(BuildContext context) {
    final Map<String, dynamic> argumentos = Get.arguments;

    return Scaffold(
      appBar: AppBar(title: Text(argumentos["titulo"]), backgroundColor: Colors.blue, foregroundColor: Colors.white,),
      body: Center(
        child: Column(children: [
          IconButton(
            onPressed: (){
              Get.snackbar("ESCOM", "Desarrollo de Aplicacions Móviles Nativas - 20261", backgroundColor: Colors.blue, snackPosition: SnackPosition.BOTTOM, snackStyle: SnackStyle.FLOATING);
            },
            icon: Icon(Icons.message)
          ),
          SizedBox(height: 10,),
          IconButton(
            onPressed: (){
              Get.defaultDialog(title: "ESCOM", middleText: "Desarrollo de Aplicaciones Móviles Nativas - 20261");
            },
            icon: Icon(Icons.messenger_outline)
          ),
          SizedBox(height: 10,),
          IconButton(
            onPressed: (){
              Get.changeTheme(ThemeData.dark());
            },
            icon: Icon(Icons.dark_mode)
          ),
          SizedBox(height: 10,),
          TextButton(
            onPressed: (){
              Get.offNamed("/");
            }, 
            child: Text("inicio")
          )
        ]),
      ),
    );
  }
}