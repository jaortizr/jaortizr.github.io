import 'package:flutter/material.dart';

class LCD extends StatelessWidget {
  const LCD({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("LCD"), backgroundColor: Colors.green, foregroundColor: Colors.white,),
      body: Center(
        child: Column(children: [
          TextButton(
            onPressed: (){}, 
            child: Text("inicio")
          )
        ]),
      ),
    );
  }
}