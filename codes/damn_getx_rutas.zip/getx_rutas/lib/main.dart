import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:getx_rutas/iia_screen.dart';
import 'package:getx_rutas/inicio_screen.dart';
import 'package:getx_rutas/isc_screen.dart';
import 'package:getx_rutas/lcd_screen.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: GetMaterialApp(
        debugShowCheckedModeBanner: false,
        initialRoute: "/",
        getPages: [
          GetPage(name: "/", page: ()=>Inicio(), transition: Transition.downToUp),
          GetPage(name: "/ISC", page: ()=>ISC(), transition: Transition.leftToRight),
          GetPage(name: "/IIA", page: ()=>IIA()),
          GetPage(name: "/LCD", page: ()=>LCD())  
        ],
      ),
    );
  }
}
