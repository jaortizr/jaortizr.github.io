# getx_rutas

A new Flutter project.
