<?php
  sleep(3);
  echo $_POST["correo"];
?>