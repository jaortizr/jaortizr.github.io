package com.example.flutter_json_local

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
