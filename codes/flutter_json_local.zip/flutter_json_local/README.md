# flutter_json_local

A new Flutter project.
