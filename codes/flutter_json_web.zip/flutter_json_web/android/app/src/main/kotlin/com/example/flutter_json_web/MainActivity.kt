package com.example.flutter_json_web

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
