import 'package:flutter'

class FormularioScreen extends StatefulWidget {
  const FormularioScreen({super.key});

  @override
  State<FormularioScreen> createState() => _FormularioScreenState();
}

class _FormularioScreenState extends State<FormularioScreen> {
  final formKey = GlobalKey<FormState>();
  
  final inputContrasena = TextEditingController();
  String boleta = "";
  String correo = "";
  String escuela = "";
  bool hrsExtra = false;
  bool alumnoRegular = false;
  String sexo = "H";

  void submitForm(){
    if(formKey.currentState!.validate()){
      formKey.currentState!.save();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Procesando...")
        )
      );
      setState((){ });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Formualarios"),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Form(
            key: formKey,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  TextFormField(
                    decoration: InputDecoration(labelText: "Boleta"),
                    validator:(value) {
                      if(value!.isEmpty){
                        return "Falta tu boleta";
                      }
                      return null;
                    },
                    onSaved: (newValue) {
                      boleta = newValue!;
                    },
                  ),
                  SizedBox(height: 10,),
                  TextFormField(
                    decoration: InputDecoration(labelText: "Correo"),
                    validator: (value) {
                      if(value!.isEmpty){
                        return "Falta tu correo electrónico";
                      }
                      return null;
                    },
                    onSaved: (newValue) {
                      correo = newValue!;
                    },
                  ),
                  SizedBox(height: 20,),
                  TextFormField(
                    decoration: InputDecoration(
                      labelText: "Contraseña",
                      suffixIcon: IconButton(
                        onPressed: (){
                          inputContrasena.clear();
                        },
                        icon: Icon(Icons.close)
                      )
                    ),
                    obscureText: true,
                    controller: inputContrasena,
                  ),
                  SizedBox(height: 20,),
                  DropdownButton(
                    value: escuela,
                    items: [
                      DropdownMenuItem(value: "",child: Text("--SELECCIONAR--"),),
                      DropdownMenuItem(value: "ESCOM",child: Text("ESCOM"),),
                      DropdownMenuItem(value: "UPIITA",child: Text("UPIITA"),),
                      DropdownMenuItem(value: "ESIAZ",child: Text("ESIA-Z"),),
                    ],
                    onChanged:(value){
                      escuela = value!;
                      setState(() {});
                    },
                  ),
                  SizedBox(height: 20,),
                  ElevatedButton(
                    onPressed: (){
                      submitForm();
                    }, 
                    child: Text("Enviar")
                  ),
                  SizedBox(height: 20,),
                  CheckboxListTile(
                    title: Text("Horas extras"),
                    value: hrsExtra,
                    onChanged:(value) {
                      hrsExtra = value!;
                      setState(() {});
                    },
                  ),
                  SizedBox(height: 20,),
                  SwitchListTile(
                    title: Text("Alumno regular"),
                    value: alumnoRegular,
                    onChanged:(value) {
                      alumnoRegular = value;
                      setState((){});
                    },
                  ),
                  SizedBox(height: 20,),
                  RadioGroup(
                    groupValue: sexo,
                    onChanged: (value) {
                      sexo = value!;
                      setState(() {});
                    },
                    child: Column(
                      children: [
                        RadioListTile(
                          title: Text("Mujer"),
                          value: "M",
                        ),
                        RadioListTile(
                          title: Text("Hombre"),
                          value: "H",
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 20,),
                  CalendarDatePicker(
                    initialDate: DateTime(2025, 10, 29),
                    firstDate: DateTime(2020),
                    lastDate: DateTime(2030),
                    onDateChanged:(value) {
                      
                    },
                  ),
                  SizedBox(height: 20,),
                  Text("$boleta & $correo")
                ],
                      ),
            ),),
        ),
      ),
    );
  }
}