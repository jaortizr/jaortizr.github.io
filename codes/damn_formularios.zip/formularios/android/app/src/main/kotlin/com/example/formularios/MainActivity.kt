package com.example.formularios

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
