package com.example.login_registro_formbuilder

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
