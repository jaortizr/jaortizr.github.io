import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:form_builder_validators/form_builder_validators.dart';

class FormScreen extends StatefulWidget {
  const FormScreen({super.key});

  @override
  State<FormScreen> createState() => _FormScreenState();
}

class _FormScreenState extends State<FormScreen> {
  final GlobalKey<FormBuilderState> formBuilderKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("DAMN - 20261"),
        backgroundColor: Colors.purple,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Center(
          child: FormBuilder(
            key: formBuilderKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                FormBuilderTextField(
                  name: "correo",
                  decoration: InputDecoration(labelText: "Correo"),
                  validator: FormBuilderValidators.compose([
                    FormBuilderValidators.required(
                      errorText: "Falta tu correo"
                    ),
                    FormBuilderValidators.email(
                      errorText: "No es un formato de correo correcto"
                    )
                  ]),
                ),
                SizedBox(height: 20,),
                FormBuilderDropdown(
                  name: "genero",
                  items: ["Masculino", "Femenino", "Otro"].map(
                    (e) => DropdownMenuItem(
                      value: e,
                      child: Text(e)
                    )
                  ).toList(),
                  validator: FormBuilderValidators.compose([
                    FormBuilderValidators.required(
                      errorText: "Debes indicar tu género"
                    )
                  ]),
                ),
                SizedBox(height: 20,),
                FormBuilderDateTimePicker(
                  name: "fechaNacimiento",
                  decoration: InputDecoration(labelText: "Fecha de nacimiento"),
                  inputType: InputType.date,
                  initialDate: DateTime.now(),
                  initialValue: DateTime.now(),
                  firstDate: DateTime(2024),
                  lastDate: DateTime.now(),
                  validator: FormBuilderValidators.compose([
                    FormBuilderValidators.required(
                      errorText: "Falta la fecha de tu cumpleaños"
                    )
                  ]),
                ),
                SizedBox(height: 20,),
                ElevatedButton(
                  onPressed: (){
                    if(formBuilderKey.currentState!.saveAndValidate()){
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text("${formBuilderKey.currentState!.value.entries.toList()}"),
                          duration: Duration(seconds: 5),
                        )
                      );
                    }
                  }, 
                  child: Text("Enviar")
                )
              ],
            )
          ),
        ),
      ),
    );
  }
}