import 'package:flutter/material.dart';
import 'package:login_registro/login_screen.dart';
import 'package:login_registro/registro_screen.dart';
import 'package:login_registro/usuario_screen.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: "/login",
      routes: {
        "/login":(context) => LoginScreen(),
        "/registro":(context) => RegistroScreen(),
        "/usuario":(context) => UsuarioScreen()
      },
    );
  }
}
