import 'package:flutter/material.dart';

class RegistroScreen extends StatefulWidget {
  const RegistroScreen({super.key});

  @override
  State<RegistroScreen> createState() => _RegistroScreenState();
}

class _RegistroScreenState extends State<RegistroScreen> {
  final GlobalKey<FormState> formRegistroKey = GlobalKey();
  String nombre = "";
  String apellidos = "";
  String boleta = "";
  String contrasena = "";

  void submitForm(){
    if(formRegistroKey.currentState!.validate()){
      formRegistroKey.currentState!.save();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            "Gracias se han registrado sus datos :)",
            style: TextStyle(color: Colors.white),  
          ),
          backgroundColor: Colors.purple,
          duration: Duration(seconds: 10),
          action: SnackBarAction(
            label: "Login ", 
            onPressed: (){
              Navigator.popAndPushNamed(context, "/login");
            }
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(("DAMN - 20261")),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(20),
          child: Form(
            key: formRegistroKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                TextFormField(
                  decoration: InputDecoration(labelText: "Nombre"),
                  validator: (value) {
                    if(value!.isEmpty){
                      return "Falta tu nombre";
                    }else{
                      return null;
                    }
                  },
                  onSaved: (newValue) {
                    nombre = newValue!;
                  },
                ),
                SizedBox(height: 20,),
                TextFormField(
                  decoration: InputDecoration(labelText: "Apellidos"),
                  validator: (value) {
                    if(value!.isEmpty){
                      return "Faltan tus apellidos";
                    }else{
                      return null;
                    }
                  },
                  onSaved: (newValue) {
                    apellidos = newValue!;
                  },
                ),
                SizedBox(height: 20,),
                TextFormField(
                  decoration: InputDecoration(labelText: "Boleta"),
                  validator: (value) {
                    if(value!.isEmpty){
                      return "Falta tu boleta";
                    }else{
                      return null;
                    }
                  },
                  onSaved: (newValue) {
                    boleta = newValue!;
                  },
                ),
                SizedBox(height: 20,),
                TextFormField(
                  decoration: InputDecoration(labelText: "Contraseña"),
                  validator: (value) {
                    if(value!.isEmpty){
                      return "Falta tu contraseña";
                    }else{
                      return null;
                    }
                  },
                  onSaved: (newValue) {
                    contrasena = newValue!;
                  },
                  obscureText: true,
                ),
                SizedBox(height: 20,),
                ElevatedButton(
                  onPressed: (){
                    submitForm();
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    foregroundColor: Colors.white
                  ),
                  child: Text("Registrar"),
                )
              ],
            )
          ),
        ),
      ),
    );
  }
}