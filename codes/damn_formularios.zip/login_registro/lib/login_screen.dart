import 'package:flutter/material.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final GlobalKey<FormState> formLoginKey = GlobalKey();
  String boleta = "";
  final contrasenaTxtCtrl = TextEditingController();
  bool txtObscuro = true;

  void submitForm(){
    if(formLoginKey.currentState!.validate()){
      formLoginKey.currentState!.save();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(
          "Enviando datos para autenticar ($boleta - ${contrasenaTxtCtrl.text})", 
          style: TextStyle(
            color: Colors.white
          ),
        ),
        duration: Duration(seconds: 5),
        backgroundColor: Colors.purple,
        action: SnackBarAction(
          label: "Continuar",
          onPressed:() => Navigator.popAndPushNamed(context, "/usuario"),
        ),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("DAMN - 20261"),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(16),
          child: Form(
            key: formLoginKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                TextFormField(
                  decoration: InputDecoration(
                    labelText: "Boleta",
                    prefixIcon: Icon(Icons.perm_identity)
                  ),
                  validator: (value) {
                    if(value!.isEmpty){
                      return "Falta tu número de boleta";
                    }else{
                      return null;
                    }
                  },
                  onSaved: (newValue) {
                    boleta = newValue!;
                  },
                ),
                SizedBox(height: 20,),
                TextFormField(
                  decoration: InputDecoration(
                    labelText: "Contraseña",
                    suffixIcon: IconButton(
                      onPressed: (){
                        //contrasenaTxtCtrl.clear();
                        txtObscuro = !txtObscuro;
                        setState(() {});
                      },
                      icon: Icon(txtObscuro?Icons.visibility : Icons.visibility_off)
                    )
                  ),
                  validator: (value) {
                    if(value!.isEmpty){
                      return "Falta tu contraseña";
                    }else{
                      return null;
                    }
                  },
                  obscureText: txtObscuro,
                  controller: contrasenaTxtCtrl,
                ),
                SizedBox(height: 20,),
                ElevatedButton(
                  onPressed: (){
                    submitForm();
                  },
                  child: Text("Entrar")
                ),
                SizedBox(height: 15,),
                ElevatedButton(
                  onPressed: (){
                    formLoginKey.currentState!.reset();
                  },
                  child: Text("Limpiar")
                ),
                TextButton(
                  onPressed: (){
                    Navigator.popAndPushNamed(context, "/registro");
                  },
                  child: Text("Crear cuenta")
                )
              ],
            )
          ),
        ),
      ),
    );
  }
}