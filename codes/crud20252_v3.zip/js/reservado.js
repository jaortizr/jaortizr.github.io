$(document).ready(()=>{
  $.ajax({
    url:"./reservado_BD.php",
    method:"post",
    cache:"false",
    success:(respAX)=>{
      let objAX_selAlumnos = JSON.parse(respAX);
      let alumnos = objAX_selAlumnos.data;
      console.log(alumnos);
      let filasAlumnos = "";
      alumnos.forEach((elemento) => {
        filasAlumnos += `
          <li>${elemento.boleta}</li>
        `;
      });
      console.log(filasAlumnos);
      $("div#respAX").html(filasAlumnos);
    }
  });
});