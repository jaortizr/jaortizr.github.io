<?php
  include("./configBD.php");

  $respAX = [];
  $infAlumnos = [];
  $sqlSelAlumno = "SELECT * FROM alumno";
  $resSelAlumno = mysqli_query($conexion, $sqlSelAlumno);
  while($fila = mysqli_fetch_assoc($resSelAlumno)){
    $infAlumnos[] = $fila;
  }

  $respAX["code"] = 1;
  $respAX["data"] = $infAlumnos;

  echo json_encode($respAX);

?>