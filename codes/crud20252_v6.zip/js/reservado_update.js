$(document).ready(()=>{
  let boleta = sessionStorage.getItem("boleta");
  
  $.ajax({
    url:"reservado_update_BD.php",
    method:"post",
    data:{boleta:boleta},
    cache:false,
    success:(respAX)=>{
      console.log(respAX);
      let objAXAlumno = JSON.parse(respAX);
      $("#correo").val(objAXAlumno.data.correo);
      $("#boleta").val(objAXAlumno.data.boleta);
    }
  });

  const validarFormUpdate = new JustValidate("#formUpdate",{
    errorFieldCssClass:"is-invalid",
    successFieldCssClass:"is-valid"
  });
  validarFormUpdate
  .addField("#correo",[
    {
      rule:"required",
      errorMessage:"Falta tu correo electrónico"
    },
    {
      rule:"email",
      errorMessage:"No es el formato correcto"
    }
  ])
  .onSuccess(()=>{
    $.ajax({
      url:"./reservado_update_AX.php",
      type:"post",
      data:$("#formUpdate").serialize(),
      cache:false,
      success:(respAX)=>{
        console.log(respAX);
        let objAXUpdAlumno = JSON.parse(respAX);
        swal.fire({
          title:"TDAW - 20252",
          text:objAXUpdAlumno.msj,
          icon:objAXUpdAlumno.icono,
          footer:objAXUpdAlumno.log,
          didDestroy:()=>{
            if(objAXUpdAlumno.code == 1){
              window.location.href = "./reservado.php";
            }else{
              window.location.reload();
            }
          }
        });
      }
    });
  });
});