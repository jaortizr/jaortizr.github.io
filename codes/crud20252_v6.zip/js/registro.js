$(document).ready(()=>{
  const validarFormRegistro = new JustValidate("#formRegistro",{
    errorFieldCssClass:"is-invalid",
    successFieldCssClass:"is-valid"
  });
  validarFormRegistro
  .addField("#boleta",[
    {
      rule:"required",
      errorMessage:"Falta tu boleta"
    }
  ])
  .addField("#nombre",[
    {
      rule:"required",
      errorMessage:"Falta tu nombre"
    }
  ])
  .addField("#apellidos",[
    {
      rule:"required",
      errorMessage:"Faltan tus apellidos"
    }
  ])
  .addField("#fechaNacimiento",[
    {
      rule:"required",
      errorMessage:"Falta tu fecha de cumpleaños"
    }
  ])
  .addField("#correo",[
    {
      rule:"required",
      errorMessage:"Falta tu correo"
    }
  ])
  .addField("#contrasena",[
    {
      rule:"required",
      errorMessage:"Falta tu contraseña"
    }
  ])
  .onSuccess(()=>{
    $.ajax({
      url:"./../php/registro_AX.php",
      method:"post",
      data:$("#formRegistro").serialize(),
      cache:false,
      success:(respAX)=>{
        console.log(respAX);
        let objAX = JSON.parse(respAX);
        Swal.fire({
          title:"TDAW 20252",
          text:objAX.msj,
          icon:objAX.icono,
          footer:objAX.log,
          didDestroy:()=>{
            if(objAX.code == 1){
              window.location.href = "./../index.html"
            }else{
              window.location.reload();
            }
          }
        });
      }
    })
  })
});