<?php
  include("./libs/fpdf.php");
  include("./configBD.php");

  $boleta = $_REQUEST["boleta"];
  $sqlGetAlumnoPDF = "SELECT * FROM alumno WHERE boleta = '$boleta'";
  $resGetAlumnoPDF = mysqli_query($conexion, $sqlGetAlumnoPDF);
  $infGetAlumnoPDF = mysqli_fetch_assoc($resGetAlumnoPDF);


  $pdf = new FPDF();
  $pdf->AddPage();
  $pdf->SetFont('Arial','B',16);
  $pdf->MultiCell(40,10, $infGetAlumnoPDF["boleta"]."\n");
  $pdf->Cell(40,10, $infGetAlumnoPDF["nombre"]."\n");
  $pdf->Cell(40,10, $infGetAlumnoPDF["apellidos"]."\n");
  $pdf->Output();

?>