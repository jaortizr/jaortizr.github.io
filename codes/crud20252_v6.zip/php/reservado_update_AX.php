<?php
  include("./configBD.php");
  
  date_default_timezone_set("America/Mexico_City");
  extract($_REQUEST);
  $respAX = [];

  $sqlUpdAlumno = "UPDATE alumno SET correo = '$correo' WHERE boleta = '$boleta'";
  $resUpdAlumno = mysqli_query($conexion, $sqlUpdAlumno);
  if(mysqli_affected_rows($conexion) == 1){
    $respAX["code"] = 1;
    $respAX["msj"] = "OK. Registro actualizado.";
    $respAX["icono"] = "success";
    $respAX["data"] = "";
    $respAX["log"] = date("Y:m:d H:i:s");
  }else{
    $respAX["code"] = 0;
    $respAX["msj"] = "Error. Favor de intentarlo nuevamente.";
    $respAX["icono"] = "error";
    $respAX["data"] = "";
    $respAX["log"] = date("Y:m:d H:i:s");
  }

  echo json_encode($respAX);

?>