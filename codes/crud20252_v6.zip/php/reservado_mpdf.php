<?php
  require_once __DIR__ . "/libs/mpdfV8/vendor/autoload.php";

  include("./configBD.php");

  $boleta = $_REQUEST["boleta"];
  $sqlGetAlumnoPDF = "SELECT * FROM alumno WHERE boleta = '$boleta'";
  $resGetAlumnoPDF = mysqli_query($conexion, $sqlGetAlumnoPDF);
  $infGetAlumnoPDF = mysqli_fetch_assoc($resGetAlumnoPDF);
  $boletaAlumno = $infGetAlumnoPDF["boleta"];
  $nombreAlumno = $infGetAlumnoPDF["nombre"]." ".$infGetAlumnoPDF["apellidos"];

  $html = "
    <style>
      h1{color:red;}
    </style>
    <h1>TDAW - 20252</h1>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent fringilla, eros sed faucibus vestibulum, nisi justo accumsan lacus, at finibus sapien sem id ex. Duis vel facilisis elit, eu sagittis felis. Sed lacinia ex vel mollis sagittis. Ut nunc est, placerat ac sagittis in, malesuada quis velit. Donec porta iaculis sapien, eu lobortis ligula lobortis in. Nulla viverra ipsum justo, ut blandit sem mollis eu. Morbi at elementum ex. Phasellus eget aliquam orci. Duis mollis eros a blandit dictum. Nullam lacinia risus magna, vel efficitur nibh lacinia a. Donec non dolor et sapien finibus lobortis pulvinar eget ante. Maecenas nec efficitur metus. Nam urna urna, elementum a mi ut, luctus tincidunt eros. Proin id justo sit amet ante venenatis viverra.</p>
    <a href='https://www.escom.ipn.mx'>ESCOM</a>
    <p>
      $boletaAlumno<br>
      $nombreAlumno
    </p>
  ";

  $mpdf = new \Mpdf\Mpdf(["format" => "Letter-P"]);
  
  $mpdf->SetHTMLFooter('
  <table width="100%">
      <tr>
          <td width="33%">{DATE j-m-Y}</td>
          <td width="33%" align="center">{PAGENO}/{nbpg}</td>
          <td width="33%" style="text-align: right;">My document</td>
      </tr>
  </table>');

  $mpdf->SetWatermarkText("TDAW - 20252");
  $mpdf->showWatermarkText = true;

  $mpdf->WriteHTML($html);
  $mpdf->Output();

?>