package com.example.flutter_mysql

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
