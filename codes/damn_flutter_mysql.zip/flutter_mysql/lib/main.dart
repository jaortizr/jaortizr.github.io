import 'package:flutter/material.dart';
import 'package:mysql1/mysql1.dart';
import 'dart:developer';

// --- CÓDIGO DE LA CLASE CRUD CON MYSQL1 (COPIA DEL PASO ANTERIOR) ---

// --- CONFIGURACIÓN CRÍTICA PARA EL EMULADOR ---
// El emulador de Android usa 10.0.2.2 para referirse al 127.0.0.1 de tu PC.
// Verifica el usuario y sus respectivos permisos sobre la BD, la tabla que se requiere se crea la primera vez en caso de que no exista
const String _host = '10.0.2.2'; 
const int _port = 3306;
const String _user = 'jantonio';     // ¡REEMPLAZA ESTO!
const String _password = 'jantonio'; // ¡REEMPLAZA ESTO!
const String _database = 'damn20261'; // ¡REEMPLAZA ESTO!

class MySqlCrudDemo {
  MySqlConnection? _conn;

  // 1. CONEXIÓN
  Future<void> connect() async {
    final settings = ConnectionSettings(
      host: _host,
      port: _port,
      user: _user,
      password: _password,
      db: _database,
      timeout: const Duration(seconds: 10), 
    );
    try {
      _conn = await MySqlConnection.connect(settings);
      log('Conexión a MySQL exitosa en host: $_host');
      await _conn!.query(
        'CREATE TABLE IF NOT EXISTS alumnos (id INT AUTO_INCREMENT PRIMARY KEY, nombre VARCHAR(100), matricula VARCHAR(20) UNIQUE, promedio DOUBLE)',
      );
    } catch (e) {
      log('--- ERROR DE CONEXIÓN A MySQL ---');
      log('Detalle: $e');
      _conn = null;
    }
  }

  // 2. CREATE
  Future<void> createAlumno(Map<String, dynamic> alumnoData) async {
    if (_conn == null) return;
    final nombre = alumnoData['nombre'];
    final matricula = alumnoData['matricula'];
    final promedio = alumnoData['promedio'];
    await _conn!.query(
      'INSERT INTO alumnos (nombre, matricula, promedio) VALUES (?, ?, ?)',
      [nombre, matricula, promedio],
    );
  }

  // 3. READ
  Future<List<Map<String, dynamic>>> readAllAlumnos() async {
    if (_conn == null) return [];
    final results = await _conn!.query('SELECT * FROM alumnos');
    final List<Map<String, dynamic>> alumnos = [];
    for (final row in results) {
      // Mapeo por índice para crear el Map<String, dynamic>
      alumnos.add({
        'id': row[0], 
        'nombre': row[1],
        'matricula': row[2],
        'promedio': row[3],
      });
    }
    return alumnos;
  }

  // 4. UPDATE
  Future<void> updateAlumno(String matricula, Map<String, dynamic> newData) async {
    if (_conn == null) return;
    final nombre = newData['nombre'];
    final promedio = newData['promedio'];
    await _conn!.query(
      'UPDATE alumnos SET nombre = ?, promedio = ? WHERE matricula = ?',
      [nombre, promedio, matricula],
    );
  }

  // 5. DELETE
  Future<void> deleteAlumno(String matricula) async {
    if (_conn == null) return;
    await _conn!.query(
      'DELETE FROM alumnos WHERE matricula = ?',
      [matricula],
    );
  }
}

// -------------------------------------------------------------------
// --- CÓDIGO DEL FRONTEND EN FLUTTER ---
// -------------------------------------------------------------------

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Demo CRUD MySQL con Flutter',
      theme: ThemeData(
        primarySwatch: Colors.indigo,
      ),
      home: const CrudScreen(),
    );
  }
}

class CrudScreen extends StatefulWidget {
  const CrudScreen({super.key});

  @override
  State<CrudScreen> createState() => _CrudScreenState();
}

class _CrudScreenState extends State<CrudScreen> {
  // Instancia de la clase de gestión de la DB
  late MySqlCrudDemo _dbManager;
  
  // Future para la conexión y carga inicial de datos
  late Future<List<Map<String, dynamic>>> _alumnosFuture; 

  @override
  void initState() {
    super.initState();
    _dbManager = MySqlCrudDemo();
    _alumnosFuture = _initializeDbAndFetchData();
  }

  // Inicializa la conexión y carga los datos
  Future<List<Map<String, dynamic>>> _initializeDbAndFetchData() async {
    await _dbManager.connect();
    // Si la conexión falló, devuelve una lista vacía
    if (_dbManager._conn == null) return Future.error('Fallo de conexión');
    return _dbManager.readAllAlumnos();
  }

  // Recarga la lista de alumnos
  void _refreshData() {
    setState(() {
      _alumnosFuture = _dbManager.readAllAlumnos();
    });
  }

  // Muestra el formulario para Crear o Actualizar
  void _showCrudForm([Map<String, dynamic>? alumno]) {
    final isUpdating = alumno != null;
    final nombreController = TextEditingController(text: isUpdating ? alumno['nombre'].toString() : '');
    final matriculaController = TextEditingController(text: isUpdating ? alumno['matricula'].toString() : '');
    final promedioController = TextEditingController(text: isUpdating ? alumno['promedio'].toString() : '');
    
    // Bloquear matrícula si estamos actualizando
    if (isUpdating) {
      matriculaController.selection = TextSelection.collapsed(offset: matriculaController.text.length);
    }
    
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(isUpdating ? 'Actualizar Alumno' : 'Crear Nuevo Alumno'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                TextField(controller: nombreController, decoration: const InputDecoration(labelText: 'Nombre')),
                TextField(
                  controller: matriculaController, 
                  decoration: const InputDecoration(labelText: 'Matrícula'),
                  enabled: !isUpdating, // Bloquea la edición de la matrícula
                ),
                TextField(
                  controller: promedioController, 
                  decoration: const InputDecoration(labelText: 'Promedio'),
                  keyboardType: TextInputType.number,
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Cancelar'),
              onPressed: () => Navigator.of(context).pop(),
            ),
            ElevatedButton(
              child: Text(isUpdating ? 'Guardar' : 'Crear'),
              onPressed: () async {
                final Map<String, dynamic> data = {
                  'nombre': nombreController.text,
                  'matricula': matriculaController.text,
                  'promedio': double.tryParse(promedioController.text) ?? 0.0,
                };

                if (isUpdating) {
                  // UPDATE
                  await _dbManager.updateAlumno(alumno['matricula'].toString(), data);
                } else {
                  // CREATE
                  await _dbManager.createAlumno(data);
                }
                
                if (mounted) {
                  Navigator.of(context).pop();
                  _refreshData(); // Recarga la lista después de la operación
                }
              },
            ),
          ],
        );
      },
    );
  }

  // Muestra una barra de confirmación después de borrar
  void _showDeleteConfirmation(String matricula) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('¿Seguro que quieres borrar la matrícula $matricula?'),
        action: SnackBarAction(
          label: 'BORRAR',
          onPressed: () async {
            await _dbManager.deleteAlumno(matricula);
            _refreshData();
          },
        ),
        duration: const Duration(seconds: 5),
      ),
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('CRUD MySQL (Demostración)'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _dbManager._conn != null ? _refreshData : null,
          ),
        ],
      ),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: _alumnosFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } 
          
          if (snapshot.hasError) {
            // Manejo de error de conexión o inicialización
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.error_outline, color: Colors.red, size: 60),
                    const SizedBox(height: 10),
                    const Text(
                      'ERROR DE CONEXIÓN A MySQL',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.red),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Verifica que tu servidor MySQL esté activo y que la IP (10.0.2.2) y credenciales sean correctas.\nError: ${snapshot.error}',
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            );
          }
          
          final alumnos = snapshot.data!;
          
          if (alumnos.isEmpty) {
            return const Center(child: Text('No hay alumnos registrados. ¡Usa el botón + para agregar uno!'));
          }

          // Lista de alumnos (ListView)
          return ListView.builder(
            itemCount: alumnos.length,
            itemBuilder: (context, index) {
              final alumno = alumnos[index]; // El Map de datos
              return Card(
                elevation: 2,
                margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                child: ListTile(
                  leading: CircleAvatar(
                    child: Text(alumno['promedio'].toString().substring(0, 3)),
                  ),
                  title: Text(alumno['nombre'].toString(), style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text('Matrícula: ${alumno['matricula']}'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // UPDATE button
                      IconButton(
                        icon: const Icon(Icons.edit, color: Colors.indigo),
                        onPressed: () => _showCrudForm(alumno),
                      ),
                      // DELETE button
                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () => _showDeleteConfirmation(alumno['matricula'].toString()),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
      // Botón flotante para CREATE
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showCrudForm(),
        child: const Icon(Icons.add),
      )
    );
  }
}