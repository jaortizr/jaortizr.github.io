package com.example.flutter_introduction_slider

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
