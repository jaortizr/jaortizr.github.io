import 'package:flutter/material.dart';
import 'package:introduction_slider/introduction_slider.dart';

void main() => runApp(
  MaterialApp(
    debugShowCheckedModeBanner: false,
    home: MyApp()
  )
);

class MyApp extends StatelessWidget {
  MyApp({super.key});

 Image escudoESCOM = Image.asset("assets/backgroundIntroduction.png");

  @override
  Widget build(BuildContext context) {
    return IntroductionSlider(
      items: [
        IntroductionSliderItem(
          logo: FlutterLogo(),
          title: Text("Intro 1", style: TextStyle(fontSize: 40, fontWeight: FontWeight.bold)),
          subtitle: Text("Escuela Superior de Cómputo"),
          backgroundColor: Colors.white,
          backgroundImageDecoration: BackgroundImageDecoration(image: escudoESCOM.image)
        ),
        IntroductionSliderItem(
          logo: Image.asset("assets/escudoESCOM.png"),
          title: Text("Intro 2", style: TextStyle(fontSize: 40, fontWeight: FontWeight.bold)),
          subtitle: Text("Desarrollo de Aplicaciones Móviles Nativas - 20252"),
          backgroundColor: Colors.black,
        ),
        IntroductionSliderItem(
          title: Text("Title 3"),
          backgroundColor: Colors.blue,
        ),
        IntroductionSliderItem(
          title: Text("Intro 4")
        )
      ],
      scrollDirection: Axis.horizontal,
      done: Done(
        child: Icon(Icons.done),
        home: HomePage(),
      ),
      next: Next(child: Icon(Icons.ac_unit_sharp)),
      back: Back(child: Icon(Icons.zoom_out_map_rounded)),
      dotIndicator: DotIndicator(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Flutter - Onboarding screen"), centerTitle: true),
      body: Center(child: Text('Home Page')),
    );
  }
}