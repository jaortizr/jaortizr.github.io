package com.example.flutter_gallery

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
