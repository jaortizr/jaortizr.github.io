package com.example.flutter_grabadora

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
