package com.example.flutter_contador

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
