import 'package:flutter/material.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatefulWidget {
  const MainApp({super.key});

  @override
  State<MainApp> createState() => _MainAppState();
}

class _MainAppState extends State<MainApp> {
  int contador = 0;
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(title: Text("Contador -StatefulWidgets"),centerTitle: true, backgroundColor: Colors.lightBlueAccent),
        body: Center(child: Text("$contador", style: TextStyle(fontSize: 50))),
        floatingActionButton: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FloatingActionButton(
              onPressed:(){
                contador++;
                setState((){});
              },
              backgroundColor: Colors.lightBlueAccent,
              foregroundColor: Colors.white,
              child: Icon(Icons.arrow_circle_up, size: 35)
            ),
            FloatingActionButton(
              onPressed:(){
                if(contador <= 0) {
                  contador = 0;
                } else {
                  contador--;
                }
                setState((){}); 
              },
              backgroundColor: Colors.lightBlueAccent,
              foregroundColor: Colors.white,
              child: Icon(Icons.arrow_circle_down, size: 35)
            ),
            FloatingActionButton(
              onPressed:(){
                contador = 0;
                setState((){ });
              },
              backgroundColor: Colors.lightBlueAccent,
              foregroundColor: Colors.white,
              child: Icon(Icons.remove_circle_outline, size: 35)
            )
          ]
        )
      )
    );
  }
}
