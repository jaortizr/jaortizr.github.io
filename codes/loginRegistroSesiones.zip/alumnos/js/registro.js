document.addEventListener("DOMContentLoaded", ()=>{
  const validator = new JustValidate("form#formRegistro",{
    //tooltip: {position:"top"}
    errorFieldCssClass:"is-invalid",
    successFieldCssClass:"is-valid"
  });
  validator
    .addField("#boleta", [
      {
        rule: "required",
        errorMessage:"Falta tu boleta"
      },
      {
        rule:"integer",
        errorMessage:"Deben ser solo digitos"
      },
      {
        rule:"minLength",
        value:8,
        errorMessage:"Deben ser al menos 8 digitos"
      },
      {
        rule:"maxLength",
        value:10,
        errorMessage:"No deben ser más de 10 digitos"
      }
    ])
    .addField("#nombre",[
      {
        rule:"required",
        errorMessage:"Falta tu nombre"
      }
    ])
    .addField("#primerApe",[
      {
        rule:"required",
        errorMessage:"Falta tu primer apellido"
      }
    ])
    .addField("#segundoApe",[
      {
        rule:"required",
        errorMessage:"Falta tu segundo apellido"
      }
    ])
    .addField("#contrasena",[
      {
        rule:"required",
        errorMessage:"Falta tu contraseña"
      },
      {
        rule:"password",
        errorMessage:"Mínimo 8 caracteres, letras y numeros"
      }
    ])
    .onSuccess((e)=>{
      $.ajax({
        url:"./php/registro_AX.php",
        method:"post",
        data:$("form#formRegistro").serialize(),
        cache:false,
        success:(respAX)=>{
          console.log(respAX);
          //$("div#respAX").html(respAX);
          let objAX = JSON.parse(respAX);
          Swal.fire({
            title:"Alumnos",
            html:objAX.msj,
            icon:objAX.icono,
            footer:objAX.extra,
            didDestroy:()=>{
              if(objAX.cod == 1)
                window.location.href = "./index.html";
              else
              window.location.reload();
            }
          });
        }
      });
    });
});

