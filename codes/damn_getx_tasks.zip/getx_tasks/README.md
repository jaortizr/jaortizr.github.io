# getx_tasks

A new Flutter project.
