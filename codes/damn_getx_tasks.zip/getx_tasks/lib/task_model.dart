class Task{
  String titulo;
  bool completa;

  Task({required this.titulo, this.completa = false});
}