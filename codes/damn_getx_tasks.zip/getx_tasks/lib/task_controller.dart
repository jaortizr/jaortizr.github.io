import 'package:get/get.dart';
import 'package:getx_tasks/task_model.dart';


class TaskController extends GetxController{
  var tareas = <Task>[].obs;

  void addTareas(Task tarea){
    tareas.add(tarea);
  }

  void changeCompleta(int indice){
    tareas[indice].completa = !tareas[indice].completa;
    tareas.refresh();
  }
}