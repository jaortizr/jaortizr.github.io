import 'package:flutter/material.dart';
import 'package:get/get_state_manager/get_state_manager.dart';
import 'package:getx_tasks/task_controller.dart';
import 'package:getx_tasks/task_model.dart';

class TaskScreen extends StatelessWidget {
  TaskScreen({super.key});

  final TaskController tareaController = TaskController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Lista de tareas"),
      ),
      body: Obx(
        ()=>ListView.builder(
          itemCount: tareaController.tareas.length,
          itemBuilder: (context, indice){
            final tarea = tareaController.tareas[indice];
            return ListTile(
              title: Text(tarea.titulo),
              leading: Checkbox(
                value: tarea.completa,
                onChanged: (valor){
                  tareaController.changeCompleta(indice);
                }
              ),
            );
          }
        )
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: (){
          final nvaTarea = Task(titulo: "Blanca Nieves");
          tareaController.addTareas(nvaTarea);
        },
        child: Icon(Icons.add)
      ),
    );
  }
}