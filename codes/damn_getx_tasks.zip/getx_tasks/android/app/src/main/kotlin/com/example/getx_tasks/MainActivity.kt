package com.example.getx_tasks

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
