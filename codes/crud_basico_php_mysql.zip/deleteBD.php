<?php

  $conexion = mysqli_connect("localhost", "root", "", "sem20251");
  $sql = "DELETE FROM alumno WHERE boleta = '2025630002'";
  $resultado = mysqli_query($conexion, $sql);
  if(mysqli_affected_rows($conexion) == 1){
    echo "Gracias, se eliminó tu registro";
  }else{
    echo "Error. Favor de intentarlo nuevamente";
  }

?>