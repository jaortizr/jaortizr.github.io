<?php

  $conexion = mysqli_connect("localhost", "root", "", "sem20251");
  $sql = "UPDATE alumno SET nombre = 'Ana' WHERE boleta = '2025630002'";
  $resultado = mysqli_query($conexion, $sql);
  if(mysqli_affected_rows($conexion) == 1){
    echo "Gracias, se actualizó tu registro";
  }else{
    echo "Error. Favor de intentarlo nuevamente";
  }

?>