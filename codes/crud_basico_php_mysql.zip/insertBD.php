<?php

  $conexion = mysqli_connect("localhost", "root", "", "sem20251");
  $sql = "INSERT INTO alumno VALUES('2025630002','Diana','Cazadora','Cazadora')";
  $resultado = mysqli_query($conexion, $sql);
  if(mysqli_affected_rows($conexion) == 1){
    echo "Gracias por tu registro";
  }else{
    echo "Error. Favor de intentarlo nuevamente";
  }
  
?>