<?php
  // Paquete mysqli
  $conexion = mysqli_connect("localhost","root","","sem20251");
  $sql = "SELECT * FROM alumno";
  $resultado = mysqli_query($conexion, $sql);  
  if(mysqli_num_rows($resultado) > 0){
    while($fila = mysqli_fetch_array($resultado, MYSQLI_NUM)){
      echo "Alumno: $fila[1] $fila[2] $fila[3] <br>";
    };
  }else{
    echo "No hay registros aun";
  }
?>