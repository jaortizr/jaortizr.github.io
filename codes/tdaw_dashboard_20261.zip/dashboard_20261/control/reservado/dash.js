$(document).ready(()=>{
  let boleta = sessionStorage.getItem("boleta");
  
  // Enviar una petición POST
  axios({
    method: "post",
    url: "./../../model/reservado/dash_bd.php",
    data: {boleta:boleta},
    headers:{"Content-Type": "multipart/form-data"}
  }).then(function(respAX){
    let objAX = respAX.data;
    $("#nombreEstudiante").text(objAX.data.estudiante.nombre);
    let allEstudiantes = Array.from(objAX.data.allEstudiantes);
    let trsAllEstudiantes = "";
    allEstudiantes.forEach((estudiante,index)=>{        
      trsAllEstudiantes += `<tr>
        <td>${estudiante.boleta}</td>
        <td>${estudiante.nombre}</td>
        <td>${estudiante.primerApe}</td>
        <td>${estudiante.segundoApe}</td>
        <td>${estudiante.correo}</td>
        <td><i class="fas fa-trash fa-2x"></i>&nbsp;<i class="fas fa-file-pdf fa-2x"></i></td>
      </tr>`;
    });
    $("#allEstudiantes").html(trsAllEstudiantes);
  });

  $("a#cerrarSesion").click(function(){
    let sesion = $(this).attr("data-sesion");
    window.location.href = `./cerrarSesion.php?sesion=${sesion}`;
  });
});