$(document).ready(()=>{
  const validaFormRegistro = new JustValidate("#formRegistro",{
    errorFieldCssClass: ["is-invalid"],
    successLabelCssClass: ["is-valid"]
  });
  validaFormRegistro
  .addField("#boleta",[
    {
      rule:"required",
      errorMessage:"Falta tu boleta"
    },
    {
      rule:"integer",
      errorMessage:"Deben ser solo dígitos"
    },
    {
      rule:"minLength",
      value:10,
      errorMessage:"Deben ser al menos 10 digitos"
    }
  ])
  .addField("#nombre",[
    {
      rule:"required",
      errorMessage:"Falta tu nombre"
    }
  ])
  .addField("#primerApe",[
    {
      rule:"required",
      errorMessage:"Falta tu primer apellido"
    }
  ])
  .addField("#segundoApe",[
    {
      rule:"required",
      errorMessage:"Falta tu segundo apellido"
    }
  ])
  .addField("#correo",[
    {
      rule:"required",
      errorMessage:"Falta tu correo"
    },
    {
      rule:"email",
      errorMessage:"Formato incorrecto"
    }
  ])
  .addField("#contrasena",[
    {
      rule:"required",
      errorMessage:"Falta tu contraseña"
    },
    {
      rule:"strongPassword",
      errorMessage:"Formato incorrecto"
    }
  ])
  .onSuccess((e)=>{
    $.ajax({
      url:"./../model/registro.php",
      type:"post",
      data:$("#formRegistro").serialize(),
      cache:false,
      success:(respAX)=>{
        let objAX = JSON.parse(respAX);
        Swal.fire({
          title:"DAMN - 20261",
          text:`${objAX.msj}`,
          icon:objAX.icono,
          footer:objAX.log,
          didDestroy:()=>{
            if(objAX.cod == 1){
              //volvemos a la pantalla de login
              window.location.href="./login.html";
            }else{
              window.location.reload();
            }
          }
        });
      }
    });
  });
});