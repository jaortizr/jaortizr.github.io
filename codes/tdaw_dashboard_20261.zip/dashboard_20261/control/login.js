$(document).ready(()=>{
  const validaFormLogin = new JustValidate("#formLogin",{
    errorFieldCssClass: ["is-invalid"],
    successLabelCssClass: ["is-valid"]
  });
  validaFormLogin
  .addField("#boleta",[
    {
      rule:"required",
      errorMessage:"Falta tu boleta"
    },
    {
      rule:"integer",
      errorMessage:"Deben ser solo dígitos"
    },
    {
      rule:"minLength",
      value:10,
      errorMessage:"Deben ser al menos 10 digitos"
    }
  ])
  .addField("#contrasena",[
    {
      rule:"required",
      errorMessage:"Falta tu contraseña"
    },
    {
      rule:"strongPassword",
      errorMessage:"Formato incorrecto"
    }
  ])
  .onSuccess((e)=>{
    $.ajax({
      url:"./../model/login.php",
      type:"post",
      data:$("#formLogin").serialize(),
      cache:false,
      success:(respAX)=>{
        let objAX = JSON.parse(respAX);
        Swal.fire({
          title:"DAMN - 20261",
          text:`${objAX.msj}  ${objAX.data.nombre}`,
          icon:objAX.icono,
          footer:objAX.log,
          didDestroy:()=>{
            if(objAX.cod == 1){
              //Accedemos al área reservada
              sessionStorage.setItem("boleta", objAX.data.boleta );
              window.location.href = "./reservado/dash.php";
            }else{
              window.location.reload();
            }
          }
        });
      }
    });
  });
});