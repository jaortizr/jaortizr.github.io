<?php
  include("./configBD.php");
  
  /* ***** Configurar uso horario México ******  */
  date_default_timezone_set("America/Mexico_City");
  $hoy = date("Y-m-d H:i:s");
  /* ******************************************* */
  
  $respAX = [];
  extract($_REQUEST);
  $contrasena = md5($contrasena);
  
  $sqlCheckBoleta = "SELECT * FROM estudiante WHERE boleta = ?";
  $statementCheckBoleta = $conexion -> prepare($sqlCheckBoleta);
  $statementCheckBoleta -> bind_param("s", $boleta);

  $sqlRegistro = "INSERT INTO estudiante VALUE(?,?,?,?,?,?,NOW())";
  $statementRegistro = $conexion -> prepare($sqlRegistro);
  $statementRegistro -> bind_param("ssssss", $boleta, $nombre, $primerApe, $segundoApe, $correo, $contrasena);
  
  $statementCheckBoleta -> execute();
  $resCheckBoleta = $statementCheckBoleta -> get_result();
  if($resCheckBoleta -> num_rows >= 1){
    $respAX["cod"] = 2;
    $respAX["msj"] = "El número de boleta ya está registrado";
    $respAX["icono"] = "warning";
    $respAX["data"] = "";
    $respAX["log"] = $hoy;
  }else{
    $statementRegistro -> execute();
    if($statementRegistro -> affected_rows == 1){
      $respAX["cod"] = 1;
      $respAX["msj"] = "Se han registrado los datos :)";
      $respAX["icono"] = "success";
      $respAX["data"] = "";
      $respAX["log"] = $hoy;
    }else{
      $respAX["cod"] = 0;
      $respAX["msj"] = "Favor de intentarlo nuevamente.";
      $respAX["icono"] = "error";
      $respAX["data"] = "";
      $respAX["log"] = $hoy;
    }
  }

  $conexion -> close();
  $statementRegistro -> close();
  
  echo json_encode($respAX);
?>