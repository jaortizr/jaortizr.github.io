<?php
  include("./../configBD.php");
  
  /* ***** Configurar uso horario México ******  */
  date_default_timezone_set("America/Mexico_City");
  $hoy = date("Y-m-d H:i:s");
  /* ******************************************* */
  
  $respAX = [];
  extract($_REQUEST);

  $sqlEstudiante = "SELECT boleta, CONCAT(nombre,' ',primerApe,' ',segundoApe) as nombre, correo FROM estudiante WHERE boleta = ?";
  $statementEstudiante = $conexion -> prepare($sqlEstudiante);
  $statementEstudiante -> bind_param("s", $boleta);
  $statementEstudiante -> execute();
  $resEstudiante = $statementEstudiante -> get_result();
  $infEstudiante = $resEstudiante -> fetch_assoc();

  $sqlAllEstudiantes = "SELECT boleta, nombre, primerApe, segundoApe, correo FROM estudiante";
  $statementAllEstudiantes = $conexion -> prepare($sqlAllEstudiantes);
  $statementAllEstudiantes -> execute();
  $resAllEstudiantes = $statementAllEstudiantes -> get_result();
  $infAllEstudiante = $resAllEstudiantes -> fetch_all(MYSQLI_ASSOC);
  
  $respAX["cod"] = 1;
  $respAX["msj"] = "Información personal del estudiante y listado de todos los estudiantes";
  $respAX["icono"] = "info";
  $respAX["data"]["estudiante"] = $infEstudiante;
  $respAX["data"]["allEstudiantes"] = $infAllEstudiante;

  echo json_encode($respAX);
?>