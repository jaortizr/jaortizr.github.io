<?php
  session_start();
  include("./configBD.php");
  
  /* Configurar uso horario México */
  date_default_timezone_set("America/Mexico_City");
  $hoy = date("Y-m-d H:i:s");
  
  $respAX = [];
  extract($_REQUEST);
  $contrasena = md5($contrasena);
  
  $sqlLogin = "SELECT boleta, nombre FROM estudiante WHERE boleta = ? AND contrasena = ?";
  $statementLogin = $conexion -> prepare($sqlLogin);
  $statementLogin -> bind_param("ss", $boleta, $contrasena);
  $statementLogin -> execute();
  $resLogin = $statementLogin -> get_result();
  if($resLogin -> num_rows == 1){
    $infEstudiante = $resLogin -> fetch_assoc();
    $respAX["cod"] = 1;
    $respAX["msj"] = "Hola! Bienvenido :)";
    $respAX["icono"] = "success";
    $respAX["data"] = $infEstudiante;
    $respAX["log"] = $hoy;
    $_SESSION["boleta"] = $boleta;
  }else{
    $respAX["cod"] = 0;
    $respAX["msj"] = "Favor de intentarlo nuevamente.";
    $respAX["icono"] = "error";
    $respAX["data"] = "";
    $respAX["log"] = $hoy;
  }

  $conexion -> close();
  $statementLogin -> close();
  
  echo json_encode($respAX);
?>