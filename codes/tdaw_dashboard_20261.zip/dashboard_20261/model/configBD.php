<?php
  $servidorBD = "localhost";
  $BD = "tdaw_20261";
  $usuarioBD = "root";
  $contrasenaUsrBD = "";

  $conexion = new mysqli($servidorBD, $usuarioBD, $contrasenaUsrBD, $BD);
  if($conexion -> connect_error){
    die("Error en la conexión a la BD:" . $conexion -> connect_error);
  }
  if(!$conexion -> set_charset("utf8mb4")){
    echo "Error al cargar el conjunto de caracteres 'utf8mb4'";
    exit();
  }
?>