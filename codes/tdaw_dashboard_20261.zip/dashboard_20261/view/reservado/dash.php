<?php
  session_start();
  if(isset($_SESSION["boleta"])){

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard - 20261</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css">
  <link href="./../libs/bootstrap5/css/bootstrap.min.css" rel="stylesheet">
  <script src="./../libs/jquery-3.7.1.min.js"></script>
  <script src="./../libs/bootstrap5/js/bootstrap.bundle.min.js"></script>
  <script src="./../libs/axios.js"></script>
  <script src="./../../control/reservado/dash.js"></script>
</head>
<body class="d-flex flex-column min-vh-100">
  <header class="mb-3">
    <nav class="navbar navbar-expand-lg navbar-light py-3 bg-light">
        <div class="container-fluid">
            <a class="navbar-brand mx-auto" href="#">
                <img class="img-fluid" src="./../imgs/escudo_ESCOM_header.png">
            </a>
        </div>
    </nav>
  </header>
  <main>
    <div class="container">
      <div class="row">
        <p class="text-center">Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem voluptatibus accusantium expedita velit animi inventore unde non, hic magni! Corporis officiis officia corrupti ex cumque nobis eum rem tempore delectus? Voluptates quaerat ratione aliquid enim obcaecati sunt dolores? Consectetur mollitia iure iste asperiores modi vitae nam nesciunt nostrum quo natus.</p>
      </div>
      <div class="row">
        <h3>Hola <span id="nombreEstudiante" class="text-primary"></span> los estudiantes registrados hasta hoy son:</h3>
        <div class="table-responsive">
          <table class="table table-hover">
            <thead>
              <tr><th>Boleta</th><th>Nombre</th><th>Primer Apellido</th><th>Segundo Apellido</th><th>Correo</th><th>Opciones</th></tr>
            </thead>
            <tbody id="allEstudiantes">
            </tbody>
          </table>
        </div>
        <div class="row text-center">
          <a href="" id="cerrarSesion" data-sesion="boleta">Cerrar Sesión</a>
        </div>
      </div>
    </div><!-- /container -->
  </main>
  <footer class="footer mt-auto py-3 bg-light">
    <div class="container text-center">
      <span class="text-muted"><a href="https://www.escom.ipn.mx">Escuela Superior de Cómputo</a></span>
    </div>
  </footer>
</body>
</html>
<?php
  }else{
    header("location:./../login.html");
  }
?>