<?php
  session_start();
  extract($_REQUEST);

  unset($_SESSION[$sesion]);
  header("location:./../login.html");
?>