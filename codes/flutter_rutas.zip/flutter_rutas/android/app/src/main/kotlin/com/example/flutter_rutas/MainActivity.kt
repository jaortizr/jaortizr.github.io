package com.example.flutter_rutas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
