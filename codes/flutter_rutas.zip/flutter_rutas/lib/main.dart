import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    title: "Rutas nombradas",
    debugShowCheckedModeBanner: false,
    initialRoute: "/",
    routes: {
      "/": (context) => const Inicio(),
      "/ubicacion": (context) => const Ubicacion(),
      "/conocenos": (context) => const Conocenos()
    },
  ));
}

class Inicio extends StatelessWidget {
  const Inicio({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Inicio"),
        backgroundColor: Colors.lightBlueAccent,
        foregroundColor: Colors.white,
      ),
      body: Center(
        child: Column(
          children: [
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue, foregroundColor: Colors.white),
              child: const Text("Ir a 'Ubicación'"),
              onPressed: () {
                Navigator.pushNamed(context, "/ubicacion");
              },
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue, foregroundColor: Colors.white),
              child: const Text("Ir a 'Conócenos'"),
              onPressed: () {
                Navigator.pushNamed(context, "/conocenos");
              },
            ),
          ],
        ), 
      ),
    );
  }
}

class Ubicacion extends StatelessWidget {
  const Ubicacion({super.key});

  @override
// ignore: dead_code
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Ubicación"),
        backgroundColor: Colors.lightBlueAccent,
        foregroundColor: Colors.white,
      ),
      body: Center(
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blue, foregroundColor: Colors.white),
          onPressed: () {
            Navigator.pushNamed(context, "/");
          },
          child: const Text("Ir a 'Inicio'"),
        ), 
      ),
    );
  }
}

class Conocenos extends StatelessWidget {
  const Conocenos({super.key});

  @override
// ignore: dead_code
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Conócenos"),
        backgroundColor: Colors.lightBlueAccent,
        foregroundColor: Colors.white,
      ),
      body: Center(
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blue, foregroundColor: Colors.white),
          onPressed: () {
            Navigator.pushNamed(context, "/");
          },
          child: const Text("Ir a 'Inicio'"),
        ), 
      ),
    );
  }
}
