// Constant Name of Box where we will store details of user
const String userHiveBox="User Box";