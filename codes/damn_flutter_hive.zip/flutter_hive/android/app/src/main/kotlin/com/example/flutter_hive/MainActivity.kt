package com.example.flutter_hive

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
