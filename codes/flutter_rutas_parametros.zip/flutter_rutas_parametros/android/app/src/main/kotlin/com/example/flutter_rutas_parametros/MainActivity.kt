package com.example.flutter_rutas_parametros

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
