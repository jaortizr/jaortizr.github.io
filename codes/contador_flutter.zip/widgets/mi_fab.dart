import 'package:flutter/material.dart';

class MiFAB extends StatelessWidget {
  final IconData icono;
  final VoidCallback? onPressed;
  const MiFAB({
    super.key, required this.icono, required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton(onPressed: onPressed,backgroundColor: Colors.lightBlue,
      child: Icon(icono,color: Colors.white)
    );
  }
}