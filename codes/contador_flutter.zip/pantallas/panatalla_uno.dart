import 'package:flutter/material.dart';
import 'package:primer_app_20251/widgets/mi_fab.dart';

class PantallaUno extends StatefulWidget {
  const PantallaUno({super.key});

  @override
  State<PantallaUno> createState() => _PantallaUnoState();
}

class _PantallaUnoState extends State<PantallaUno> {
  int contador = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text("Mi primera App", style: TextStyle(color: Colors.white)),
          centerTitle: true,
          actions:[
            IconButton(onPressed:(){
              contador = 0;
              setState(() {
                
              });
            }, icon: const Icon(Icons.refresh_outlined))
          ]),
        body:Center(child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
          Text("$contador", style: const TextStyle(fontSize: 70)),
          Text("Clic${contador == 1?'':'s'}", style: const TextStyle(fontSize: 25))
        ],)),
        floatingActionButton: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            MiFAB(icono:Icons.plus_one_outlined, onPressed: (){contador++; setState((){});}),
            const SizedBox(height:10),
            MiFAB(icono:Icons.exposure_minus_1_outlined, onPressed: (){if(contador == 0) return; contador--; setState(() {});},),
            const SizedBox(height:10),
            MiFAB(icono:Icons.refresh_outlined, onPressed: (){contador=0; setState((){});},)
          ]
        )
        );
  }
}

