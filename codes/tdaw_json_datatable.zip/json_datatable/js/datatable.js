$(document).ready(()=>{
  $("#example").DataTable();
});