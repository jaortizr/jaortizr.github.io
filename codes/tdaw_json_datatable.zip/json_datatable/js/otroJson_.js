document.addEventListener("DOMContentLoaded", ()=>{
  let otroObjeto = JSON.parse(otroJson);
  let publicaciones = otroObjeto.publicaciones;

  publicaciones = Array.from(publicaciones);
  let trsPublicaciones = "";
  publicaciones.forEach((objeto, indice, arreglo)=>{
    console.info(`Indice: ${indice}: ${objeto.title}`);
    trsPublicaciones += `
      <tr>
        <td>${objeto.userId}</td>
        <td>${objeto.id}</td>
        <td>${objeto.title}</td>
        <td>${objeto.body}</td>
      </tr>
    `;
  });

  document.querySelector("#tblPublicaciones").innerHTML = trsPublicaciones;
});