# getx_estados

A new Flutter project.
