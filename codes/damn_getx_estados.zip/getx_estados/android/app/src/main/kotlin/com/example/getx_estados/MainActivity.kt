package com.example.getx_estados

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
