import 'package:flutter/material.dart';
import 'package:flutter_supabase_auth/auth/auth_service.dart';
import 'package:flutter_supabase_auth/pages/registro_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  //get auth service
  final authService = AuthService();

  //text controllers
  final correoController = TextEditingController();
  final contrasenaController = TextEditingController();

  //login function
  void login() async{
    final correo = correoController.text;
    final contrasena = contrasenaController.text;

    try{
      await authService.loginConCorreoContrasena(correo, contrasena);
    }catch(e){
      if(mounted){
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Error: $e")));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Login")),
      body: ListView(
        children: [
          TextField(
            controller: correoController,
            decoration: InputDecoration(labelText: "Coreo")
          ),
          SizedBox(height: 20),
          TextField(
            controller: contrasenaController,
            decoration: InputDecoration(labelText: "Contrasena"),
            obscureText: true
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: login, 
            child: Text("Entrar")
          ),
          SizedBox(height: 20),
          GestureDetector(
            onTap: () => Navigator.push(context, 
              MaterialPageRoute(builder: (context) => RegistroPage())
            ),
            child: Center(child: Text("No tienes una cuenta? Registrate"))
          )
        ]
      )
    );
  }
}