import 'package:flutter/material.dart';
import 'package:flutter_supabase_auth/auth/auth_service.dart';

class PerfilPage extends StatefulWidget {
  const PerfilPage({super.key});

  @override
  State<PerfilPage> createState() => _PerfilPageState();
}

class _PerfilPageState extends State<PerfilPage> {
  final authService = AuthService();

  void salir() async{
    await authService.cerrarSesion();
  }

  @override
  Widget build(BuildContext context) {
    final correoUsuario = authService.getCorreoUsuario();
    return Scaffold(
      appBar: AppBar(
        title: Text("Perfil"),
        actions: [
          IconButton(
            onPressed:salir,
            icon: Icon(Icons.logout)
          )
        ],
      ),
      body: Center(
        child: Text(correoUsuario.toString())
      ),

    );
  }
}