import 'package:flutter/material.dart';
import 'package:flutter_supabase_auth/auth/auth_service.dart';

class RegistroPage extends StatefulWidget {
  const RegistroPage({super.key});

  @override
  State<RegistroPage> createState() => _RegistroPageState();
}

class _RegistroPageState extends State<RegistroPage> {
  //get auth service
  final authService = AuthService();

  //text controllers
  final correoController = TextEditingController();
  final contrasenaController = TextEditingController();
  final confirmContrasenaController = TextEditingController();

  //function registro()
  void registro() async{
    final correo = correoController.text;
    final contrasena = contrasenaController.text;
    final confirmContrasena = confirmContrasenaController.text;

    //check that passwords match
    if(contrasena != confirmContrasena){
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Contraseñas no coinciden")));
      return;
    }

    try{
      await authService.registroConCorreoContrasena(correo, contrasena);
      Navigator.pop(context);
    }catch(e){
      if(mounted){
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Error: $e")));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Registro")),
      body: ListView(
        children: [
          TextField(
            controller: correoController,
            decoration: InputDecoration(labelText: "Coreo")
          ),
          SizedBox(height: 20),
          TextField(
            controller: contrasenaController,
            decoration: InputDecoration(labelText: "Contrasena"),
            obscureText: true
          ),
          SizedBox(height: 20),
          TextField(
            controller: confirmContrasenaController,
            decoration: InputDecoration(labelText: "Confirmar contrasena"),
            obscureText: true
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: registro, 
            child: Text("Registrar")
          )
        ]
      )
    );
  }
}