import 'package:supabase_flutter/supabase_flutter.dart';

class AuthService{
  final SupabaseClient supabase = Supabase.instance.client;

  //sign in with email and password
  Future<AuthResponse> loginConCorreoContrasena(String correo, String contrasena) async{
    return await supabase.auth.signInWithPassword(password:contrasena, email: correo);
  }

  //sign up with email and password
  Future<AuthResponse> registroConCorreoContrasena(String correo, String contrasena) async{
    return await supabase.auth.signUp(password: contrasena, email: correo);
  }

  //sign out
  Future<void> cerrarSesion() async{
    await supabase.auth.signOut();
  }

  //get user email
  String? getCorreoUsuario(){
    final sesion = supabase.auth.currentSession;
    final usuario = sesion?.user;
    return usuario?.email;
  }
}