import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter_supabase_auth/auth/auth_gate.dart';

void main() async {
  // supabase setup
  await Supabase.initialize(
    anonKey: "",
    url: ""
  );

  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: AuthGate()
    );
  }
}
