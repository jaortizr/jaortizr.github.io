package com.example.flutter_supabase_auth

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
