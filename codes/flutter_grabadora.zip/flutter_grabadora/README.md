# record_example

Demonstrates how to use the record plugin.

## Getting Started

Warnings on web:
* player does not support blob URL at the time of writing.

