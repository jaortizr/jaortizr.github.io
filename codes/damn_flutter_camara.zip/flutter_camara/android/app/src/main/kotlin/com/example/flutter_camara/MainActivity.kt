package com.example.flutter_camara

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
