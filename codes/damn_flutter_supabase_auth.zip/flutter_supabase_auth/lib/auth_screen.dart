import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool isLoading = false;
  final formKey = GlobalKey<FormState>();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();

  @override
  void dispose(){
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  void showError(String mensaje){
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(mensaje), backgroundColor: Colors.red,)
    );
  }

  Future<void> signIn() async {
    if(!formKey.currentState!.validate()) return;
    setState((){isLoading = true;});
    try{
      await Supabase.instance.client.auth.signInWithPassword(
        email: emailController.text.trim(),
        password: passwordController.text.trim()
      );
      if(mounted){
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("¡Inicio de sesión exitoso! :)"),
            backgroundColor: Colors.blue,
          )
        );
      }
    }on AuthApiException catch (error){
      if(mounted) showError(error.message);
    }catch (error){
      if(mounted) showError("Ocurrió un error inesperado");
    }finally{
      if(mounted) setState(() {isLoading = false;});
    }
  }

  Future<void> signUp() async {
    if(!formKey.currentState!.validate()) return;
    setState((){isLoading = true;});
    try{
      await Supabase.instance.client.auth.signUp(
        email: emailController.text.trim(),
        password: passwordController.text.trim()
      );
      if(mounted){
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("¡Registro exitoso! Revisa tu correo para confirmar la cuenta"),
            backgroundColor: Colors.green,
          )
        );
      }
    }on AuthApiException catch (error){
      if(mounted) showError(error.message);
    }catch (error){
      if(mounted) showError("Ocurrió un error inesperado durante el registro");
    }finally{
      if(mounted) setState(() {isLoading = false;});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Supabase - Auth"),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child:isLoading
        ?CircularProgressIndicator()
        :Form(
          key: formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextFormField(
                controller: emailController,
                decoration: InputDecoration(labelText: "Correo"),
                validator: (value) {
                  if(value == null || value.isEmpty){
                    return "Falta tu correo electrónico";
                  }
                  return null;
                },
              ),
              SizedBox(height: 20,),
              TextFormField(
                controller: passwordController,
                obscureText: true,
                decoration: InputDecoration(labelText: "Contraseña"),
                validator: (value) {
                  if(value == null || value.isEmpty){
                    return "Falta tu contraseña";
                  }
                  return null;
                },
              ),
              SizedBox(height: 20,),
              ElevatedButton(
                onPressed:(){
                  signIn();
                }, 
                child: Text("Iniciar sesion")
              ),
              SizedBox(height: 20,),
              ElevatedButton(
                onPressed:(){
                  signUp();
                },
                child: Text("Registrarse")
              )
            ],
          ),
        ),
      ),
    );
  }
}