document.addEventListener("DOMContentLoaded", ()=>{
  let miOBJ = JSON.parse(miJSON);
  let posts = "";
  miOBJ.forEach((value, index)=>{
    posts += `
      <div class="row my-5">
        <div class="col col-xs-12 col-lg-3">
          <img src="./imgs/EscudoESCOM_300.jpg">
        </div>
        <div class="col col-xs-12 col-lg-9">
          <div id="info" class="text-primary">User: ${value.userId} / Id: ${value.id}</div>
          <h2 id="title"><i class="fa-solid fa-star"></i> ${value.title}</h2>
          <h3 id="body" class="text-muted justificar">${value.body}</h3>
        </div>
      </div>
    `;
  });
  document.querySelector("div#contenedor").innerHTML = posts;


  let misIconos = document.querySelectorAll("i.fa-star");
  console.log(misIconos);
  misIconos.forEach((value, index)=>{
    value.addEventListener("click",()=>{
      console.log("Click en el icono: " + (index+1));
      window.location.href = "https://www.ipn.mx";
    })
  });


});
