# flutter_supabase_bd

A new Flutter project.
