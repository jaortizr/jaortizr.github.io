import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class InsertScreen extends StatefulWidget {
  const InsertScreen({super.key});

  @override
  State<InsertScreen> createState() => _InsertScreenState();
}

class _InsertScreenState extends State<InsertScreen> {
  final alumnos = Supabase.instance.client.from("alumno").select();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("SUPABASE - BD"),
        centerTitle: true,
      ),
      body: FutureBuilder(
        future: alumnos, 
        builder:(context, snapshot) {
          if(!snapshot.hasData){
            return Center(
              child: CircularProgressIndicator(),
            );
          }
          final allAlumnos = snapshot.data!;
          return ListView.builder(
            itemCount: allAlumnos.length,
            itemBuilder:(context, index) {
              final alumno = allAlumnos[index];
              return ListTile(
                leading: Icon(Icons.person),
                title: Text(alumno["boleta"]),
              );
            },
          );
        },
      ),
    );
  }
}