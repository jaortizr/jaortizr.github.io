package com.example.flutter_supabase_bd

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
