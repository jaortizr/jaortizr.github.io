import 'package:flutter/material.dart';
import 'package:flutter_layout/mis_widgets.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: SafeArea(
        child: Scaffold(
          appBar: AppBar(
            title: Text("DAMN - 20261", 
              style:TextStyle(color: Colors.white) ,
            ),
            backgroundColor: Colors.blue,
            centerTitle: true,
          ),
          body: SingleChildScrollView(
            child:Column(
              children: [
                Titulo(),
                FotoHome(),
                InfoEscuela(),
                Contactos(),
                Bienvenida()
              ],
            ),
          )
        ),
      ),
    );
  }
}

/* ++++++++++++++++++++ */

