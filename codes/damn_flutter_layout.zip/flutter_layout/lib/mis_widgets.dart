import 'package:flutter/material.dart';

class Titulo extends StatelessWidget {
  const Titulo({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Padding(
          padding: const EdgeInsets.all(15.0),
          child: Text("Instituto Politécnico Nacional",
            style: TextStyle(
              color: Colors.red.shade900,
              fontSize: 20,
              fontWeight: FontWeight.w900
            ),
          ),
        )
      ]
    );
  }
}

class FotoHome extends StatelessWidget {
  const FotoHome({super.key});

  @override
  Widget build(BuildContext context) {
    return Image(image:AssetImage("assets/fotoESCOM.jpg"));
  }
}

class NombreEscuela extends StatelessWidget {
  const NombreEscuela({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(15.0),
      child: Column(
        children: [
          Text("Escuela Superior de Cómputo",
            style: TextStyle(
              fontSize: 18, fontWeight: FontWeight.w400
            ),
          ),
          Text("U.P. Adolfo López Mateos")
        ],
      ),
    );
  }
}

class Estrella extends StatelessWidget {
  const Estrella({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(Icons.star,
          color: Colors.blue,
          size: 40,
        ),
        Text("93",
          style: TextStyle(
            fontSize: 35
          ),
        )
      ],
    );
  }
}

class InfoEscuela extends StatelessWidget {
  const InfoEscuela({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        NombreEscuela(),
        Estrella()
      ],
    );
  }
}

class Contacto extends StatelessWidget {
  final IconData icono;
  final String texto;
  const Contacto(this.icono, this.texto, {super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Icon(icono,
          color: Colors.lightBlue,
          size: 40,
        ),
        SizedBox(height: 8,),
        Text(texto,
          style: TextStyle(
            fontWeight: FontWeight.bold
          ),
        )
      ],
    );
  }
}

class Contactos extends StatelessWidget {
  const Contactos({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(15.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Contacto(Icons.facebook, "FACEBOOK"),
          Contacto(Icons.mobile_friendly, "TELÉFONO"),
          Contacto(Icons.mail, "CORREO")
        ],
      ),
    );
  }
}

class Bienvenida extends StatelessWidget {
  const Bienvenida({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text("Bienvenidos",
          style: TextStyle(
            fontSize: 25
          ),
        ),
        Text("""
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas eget quam a purus blandit iaculis. Cras ullamcorper leo fermentum, semper felis id, euismod urna. Mauris dignissim at felis eget suscipit. Nullam et orci fermentum magna tincidunt porta. Morbi id nisl eros. Nullam vel sapien suscipit, tincidunt tortor sed, mollis purus. Morbi vel porttitor lectus, non fermentum orci.

Duis sodales, lacus non ultricies tempor, quam ipsum suscipit nulla, et ultrices nisi turpis nec sapien. Sed maximus ante a tortor porttitor, at blandit augue sodales. Aenean elementum rutrum libero, porttitor efficitur diam rhoncus eu. In luctus nec enim at tincidunt. Donec venenatis enim ut justo porttitor, ac condimentum libero commodo. Vestibulum tincidunt faucibus elementum. Nulla facilisi. Donec sed vehicula leo. Proin nisl nulla, mollis a nulla vitae, molestie accumsan sem. In facilisis, quam vel mollis tincidunt, tortor tellus aliquam lorem, et interdum tellus sem eget nunc. Aliquam eros felis, malesuada a arcu in, bibendum commodo urna.

Phasellus id orci vel augue ultrices hendrerit vel ut velit. Curabitur nec rhoncus ex, eu tempor justo. Proin quis est enim. Donec dapibus, lorem vel pretium posuere, urna nisi sollicitudin enim, vel hendrerit dolor tortor eu diam. Aenean fringilla nec lacus id blandit. Donec at felis a elit scelerisque volutpat in non justo. Sed porta pulvinar tortor in sagittis. Ut sollicitudin lectus eu ex semper, nec pellentesque tortor ullamcorper. Maecenas vitae nisi nisi. Sed viverra ornare porta. Morbi eu feugiat purus, a finibus mauris. Duis viverra elit ut leo elementum, sit amet fringilla metus accumsan. Maecenas vitae sollicitudin sapien.

Maecenas a mattis metus. Pellentesque consectetur elit in lorem pretium dictum. Maecenas ultrices ullamcorper dui, vitae lacinia ligula scelerisque congue. Sed id augue vel est semper pharetra at a sapien. In nec maximus justo. Integer sodales eros sem, ac rhoncus leo accumsan at. Nullam egestas enim in nisl viverra, nec viverra justo eleifend. Aliquam pellentesque iaculis convallis. Donec efficitur dignissim sapien, sed porta nisi luctus vel. Nunc nisl lacus, feugiat eu urna eu, dapibus elementum quam. Sed sollicitudin luctus turpis eget aliquam. Donec ultricies nulla at enim commodo, ut imperdiet ligula bibendum. In finibus metus a nulla cursus, ut blandit velit placerat.
        """,
        textAlign: TextAlign.justify,
        )
      ],
    );
  }
}