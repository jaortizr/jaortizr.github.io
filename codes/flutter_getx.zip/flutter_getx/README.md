# flutter_getx

A new Flutter project.
