import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ContadorController extends GetxController {
  var contador= 0.obs;
  
  incrementar() => contador.value++;
  
  decrementar(){
    if(contador.value <= 0){
      resetear();
    }else{
      contador.value--;
    } 
  }
  
  resetear(){
    contador.value = 0;
  }
}

//Obx(() => Text("Clicks: ${c.contador.string}"))

class Home extends StatelessWidget {
  const Home({super.key});

  @override
  Widget build(context) {
    // Cree una instancia de su clase usando Get.put() para que esté disponible para todas las rutas "secundarias" allí.
    final ContadorController c = Get.put(ContadorController());
    
    return Scaffold(
      // Utilice Obx(()=> para actualizar Text() siempre que se cambie el recuento.
      appBar: AppBar(title: Text("GetX - Flutter"), centerTitle: true, backgroundColor: Colors.lightBlueAccent),
      // Reemplace el Navigator.push de 8 líneas por un simple Get.to(). No necesitas contexto
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Obx(() => Text("Clicks: ${c.contador.string}")),
            ElevatedButton(
              child: Text("Ir a Other"), 
              onPressed: () => Get.to(Other())
            )
          ],
        )
      ),
      floatingActionButton:
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              FloatingActionButton(
                onPressed: c.incrementar,
                child: Icon(Icons.exposure_plus_1)
              ),
              FloatingActionButton(
                onPressed: c.decrementar,
                child: Icon(Icons.exposure_minus_1)
              )
            ],
          )
          );
  }
}

class Other extends StatelessWidget {
  // Puede pedirle a Get que busque un controlador que está siendo utilizado por otra página y le redirija a él.
  final ContadorController c = Get.find();
  
  Other({super.key});

  @override
  Widget build(context){
    // Acceder a la variable de recuento actualizada
    return Scaffold(body: Center(child: Text(c.contador.string)));
  }
}

void main() => runApp(const MainApp());

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      home: Home()
    );
  }
}