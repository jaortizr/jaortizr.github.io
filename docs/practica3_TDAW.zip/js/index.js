$(document).ready(()=>{
  let objDBS = JSON.parse(jsonDBS);
  let numPersonajes = objDBS.length;
  let trsPersonajes = "";
  for(let i = 0; i < numPersonajes; i++){
    let nombre = objDBS[i].name;
    let biografia = objDBS[i].bio;
    let imagen = objDBS[i].img;
    trsPersonajes += "<tr><td><h5>"+nombre+"</h5></td><td><p>"+biografia+"</p></td><td><img src='"+imagen+"' class='responsive-img'></td></tr>";
  }
  $("tbody#personajesDBS").html(trsPersonajes);
});




