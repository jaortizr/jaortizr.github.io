$(document).ready(()=>{
  let objDBS = JSON.parse(jsonDBS);

  let tamObjDBS = objDBS.length;
  let rowsPersonajes = "";
  for(let i=0; i<tamObjDBS; i++){
    let nombre = objDBS[i].name;
    let bio = objDBS[i].bio;
    let imagen = objDBS[i].img;
    let raza = objDBS[i].race;
    let salud= objDBS[i].health;
    let defensa = objDBS[i].defense;
    let ataque = objDBS[i].attack;
    let recuperacion = objDBS[i].kiRestoreSpeed;
    let habilidades = objDBS[i].abilities;

    rowsPersonajes += '<div class="row"><div class="col s12 m6 l4 xl4"><img src="'+imagen+'" class="responsive-img"></div><div class="col s12 m6 l8 xl8"><div class="row"><h1>'+nombre+' - '+raza+'</h1><h5 class="txtJustificado">'+bio+'</h5></div><div class="row"><div class="col s12 m6 l3 xl3 center-align"><i class="fas fa-heart fa-beat fa-8x red-text"></i><h4>Salud</h4><h4>'+salud+'</h4></div><div class="col s12 m6 l3 xl3 center-align"><i class="fa-solid fa-shield-halved fa-8x orange-text"></i><h4>Defensa</h4><h4>'+defensa+'</h4></div><div class="col s12 m6 l3 xl3 center-align"><i class="fa-solid fa-hand-fist fa-8x orange-text"></i><h4>Ataque</h4><h4>'+ataque+'</h4></div><div class="col s12 m6 l3 xl3 center-align"><i class="fa-solid fa-suitcase-medical fa-8x orange-text"></i><h4>Recuperación</h4><h4>'+recuperacion+'</h4></div></div><div class="row"><h4 class="txtJustificado"><i class="fa-solid fa-fire red-text"></i> Super poderes: '+habilidades[0]+', '+habilidades[1]+', '+habilidades[2]+'.</h4></div></div></div><hr>';
  }

  $("div#personajes").html(rowsPersonajes);
});
