$(document).ready(()=>{
  let objDBS = JSON.parse(jsonDBS);

  let tamObjDBS = objDBS.length;
  let trsPersonajes = "";
  for(let i=0; i<tamObjDBS; i++){
    let nombre = objDBS[i].name;
    let bio = objDBS[i].bio;
    let imagen = objDBS[i].img;
    trsPersonajes += "<tr><td><h5>"+nombre+"</h5></td><td><span class='hide-on-med-and-down'>"+bio+"</span></td><td><img src='"+imagen+"' class='responsive-img circle'></td></tr>";
  }

  $("tbody#personajesDBS").html(trsPersonajes);
});
