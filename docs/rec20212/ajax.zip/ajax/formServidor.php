<?php
  //sleep(35); //Simular una conectividad inestable

  //$_POST[] $_GET[]
  $usuario = $_REQUEST["usuario"];
  $contrasena = $_REQUEST["contrasena"];

  echo "Usuario: $usuario <br>Contraseña: $contrasena";
?>