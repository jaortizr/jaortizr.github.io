<?php
  $usuario = $_POST["usuario"];
  $contrasena = $_REQUEST["contrasena"];


  echo "Bienvenido: $usuario y tu Password es: $contrasena";
?>