<?php
    echo "VER: ".$_POST["boleta"];
?>