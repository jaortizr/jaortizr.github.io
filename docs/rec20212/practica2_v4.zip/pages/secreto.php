<?php
    session_start();
    if(isset($_SESSION["login"])){
        $boleta = $_SESSION["login"];
        $conexion = mysqli_connect("localhost","root","escomipn","escom20212");
        $sqlInfAlumno = "SELECT * FROM alumnos WHERE boleta = '$boleta'";
        $resInfAlumno = mysqli_query($conexion,$sqlInfAlumno);
        $infAlumno = mysqli_fetch_row($resInfAlumno);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>Examples</title>
<meta name='viewport' content='width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no'/>
<meta name="description" content="">
<meta name="keywords" content="">
<link href="" rel="stylesheet">
</head>
<body>
    <h1>Bienvenido a la Sección Secreta: <?php echo $infAlumno[1]; ?> </h1>
    <p>
        Boleta: <?php echo $infAlumno[0]; ?><br>
        Correo: <?php echo $infAlumno[2]; ?>
    </p>
    <p><a href="./cerrarSesion.php?nombreSesion=login">Cerrar sesión</a></p>
</body>
</html>
<?php
    }else{
        header("location: ./login.html");
    }
?>
