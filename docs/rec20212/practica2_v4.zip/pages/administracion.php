<?php
    //Checar la sesión asociada a los administradores

    $conexion = mysqli_connect("localhost","root","escomipn","escom20212");
    mysqli_set_charset($conexion,"utf8");
    $sqlAlumnos = "SELECT * FROM alumnos";
    $resAlumnos = mysqli_query($conexion, $sqlAlumnos);
    $trAlumnos = "";
    while($filas = mysqli_fetch_array($resAlumnos,MYSQL_BOTH)){
        $trAlumnos .= "<tr>
            <td>$filas[1]</td>
            <td>
                <i class='fas fa-eye fa-2x blue-text text-darken-1 verRegistro' data-boleta='$filas[0]'></i>&nbsp;
                <i class='fas fa-edit fa-2x blue-text text-darken-2 editarRegistro' data-boleta='$filas[0]'></i>&nbsp;
                <i class='fas fa-times fa-2x blue-text text-darken-3 eliminarRegistro' data-boleta='$filas[0]'></i>&nbsp;
                <i class='fas fa-file-pdf fa-2x blue-text text-darken-3 generarPDF' data-boleta='$filas[0]'></i>&nbsp;
                <i class='fas fa-envelope fa-2x blue-text text-darken-3 enviarCorreo' data-boleta='$filas[0]'></i>
            </td>
        </tr>";
    }
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>Administración</title>
<meta name='viewport' content='width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no'/>
<meta name="description" content="">
<meta name="keywords" content="">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
<link href="./../materialize/css/materialize.min.css" rel="stylesheet">
<link href="./../jscript/plugins/confirm334/jquery-confirm.min.css" rel="stylesheet">
<link href="./../css/general.css" rel="stylesheet">
<script src="./../jscript/jquery-3.6.0.min.js"></script>
<script src="./../materialize/js/materialize.min.js"></script>
<script src="./../jscript/plugins/confirm334/jquery-confirm.min.js"></script>
<script src="./../jscript/administracion.js"></script>
</head>
<body>
    <header>
        <img src="./../imgs/header2.jpg" class="responsive-image">
    </header>
    <main class="valign-wrapper">
        <div class="container">
            <div class="row">
            <h3>Administrador</h3>
                <table class="centered striped responsive-table">
                    <thead>
                        <tr><th>Nombre</th><th>Opciones</th>
                    </thead>
                    <tbody>
                        <?php echo $trAlumnos; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
    <footer class="page-footer blue">
        <div class="footer-copyright">
            <div class="container">
              © 2021 JAOR
              <a class="grey-text text-lighten-4 right" href="https://www.escom.ipn.mx">ESCOM</a>
            </div>
        </div>
    </footer>
</body>
</html>