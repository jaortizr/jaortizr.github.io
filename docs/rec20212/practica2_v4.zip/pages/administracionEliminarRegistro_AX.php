<?php
    echo "ELIMINAR: ".$_POST["boleta"];
?>