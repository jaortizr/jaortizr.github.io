<?php
  //Conectarse al servidor MySQL o MariaDB
  $conexion = mysqli_connect("localhost","root","","escom20212");
  //Forzar a que los caracteres utilizados sean del conjunto UTF8
  mysqli_query($conexion, "SET character_set_results = 'utf8', character_set_client = 'utf8', character_set_connection = 'utf8', character_set_database = 'utf8', character_set_server = 'utf8'");
  //Preparo la instrucción SQL
  $sql = "SELECT * FROM alumnos";
  //Ejecuto la instrucción SQL sobre MySQL o MariaDB
  $resultado = mysqli_query($conexion,$sql);
  
  //En función al SQL ejecutado se procesa la respuesta
  //En este caso, varias opciones para una instrucción SELECT:
  //a) cuantas filas o registros contine la respuesta
  $numFilas = mysqli_num_rows($resultado);
  echo "<p style='color:red;'>Se tienen: $numFilas fila(s) en la tabla 'alumnos'</p>";

  //b) Caso particular con un solo registro como respuesta
  /*
  $fila = mysqli_fetch_row($resultado);
  echo "$fila[0] / $fila[1] / $fila[2] / $fila[3] / $fila[4]";
  */
  

  //c) Caso general para 'N' registros como respuesta
  
  $tablaResultado = "<table width='100%'><tr><th>Boleta</th><th>Nombre</th><th>Correo</th><th>Contraseña</th><th>Auditoria</th></tr>";
  while($filas = mysqli_fetch_array($resultado,MYSQLI_BOTH)){
    $tablaResultado .= "<tr><td>$filas[0]</td><td>$filas[1]</td><td>$filas[2]</td><td>$filas[3]</td><td>$filas[4]</td></tr>";
  }
  $tablaResultado .= "</table>";
  echo $tablaResultado;
  


  //d) Caso general para 'N' registros como respuesta pero en formato JSON
  /*
    $resultadoJSON = array();
    $resultadoJSON[] = $numFilas;
  while($filas = mysqli_fetch_array($resultado,MYSQLI_ASSOC)){
    $resultadoJSON[] = $filas;
    //$resultadoJSON['boleta'] = 2021630001 $resultadoJSON['nombre'] = Juan Pérez Pérez ...
  }

  echo json_encode($resultadoJSON);
  */
?>