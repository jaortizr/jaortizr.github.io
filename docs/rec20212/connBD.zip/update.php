<?php
  $conexion = mysqli_connect("localhost","root","","escom20212");
  mysqli_query($conexion, "SET character_set_results = 'utf8', character_set_client = 'utf8', character_set_connection = 'utf8', character_set_database = 'utf8', character_set_server = 'utf8'");

  $sql = "UPDATE alumnos SET correo = 'estela@gmail.com' WHERE boleta = '2020630006'";
  $resultado = mysqli_query($conexion, $sql);

  $info = mysqli_affected_rows($conexion);
  echo "Filas actualizadas: $info";

?>