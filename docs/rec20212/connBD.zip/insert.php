<?php
  $conexion = mysqli_connect("localhost","root","","escom20212");
  mysqli_query($conexion, "SET character_set_results = 'utf8', character_set_client = 'utf8', character_set_connection = 'utf8', character_set_database = 'utf8', character_set_server = 'utf8'");

  $sql = "INSERT INTO alumnos values('2020630006','Estela Enriquez Enriquez','estela@estela.com','estela',NOW())";
  $resultado = mysqli_query($conexion, $sql);

  $info = mysqli_affected_rows($conexion);
  echo "Filas insertadas: $info";

?>