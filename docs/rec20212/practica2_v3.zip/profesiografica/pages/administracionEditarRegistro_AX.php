<?php
    echo "EDITAR: ".$_POST["boleta"];
?>