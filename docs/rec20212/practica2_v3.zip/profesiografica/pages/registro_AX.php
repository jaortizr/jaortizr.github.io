<?php
  $boleta = $_POST["boleta"];
  $nombre = $_POST["nombre"];
  $correo = $_POST["correo"];
  $contrasena = md5($_POST["contrasena"]);

  $conexion = mysqli_connect("localhost","root","escomipn","escom20212");
  mysqli_set_charset($conexion,"utf8");

  /*
  // La respuesta que el servidor generará será en formato HTML
  $respAX_HTML = "";
  $sql = "INSERT INTO alumnos VALUES('$boleta','$nombre','$correo','$contrasena',NOW())";
  $sqlCheckBoleta = "SELECT * FROM alumnos WHERE boleta = '$boleta'";
  $resultadoCheckBoleta = mysqli_query($conexion,$sqlCheckBoleta);
  if(mysqli_num_rows($resultadoCheckBoleta) == 1){
    $respAX_HTML .= "<h3>Error. El número ya está registrado. Favor de intentarlo nuevamente :(</h3>";
  }else{
    $resultado = mysqli_query($conexion,$sql);
    if(mysqli_affected_rows($conexion) == 1){
      $respAX_HTML .= "<h3>Gracia. Tu registro se realizó correctamente :)</h3>";
    }else{
      $respAX_HTML .= "<h3>Error. Favor de intentarlo nuevamente :(</h3>";
    }
  }
  */

  // La respuesta que el servidor generará será en formato JSON
  $respAX_JSON = array();
  $sql = "INSERT INTO alumnos VALUES('$boleta','$nombre','$correo','$contrasena',NOW())";
  $sqlCheckBoleta = "SELECT * FROM alumnos WHERE boleta = '$boleta'";
  $resultadoCheckBoleta = mysqli_query($conexion,$sqlCheckBoleta);
  if(mysqli_num_rows($resultadoCheckBoleta) == 1){
    $respAX_JSON["codigo"] = 2;
    $respAX_JSON["msj"] = "<h5 class='center-align'>Error. El número de boleta ya está registrado.<br>Favor de intentarlo nuevamente :(</h5>";
  }else{
    $resultado = mysqli_query($conexion,$sql);
    if(mysqli_affected_rows($conexion) == 1){
      $respAX_JSON["codigo"] = 1;
      $respAX_JSON["msj"] = "<h5 class='center-align'>Gracias. Tu registro se realizó correctamente :)</h5>";
    }else{
      $respAX_JSON["codigo"] = 0;
      $respAX_JSON["msj"] = "<h5 class='center-align'>Error. Favor de intentarlo nuevamente :(</h5>";
    }
  }
  
  echo json_encode($respAX_JSON); //{"codigo":1,"msj":"<h3>Gracias|Error...</h3"}
?>