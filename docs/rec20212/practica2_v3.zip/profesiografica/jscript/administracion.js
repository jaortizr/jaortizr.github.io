$(document).ready(function(){
    $(".fas").mouseover(function(){
        $(this).css("cursor","pointer");
    });

    $(".verRegistro").click(function(){
        let boleta = $(this).attr("data-boleta");
        $.ajax({
            url:"./administracionVerRegistro_AX.php",
            method:"post",
            data:{boleta:boleta},
            cache:false,
            success:function(respAX){
                alert(respAX);
            }
        });
    });

    $(".editarRegistro").click(function(){
        let boleta = $(this).attr("data-boleta");
        $.ajax({
            url:"./administracionEditarRegistro_AX.php",
            method:"post",
            data:{boleta:boleta},
            cache:false,
            success:function(respAX){
                alert(respAX);
            }
        });
    });

    $(".eliminarRegistro").click(function(){
        let boleta = $(this).attr("data-boleta");
        $.confirm({
            title: 'TWeb 2021-2',
            content: '¿Está seguro de eliminar este registro?',
            buttons: {
                Si: function () {
                    $.ajax({
                        url:"./administracionEliminarRegistro_AX.php",
                        method:"post",
                        data:{boleta:boleta},
                        cache:false,
                        success:function(respAX){
                            alert(respAX);
                        }
                    });
                },
                No: function () {
                },
            }
        });
    });
});