/*
SQLyog Community v13.1.7 (64 bit)
MySQL - 10.4.16-MariaDB : Database - escom20212
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`escom20212` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `escom20212`;

/*Table structure for table `alumnos` */

DROP TABLE IF EXISTS `alumnos`;

CREATE TABLE `alumnos` (
  `boleta` varchar(10) NOT NULL,
  `nombre` varchar(128) NOT NULL,
  `correo` varchar(128) DEFAULT NULL,
  `contrasena` varchar(32) NOT NULL,
  `auditoria` datetime DEFAULT NULL,
  PRIMARY KEY (`boleta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `alumnos` */

insert  into `alumnos`(`boleta`,`nombre`,`correo`,`contrasena`,`auditoria`) values 
('2021630001','Juan Pérez Pérez','juan@juan.com','d8578edf8458ce06fbc5bb76a58c5ca4','2021-05-17 14:56:10'),
('2021630002','Ana Anaya Anaya','ana@ana.com','d8578edf8458ce06fbc5bb76a58c5ca4','2021-05-17 14:56:31'),
('2021630003','Luis Lopez Lopez','luis@luis.com','d8578edf8458ce06fbc5bb76a58c5ca4','2021-05-17 14:56:53'),
('2021630004','Blanca Benitez Benitez','blanca@blanca.com','d8578edf8458ce06fbc5bb76a58c5ca4','2021-05-17 14:57:39'),
('2021630005','Esther Enriquez Enriquez','esther@esther.com','d8578edf8458ce06fbc5bb76a58c5ca4','2021-05-17 14:58:10');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
