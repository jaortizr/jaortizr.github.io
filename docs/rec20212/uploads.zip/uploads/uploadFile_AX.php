<?php
    $archivo = $_FILES["archivo"];

    //$_FILES["archivo"]["name"];
    
    $dirUploads = "./files/";
    $archUpload = $dirUploads.$archivo["name"];

    if(move_uploaded_file($archivo["tmp_name"],$archUpload)){
        $respAX = "<p>La información del archivo que se subió<br>Nombre: ".$archivo["name"]."<br>Tipo: ".$archivo["type"]."<br>Tamaño: ".$archivo["size"]."</p>";
        echo $respAX;
    }else{
        echo "Error: ".$archivo["error"];
    }
?>