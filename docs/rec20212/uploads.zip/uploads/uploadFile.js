$(document).ready(function(){
    $("input#archivo").on("change",function(){
        let archivo = $("input#archivo");
        
        if(archivo[0].files.length > 0){
            let nombreArchivo = archivo[0].files[0].name;
            let tamanoArchivo = archivo[0].files[0].size;
            let tipoArchivo = archivo[0].files[0].type;
            let fechaArchivo = archivo[0].files[0].lastModifiedDate;

            let reporteArchivo = "<p>Nombre: "+nombreArchivo+"<br>Tamaño: "+ Math.round((tamanoArchivo/1024/1024)*100)/100 +" MB<br>Tipo: "+tipoArchivo+"<br>Modificación: "+fechaArchivo+"</p>";
            
            $("#infoArchivo").html(reporteArchivo);
        }else{
            alert("No hay archivo seleccionado");
        }
    });


    $("form#formUploadFile").submit(function(e){
        e.preventDefault();
        var formData = new FormData($("form#formUploadFile")[0]);
        $.ajax({
            url:"uploadFile_AX.php",
            method:"post",
            data:formData,
            cache:false,
            contentType:false, //Importante colocar siempre que se pretenda enviar un archivo al servidor
            processData:false, //Importante colocar siempre que se pretenda enviar un archivo al servidor
            success:function(respAX){
                alert(respAX);
            }
        });
    });
});