$(document).ready(function(){
    $('.fixed-action-btn').floatingActionButton();
});