<?php
  session_start();
  if(isset($_SESSION["alumno"])){
    include("./alumno_BD.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>ESCOM / Demo 20232</title>
<meta name='viewport' content='width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no'/>
<meta name="description" content="">
<meta name="keywords" content="">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link href="./../css/stickyFooter.css" rel="stylesheet">
<link href="./../materialize/css/materialize.min.css" rel="stylesheet">
<script src="./../js/libs/jquery-3.6.4.min.js"></script>
<script src="./../materialize/js/materialize.min.js"></script>
<script src="./../js/alumno.js"></script>
</head>
<body>
  <header>
    <img src="./../imgs/header.jpg" class="responsive-img">
    <div class="fixed-action-btn">
      <a class="btn-floating btn-large blue">
        <i class="fas fa-ellipsis"></i>
      </a>
      <ul>
        <li><a href="./cerrarSesion.php?nombreSesion=alumno" class="btn-floating grey"><i class="fas fa-power-off"></i></a></li>
        <li><a href="./edita.php" class="btn-floating grey"><i class="fas fa-pencil"></i></a></li>
      </ul>
    </div>
  </header>
  <main class="valign-wrapper">
    <div class="container">
      <div class="row">
        <h3><?php echo "$infAlumno[1] $infAlumno[2] $infAlumno[3]"; ?></h3>
        <h4><i class="fas fa-id-card"></i> Boleta: <?php echo $infAlumno[0]; ?></h4>
        <h4><i class="fas fa-at"></i> Correo: <?php echo $infAlumno[4]; ?></h4>
        <h4><i class="fas fa-mobile"></i> TelCel: <?php echo $infAlumno[5] ?></h4>
        <h5>Registro realizado el: <?php echo $infAlumno[7]; ?></h5>
      </div>
    </div>
  </main>
  <footer class="page-footer blue">
    <div class="footer-copyright">
      <div class="container">
      © 2023 Copyright
      <a class="grey-text text-lighten-4 right" href="https://www.escom.ipn.mx">ESCOM-IPN</a>
      </div>
    </div>
  </footer>
</body>
</html>
<?php
  }else{
    header("location:./../");
  }
?>