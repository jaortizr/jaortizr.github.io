<?php
  include("./configBD.php");

  $boleta = $_SESSION["alumno"];
  $sqlInfAlumno = "SELECT * FROM alumno WHERE boleta = '$boleta'";
  $resInfAlumno = mysqli_query($conexion, $sqlInfAlumno);
  $infAlumno = mysqli_fetch_row($resInfAlumno);
?>