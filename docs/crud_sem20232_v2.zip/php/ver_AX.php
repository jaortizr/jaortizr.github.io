<?php
  include("./configBD.php");

  $boleta = $_POST["boleta"];
  $sqlVerAlumno = "SELECT * FROM alumno WHERE boleta = '$boleta'";
  $resVerAlumno = mysqli_query($conexion, $sqlVerAlumno);
  $infVerAlumno = mysqli_fetch_row($resVerAlumno);
  $respAX = [];
  $respAX["cod"] = 1;
  //$respAX["alumno"] = "$infVerAlumno[1] $infVerAlumno[2] $infVerAlumno[3], Boleta: $infVerAlumno[0]";
  $respAX["alumno"] = $infVerAlumno;
  $respAX["icono"] = "info";

  echo json_encode($respAX);
?>