<?php
  include("./elimina_BD.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>ESCOM / Demo 20232</title>
<meta name='viewport' content='width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no'/>
<meta name="description" content="">
<meta name="keywords" content="">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link href="./../css/stickyFooter.css" rel="stylesheet">
<link href="./../materialize/css/materialize.min.css" rel="stylesheet">
<style>
  .ver, .eliminar{
    cursor:pointer;
  }
</style>
<script src="./../js/libs/jquery-3.6.4.min.js"></script>
<script src="./../materialize/js/materialize.min.js"></script>
<script src="./../js/libs/sweetAlert.min.js"></script>
<script src="./../js/elimina.js"></script>
</head>
<body>
  <header>
    <img src="./../imgs/header.jpg" class="responsive-img">
  </header>
  <main class="valign-wrapper">
    <div class="container">
      <div class="row">
        <h2>CRUD Elimina</h2>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Ab quo enim quos temporibus quisquam commodi ad ipsam! Nesciunt nam odit explicabo nisi ducimus, necessitatibus voluptas voluptate perferendis, iste, praesentium molestiae deserunt tenetur corrupti sint possimus sunt minus nihil eius illum ipsa. Iste ab itaque fugit velit impedit commodi officiis aut.</p>
      </div>
      <table class="stripped centered responsive-table">
        <thead>
          <tr><th>Nombre</th><th>Opciones</th></tr>
        </thead>
        <tbody>
          <?php echo $alumnos; ?>
        </tbody>
      </table>
    </div>
  </main>
  <footer class="page-footer blue">
    <div class="footer-copyright">
      <div class="container">
      © 2023 Copyright
      <a class="grey-text text-lighten-4 right" href="https://www.escom.ipn.mx">ESCOM-IPN</a>
      </div>
    </div>
  </footer>
</body>
</html>