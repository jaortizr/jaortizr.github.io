<?php
  include("./configBD.php");

  $sql = "SELECT * FROM alumno ORDER BY nombre";
  $res = mysqli_query($conexion, $sql);
  $alumnos = "";
  while($filas = mysqli_fetch_row($res)){
    $alumnos .= "<tr><td>$filas[1] $filas[2] $filas[3]</td><td><i class='fas fa-trash eliminar' data-boleta='$filas[0]'></i>&nbsp;&nbsp;&nbsp;<i class='fas fa-eye ver' data-boleta='$filas[0]'></i></td></tr>";
  }
?>