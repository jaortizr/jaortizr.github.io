<?php
  include("./configBD.php");

  $boleta = $_REQUEST["boleta"];
  $sqlDelAlumno = "DELETE FROM alumno WHERE boleta = '$boleta'";
  $resDelAlumno = mysqli_query($conexion, $sqlDelAlumno);
  $numFilasAfectadasDelAlumno = mysqli_affected_rows($conexion);

  $respAX = [];
  if($numFilasAfectadasDelAlumno == 1){
    $respAX["cod"] = 1;
    $respAX["msj"] = "Gracias. El registro fue eliminado :)";
    $respAX["icono"] = "success";
  }else{
    $respAX["cod"] = 0;
    $respAX["msj"] = "Gracias. El registro fue eliminado :)";
    $respAX["icono"] = "error";
  }

  echo json_encode($respAX);
?>