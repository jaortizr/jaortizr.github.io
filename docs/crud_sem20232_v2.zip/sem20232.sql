/*
SQLyog Community v13.1.2 (64 bit)
MySQL - 5.7.24 : Database - sem20232
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`sem20232` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `sem20232`;

/*Table structure for table `alumno` */

DROP TABLE IF EXISTS `alumno`;

CREATE TABLE `alumno` (
  `boleta` varchar(10) NOT NULL,
  `nombre` varchar(64) NOT NULL,
  `primerApe` varchar(64) NOT NULL,
  `segundoApe` varchar(64) DEFAULT NULL,
  `correo` varchar(128) NOT NULL,
  `telcel` varchar(10) NOT NULL,
  `contrasena` varchar(32) NOT NULL,
  `auditoria` datetime DEFAULT NULL,
  PRIMARY KEY (`boleta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `alumno` */

insert  into `alumno`(`boleta`,`nombre`,`primerApe`,`segundoApe`,`correo`,`telcel`,`contrasena`,`auditoria`) values 
('2023630001','Juan','Pérez','Pérez','juan@juan.com','5557296000','f584827c4ca52dd018b4d23e6931c95a','2023-06-03 20:25:30'),
('2023630002','Blanca','Nieves','Nieves','blancanieves@blancanieves.com','5557296000','2bf9e80c5600f8579a76087f10bf249b','2023-06-03 23:38:58'),
('2023630005','José Antonio','Ortiz','Ramírez','jaor@jaor.com','5557296000','14d6dd0c09bb239007aec9ab58ccaec1','2023-06-03 20:41:33');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
