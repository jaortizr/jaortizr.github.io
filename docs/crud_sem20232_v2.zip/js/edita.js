$(document).ready(()=>{
  const validarRegistro = new JustValidate("form#formEdita");
  validarRegistro.addField("#nombre",[
    {
      rule:"required",
      errorMessage:"Falta tu nombre"
    }
  ]).addField("#primerApe",[
    {
      rule:"required",
      errorMessage:"Falta tu primer apellidos"
    }
  ]).addField("#correo",[
    {
      rule:"required",
      errorMessage:"Falta tu correo"
    },
    {
      rule:"email",
      errorMessage:"Revisa formato de tu correo"
    }
  ]).addField("#telcel",[
    {
      rule:"required",
      errorMessage:"Falta tu número teléfonico"
    },
    {
      rule:"integer",
      errorMessage:"Solo digitos"
    },
    {
      rule:"minLength",
      value:10,
      errorMessage:"Mínimo 10 digitos"
    },
    {
      rule:"maxLength",
      value:10,
      errorMessage:"Máximo 10 digitos"
    }
  ]).onSuccess(()=>{
    $.ajax({
      url:"./edita_AX.php",
      method:"POST",
      data:$("form#formEdita").serialize(),
      cache:false,
      success:(respAX)=>{
        let AX = JSON.parse(respAX);
        Swal.fire({
          title:"ESCOM-IPN",
          text:AX.msj,
          icon:AX.icono,
          didDestroy:()=>{
            if(AX.cod == 1)
              location.href = "./alumno.php";
            if(AX.cod == 0)
              location.reload();
          }
        }); // sweetAlert/
      }
    }); // ajax/
  }); // justValidate/
}); // ready/