$(document).ready(()=>{
  $(".fixed-action-btn").floatingActionButton();
});