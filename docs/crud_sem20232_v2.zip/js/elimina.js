$(document).ready(()=>{
  $(".eliminar").on("click",function(){
    let boleta = $(this).attr("data-boleta");
    Swal.fire({
      title: "ESCOM - TWeb",
      text: "¿Desea eliminar al alumno con boleta "+boleta+"?",
      icon: "question",
      showCancelButton: true,
      cancelButtonText: 'No',
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Sí'
    }).then((result) => {
      if (result.isConfirmed) {
        $.ajax({
          url:"./elimina_AX.php",
          method:"POST",
          data:{boleta:boleta},
          cache:false,
          success:(respAX)=>{
            let AX = JSON.parse(respAX);
            Swal.fire({
              title:"ESCOM-TWeb",
              text:AX.msj,
              icon:AX.icono,
              didDestroy:()=>{
                location.reload();
              }
            });
          }
        });
      }
    });
  });

  $(".ver").on("click",function(){
    let boleta = $(this).attr("data-boleta");
    $.ajax({
      url:"./ver_AX.php",
      method:"POST",
      data:{boleta:boleta},
      cache:false,
      success:(respAX)=>{
        let AX = JSON.parse(respAX);
        Swal.fire({
          title:"ESCOM-TWeb",
          html:"<h5><i class='fas fa-user'></i> "+AX.alumno[1]+" "+AX.alumno[2]+" "+AX.alumno[3]+"<br><i class='fas fa-cog'></i> Boleta: "+AX.alumno[0]+"<br><i class='fas fa-at'></i> Correo: "+AX.alumno[4]+"<br><i class='fas fa-mobile'></i> TelCel: "+AX.alumno[5]+"</h5>",
          icon:AX.icono,
          didDestroy:()=>{
          }
        });
      }
    });
  });
});
