<?php
    //Recupero los datos que llegan a esta página accediendo al arreglo asociativo global $_POST[] y posteriormente solo la depliego en pantalla por medio de confirm.js. Claro que no es lo único que podemos, que debemos, hacer; el objetivo será hacer operaciones contra una BD MySQL, esto más adelante, calma.

    $boleta = $_POST["boleta"];
    $contrasena = $_POST["contrasena"];
    $mensaje = "$boleta y $contrasena";
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>Examples</title>
<meta name='viewport' content='width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no'/>
<meta name="description" content="">
<meta name="keywords" content="">
<link href="./fontawesome/css/all.min.css" rel="stylesheet">
<link href="./materialize/css/materialize.min.css" rel="stylesheet">
<link href="./js/plugins/confirm/jquery-confirm.min.css" rel="stylesheet">
<script src="./js/jquery-3.4.1.min.js"></script>
<script src="./materialize/js/materialize.min.js"></script>
<script src="./js/plugins/confirm/jquery-confirm.min.js"></script>
<script>
    $(document).ready(function(){
        //Aprovechamos las bondades de este plugin y agregamos el uso de uno de sus callbacks que se activa cuando se destruye la 'ventanita' y redirecciono a la página inicial
        $.alert({
            title:"<h4>TWeb - Sem. 20202</h4>",
            content:"<h5>Los datos recibidos son: <?php echo $mensaje; ?></h5>",
            theme:"supervan",
            icon:"fas fa-cogs fa-2x",
            type:"blue",
            onDestroy:function(){
                window.location.replace("./index.html");
            }
        });
    });
</script>
</head>
<body>
    
</body>
</html>