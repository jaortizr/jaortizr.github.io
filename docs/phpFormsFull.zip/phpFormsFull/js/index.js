$(document).ready(function(){
    /*
        UPDATE:040420
        Recordemos que está pasando: tenemos un formulario en HTML, que al hacer click en el componente de tipo SUBMIT se activa el envío de dicho formulario a donde indique ACTION, pero también tiene VALIDETTA que casualmente se activa también cuando se presenta el evento SUBMIT del componente de formulario SUBMIT; hay que verificar que validetta hace su trabajo limitandose a validar la información que el usuario proporciona sin afectar el comportamiento que por default tienen todos los involucrados.

        A diferencia del ejemplo anterior, aquí no utilizaremos el plugin CONFIRM.JS por lo que retiramos las líneas correspondientes así como en el HTML los <link> y <script> correspondientes, para intentar aplicarlos en el PHP que recibirá la información del formulario.
    */
    
    //Validetta valida la información que el usuario proporciona y hasta que no se cumplan estas se continua con el envío del formulario y antes de que esto suceda le indicamos al usuario que datos se enviarán. Afortunadamente validetta no es muy intrusivo en este esquema de 'vieja escuela'
    $("#formFrontEnd").validetta({
        bubblePosition: "bottom",
        bubbleGapTop: 10,
        bubbleGapLeft: -5
    });
});