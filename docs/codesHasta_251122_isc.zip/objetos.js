const miObjeto = {
  color:"Rojo",
  marca:{
    pais:"España",
    fundacion:1932,
    varios:["Ibiza","Leon","Arona"]
  },
  modelo:[
    {
      x:"ESCOM",
      y:"UPIITA"
    },
    {
      x:"UPIICSA",
      y:"ESIME"
    }
  ],
  km:23456,
  verificacion:[2020,2021,2022],
  getColor: function(){
    return this.color;
  },
  getKm: function(){
    return this.km + " kms.";
  },
  setKm: function(km){
    this.km = km;
  }

};

console.log(miObjeto.marca.varios[1]);
console.log(miObjeto.modelo[1].y)

/*
console.log("Años verificados -indice0-: " + miObjeto.verificacion[0]);
miObjeto.verificacion[0] = "2020b";
console.log("Años verificados -indice0-: " + miObjeto.verificacion[0]);
*/

/*
console.log("Los kms del auto son: " + miObjeto.km);

miObjeto.setKm(25789);

console.log("Nuevo KM es: " + miObjeto.km);

console.log("Los kms del auto son -metodo-: " + miObjeto.getKm());
console.log("El color del auto es: " + miObjeto.getColor());
console.log("El color del auto es -metodo-: " + miObjeto.getColor());
*/