let miJSON = '{"menu": {"id": "file","value": "File","popup": {"menuitem": [{"value": "New", "onclick": "CreateNewDoc()"},  {"value": "Open", "onclick": "OpenDoc()"},{"value": "Close", "onclick": "CloseDoc()"}]}}}';

let miObjJSON = JSON.parse(miJSON);

console.log(miObjJSON.menu.popup.menuitem[0].onclick);