const miJSON2 = '{"nombre":"Juan Perez", "boleta":2022630001, "correo":"juan@juan.com"}';

const miObj2 = JSON.parse(miJSON2);

//console.log(miObj2.correo);

const miObj3 = {
  boleta:2022630005,
  promedio:[7.5,7.8,7.09],
  grupo:"4CV4",
  carrera:"ISC"
}

const miJSON3 = JSON.stringify(miObj3);

//console.log(miJSON3);

const miJSON3b = '{"boleta":2022630005,"promedio":[7.5,7.8,7.09],"grupo":"4CV4","carrera":"ISC"}';

const miObj3b = JSON.parse(miJSON3b);

console.log(miObj3b.promedio[1]);