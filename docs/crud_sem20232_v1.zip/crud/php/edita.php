<?php
  session_start();
  if(isset($_SESSION["alumno"])){
    include("./edita_BD.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>ESCOM / Demo 20232</title>
<meta name='viewport' content='width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no'/>
<meta name="description" content="">
<meta name="keywords" content="">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link href="./../css/stickyFooter.css" rel="stylesheet">
<link href="./../materialize/css/materialize.min.css" rel="stylesheet">
<script src="./../js/libs/jquery-3.6.4.min.js"></script>
<script src="./../materialize/js/materialize.min.js"></script>
<script src="./../js/libs/justValidate.js"></script>
<script src="./../js/libs/sweetAlert.min.js"></script>
<script src="./../js/edita.js"></script>
</head>
<body>
  <header>
    <img src="./../imgs/header.jpg" class="responsive-img">
    <div class="fixed-action-btn">
      <a class="btn-floating btn-large blue">
        <i class="fas fa-ellipsis"></i>
      </a>
      <ul>
        <li><a href="./cerrarSesion.php?nombreSesion=alumno" class="btn-floating grey"><i class="fas fa-power-off"></i></a></li>
        <li><a href="./alumno.php" class="btn-floating grey"><i class="fas fa-circle-left"></i></a></li>
      </ul>
    </div>
  </header>
  <main class="valign-wrapper">
    <div class="container">
      <h1>Editar</h1>
      <form id="formEdita" autocomplete="off">
        <div class="row">
          <div class="col s12 m6 l3 input-field">
            <i class="fas fa-id-card prefix"></i>
            <label for="boleta">Boleta</label>
            <input type="text" id="boleta" name="boleta" value="<?php echo $infAlumno[0]; ?>" readonly>
          </div>
          <div class="col s12 m6 l3 input-field">
            <i class="fas fa-user prefix"></i>
            <label for="nombre">Nombre</label>
            <input type="text" id="nombre" name="nombre" value="<?php echo $infAlumno[1]; ?>">
          </div>
          <div class="col s12 m6 l3 input-field">
            <i class="fas fa-users prefix"></i>
            <label for="primerApe">Primer Apellido</label>
            <input type="text" id="primerApe" name="primerApe" value="<?php echo $infAlumno[2]; ?>">
          </div>
          <div class="col s12 m6 l3 input-field">
            <i class="fas fa-users prefix"></i>
            <label for="segundoApe">Segundo Apellido</label>
            <input type="text" id="segundoApe" name="segundoApe" value="<?php echo $infAlumno[3]; ?>">
          </div>
        </div>
        <div class="row">
          <div class="col s12 m6 l4 input-field">
            <i class="fas fa-at prefix"></i>
            <label for="correo">Correo</label>
            <input type="text" id="correo" name="correo" value="<?php echo $infAlumno[4]; ?>">
          </div>
          <div class="col s12 m6 l4 input-field">
            <i class="fas fa-mobile prefix"></i>
            <label for="telcel">TelCel</label>
            <input type="text" id="telcel" name="telcel" value="<?php echo $infAlumno[5]; ?>">
          </div>
          <div class="col s12 m6 l4 input-field">
            <i class="fas fa-asterisk prefix"></i>
            <label for="contrasena">Contraseña</label>
            <input type="password" id="contrasena" name="contrasena" readonly>
          </div>
        </div>
        <div class="row">
          <div class="col s12 m6 input-field">
            <a href="./" class="btn orange" style="width:100%;">Cancelar</a>
          </div>
          <div class="col s12 m6 input-field">
            <button type="submit" class="btn blue" style="width:100%;">Editar</button>
          </div>
        </div>
      </form>
    </div>
  </main>
  <footer class="page-footer blue">
    <div class="footer-copyright">
      <div class="container">
      © 2023 Copyright
      <a class="grey-text text-lighten-4 right" href="https://www.escom.ipn.mx">ESCOM-IPN</a>
      </div>
    </div>
  </footer>
</body>
</html>
<?php
  }else{
    header("location:./../");
  }
?>