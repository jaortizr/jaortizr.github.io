<?php
  session_start();
  include("./configBD.php");
  
  $usuario = $_POST["usuario"];
  $contrasena = md5($_POST["contrasena"]);

  $sqlCheckUsr = "SELECT * FROM usuario WHERE usuario = '$usuario' AND contrasena = '$contrasena'";
  $resCheckUsr = mysqli_query($conexion, $sqlCheckUsr);
  if(mysqli_num_rows($resCheckUsr) == 1){
    $_SESSION["login"] = true;
    header("location:./crud.php");
  }else{
    echo "Tus datos no están registrados. Favor de intentarlo nuevaente.
    <a href='./index.html'>Regresar</a>";
  }
?>