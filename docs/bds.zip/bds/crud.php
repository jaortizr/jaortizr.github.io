<?php
  session_start();
  if(!isset($_SESSION["login"])){
    header("location:./index.html");
  }else{
    echo $_SESSION["login"];
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>BDs - PHP/MySQL</title>
<meta name='viewport' content='width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no' />
<meta name="description" content="">
<meta name="keywords" content="">
<link href="" rel="stylesheet">
</head>
<body>
  <h3>Operaciones CRUD</h3>
  <h4><a href="./cerrarSesion.php?sesion=login">Cerrar Sesión</a>
  <form action="./read.php" method="post">
    <h5>Buscar (Read)</h5>
    <label for="boleta">Boleta</label>
    <input type="text" id="boleta" name="boleta"><button type="submit">Buscar</button>
  </form>
  <form action="./delete.php" method="post">
    <h5>Eliminar (Delete)</h5>
    <label for="boleta">Boleta</label>
    <input type="text" id="boleta" name="boleta"><button type="submit">Eliminar</button>
  </form>
  <form action="./update.php" method="post">
    <h5>Actualizar (Update)</h5>
    <label for="boleta">Boleta</label>
    <input type="text" id="boleta" name="boleta"><button type="submit">Actualizar</button>
  </form>
  <form action="./create.php" method="post">
    <h5>Agregar (Insert)</h5>
    <label for="boleta">Boleta:</label>
    <input type="number" id="boleta" name="boleta"><br>
    <label for="nombre">Nombre:</label>
    <input type="text" id="nombre" name="nombre"><br>
    <label for="primerApe">Primer Ape.:</label>
    <input type="text" id="primerApe" name="primerApe"><br>
    <label for="segundoApe">Segundo Ape.:</label>
    <input type="text" id="segundoApe" name="segundoApe"><br>
    <label for="correo">Correo:</label>
    <input type="text" id="correo" name="correo"><br>
    <label for="fechaNac">Fecha de Nac.:</label>
    <input type="date" id="fechaNac" name="fechaNac"><br>
    <label for="telcel">Tel/Cel:</label>
    <input type="number" id="telcel" name="telcel"><br>
    <label for="contrasena">Contraseña:</label>
    <input type="password" id="contrasena" name="contrasena"><br>
    <button type="submit">Guardar</button>
  </form>
</body>
</html>
<?php
  }
?>