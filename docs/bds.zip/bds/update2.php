<?php
  include("./configBD.php");

  $boleta = $_POST["boleta"];
  $nombre = $_POST["nombre"];
  $correo = $_POST["correo"];
  $telcel = $_POST["telcel"];

  $sqlUpdAlumno = "UPDATE alumno SET nombre = '$nombre', correo = '$correo', telcel = '$telcel' WHERE boleta = '$boleta'";
  $resUpdAlumno = mysqli_query($conexion, $sqlUpdAlumno);
  if(mysqli_affected_rows($conexion) == 1){
    echo "<h5>Se actualizó correctamente el registro con boleta $boleta.<br><a href='./index.html'>Regresar</a></h5>";
  }else{
    echo "<h5>Error. No se  pudo eliminar el registro con boleta $boleta.<br>Favor de intentarlo nuevamente<br><a href='./index.html'>Regresar</a></h5>";
  }
?>