<?php
  include("./configBD.php");

  $boleta = $_POST["boleta"];
  $sqlCheckBoleta = "SELECT * FROM alumno WHERE boleta = '$boleta'";
  $resCheckBoleta = mysqli_query($conexion, $sqlCheckBoleta);
  if(mysqli_num_rows($resCheckBoleta) == 0){
    echo "<h5>No hay datos registrados asociados a la boleta $boleta.<br>Favor de verificar datos.<br>
    <a href='./index.html'>Regresar</a>";
  }else{
    $infAlumno = mysqli_fetch_row($resCheckBoleta);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>BDs - Update</title>
<meta name='viewport' content='width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no'/>
<meta name="description" content="">
<meta name="keywords" content="">
<link href="" rel="stylesheet">
</head>
<body>
  <form action="./update2.php" method="post">
    <label for="boleta">Boleta:</label>
    <input type="text" id="boleta" name="boleta" value="<?php echo $infAlumno[0]; ?>" readonly><br>
    <label for="nombre">Nombre:</label>
    <input type="text" id="nombre" name="nombre" value="<?php echo $infAlumno[1]; ?>"><br>
    <label for="correo">Correo:</label>
    <input type="text" id="correo" name="correo" value="<?php echo $infAlumno[5]; ?>"><br>
    <label for="telcel">Tel/Cel:</label>
    <input type="text" id="telcel" name="telcel" value="<?php echo $infAlumno[6]; ?>"><br>
    <button type="submit">Actualizar</button>
  </form>
</body>
</html>
<?php
  }
?>