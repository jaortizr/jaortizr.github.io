<?php
  include("./configBD.php");

  $boleta = $_POST["boleta"];
  $sqlCheckBoleta = "SELECT * FROM alumno WHERE boleta = '$boleta'";
  $resCheckBoleta = mysqli_query($conexion, $sqlCheckBoleta);
  if(mysqli_num_rows($resCheckBoleta) == 1){
    $sqlDelBoleta = "DELETE FROM alumno WHERE boleta = '$boleta'";
    $resDelBoleta = mysqli_query($conexion, $sqlDelBoleta);
    if(mysqli_affected_rows($conexion) == 1){
      echo "<h5>Se ha eliminado el registro con boleta $boleta.<br><a href='./index.html'>Regresar</a></h5>";
    }else{
      echo "<h5>Error. No se  pudo eliminar el registro con boleta $boleta.<br>Favor de intentarlo nuevamente<br><a href='./index.html'>Regresar</a></h5>";
    }
  }else{
    echo "<h5>No hay datos registrados asociados a la boleta $boleta.<br>Favor de verificar datos.<br>
    <a href='./index.html'>Regresar</a>";
  }
?>