<?php
  include("./configBD.php");

  $boleta = $_POST["boleta"];
  $sql = "SELECT * FROM alumno WHERE boleta = '$boleta'";
  $res = mysqli_query($conexion,$sql);
  if(mysqli_num_rows($res) == 1){
    $inf = mysqli_fetch_row($res);
    echo "<h5>
    READ<br>
    Los datos asociados a la boleta $boleta son:<br>
    <ul>
      <li>Nombre: $inf[1]</li>
      <li>Primer Ape. $inf[2]: </li>
      <li>Segundo Ape.: $inf[3] </li>
      <li>Correo: $inf[4]</li>
      <li>Fecha de Nacimiento: $inf[5]</li>
      <li>Telcel: $inf[6]</li>
    </ul>
    </h5>
    <a href='./index.html'>Regresar</a>";
  }else{
    echo "<h5>No tenemos datos registrados asociados a la boleta $boleta.<br>Favor de intentarlo nuevamente.</h5>
    <a href='./index.html'>Regresar</a>";
  }
?>