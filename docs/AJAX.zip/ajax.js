$(document).ready(()=>{
  $.ajax({
    method:"POST",
    url:"./ajax.php",
    data:{boleta:"2021630005", correo:"antonio@antonio.com", telcel:"5512345678"},
    cache:false,
    success:(respAX)=>{
      let AX = JSON.parse(respAX);
      let icono = "";
      $("div#respAX").html(AX.msj);
      AX.cod == 1 ? icono = "success" : icono = "error";
      Swal.fire({
        title: "TDAW 2022-1",
        html: AX.msj,
        icon: icono
      })
    }
  });

  
});