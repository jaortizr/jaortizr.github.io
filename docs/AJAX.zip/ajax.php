<?php

$boleta = $_POST["boleta"];
$correo = $_POST["correo"];
$telcel = $_POST["telcel"];

/* Proceso la información y hago consultas a la BD */
/* ... */

$respAX = [];
$respAX["cod"] = 1;
$respAX["msj"] = "<p>Gracias. La operación se realizó correctamente</p>";
$respAX["tiempoResp"] = "5.21 s";
$respAX["auditoria"] = "2021-11-21 14:30:34";

echo json_encode($respAX);

?>