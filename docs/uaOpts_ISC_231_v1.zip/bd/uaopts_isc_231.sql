/*
SQLyog Community v13.1.9 (64 bit)
MySQL - 10.4.24-MariaDB : Database - uaopts_isc_231
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`uaopts_isc_231` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `uaopts_isc_231`;

/*Table structure for table `encuesta` */

DROP TABLE IF EXISTS `encuesta`;

CREATE TABLE `encuesta` (
  `boleta` varchar(10) DEFAULT NULL,
  `idUAO` varchar(16) DEFAULT NULL,
  `auditoria` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `encuesta` */

/*Table structure for table `estudiante` */

DROP TABLE IF EXISTS `estudiante`;

CREATE TABLE `estudiante` (
  `boleta` varchar(18) NOT NULL,
  `curp` varchar(10) NOT NULL,
  `nombre` varchar(64) NOT NULL,
  `primerApe` varchar(64) NOT NULL,
  `segundoApe` varchar(64) DEFAULT NULL,
  `correo` varchar(128) NOT NULL,
  `carrera` varchar(4) NOT NULL,
  `estatus` varchar(2) NOT NULL,
  `auditoria` datetime DEFAULT NULL,
  PRIMARY KEY (`boleta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `estudiante` */

insert  into `estudiante`(`boleta`,`curp`,`nombre`,`primerApe`,`segundoApe`,`correo`,`carrera`,`estatus`,`auditoria`) values 
('2023630001','ABCD123456','Juan','PÃ©rez','PÃ©rez','juan@juan.com','ISC','0','2022-12-16 19:10:16');

/*Table structure for table `uaoptivas` */

DROP TABLE IF EXISTS `uaoptivas`;

CREATE TABLE `uaoptivas` (
  `idUAO` varchar(16) NOT NULL,
  `nombre` varchar(64) NOT NULL,
  `carrera` varchar(4) NOT NULL,
  PRIMARY KEY (`idUAO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `uaoptivas` */

insert  into `uaoptivas`(`idUAO`,`nombre`,`carrera`) values 
('uao_isc_1','Tecnologías para la web','ISC');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
