$(document).ready(function(){

  $("select").formSelect();

  const validRegistro = new JustValidate("#formRegistro");

  validRegistro
    .addField("#boleta", [
      {
        rule: "required",
        errorMessage: "Falta tu Número de Boleta"
      },
      {
        rule: "minLength",
        value: 8,
        errorMessage: "Al menos 8 digitos"
      },
      {
        rule: "maxLength",
        value: 10,
        errorMessage: "Máximo de 10 digitos"
      }
    ])
    .addField("#curp",[
      {
        rule: "required",
        errorMessage: "Falta tu CURP"
      },
      {
        rule: "minLength",
        value: 18,
        errorMessage: "Formato incorrecto"
      },
      {
        rule: "maxLength",
        value: 18,
        errorMessage: "Formato incorrecto"
      }
    ])
    .addField("#nombre",[
      {
        rule: "required",
        errorMessage: "Falta tu nombre"
      }
    ])
    .addField("#primerApe",[
      {
        rule: "required",
        errorMessage: "Falta tu primer apellido"
      }
    ])
    .addField("#segundoApe",[
      {
        rule: "required",
        errorMessage: "Falta tu segundo apellido"
      }
    ])
    .addField('#correo', [
      {
        rule: "required",
        errorMessage: 'Falta tu correo',
      },
      {
        rule: "email",
        errorMessage: "Formato invalido"
      }
    ])
    .addField("#carrera",[
      {
        rule: "required",
        errorMessage: "Falta tu carrera"
      }
    ])
    .onSuccess((e)=>{
      e.preventDefault();
      $("form#formRegistro").submit();
    });

});