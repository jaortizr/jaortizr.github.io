<?php
  $correoGmail = "tucorreo@gmail.com";
  $passGmail = "passwordCorreo";
?>