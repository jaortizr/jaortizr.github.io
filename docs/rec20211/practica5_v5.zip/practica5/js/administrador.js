$(document).ready(function(){
  $('.fixed-action-btn').floatingActionButton();
  $('.tooltipped').tooltip();
  
  $(".ver").click(function(){
    let boleta = $(this).attr("data-boleta");
    $.ajax({
      method:"POST",
      url:"./administradorVer_AX.php",
      data:{boleta:boleta},
      cache:"false",
      success:function(respAX){
        let AX = JSON.parse(respAX);
        $.alert({
          title:"TWeb 2021-1",
          content:"<h5 class='blue-text'>Boleta: "+AX[0]+"<br>Nombre: "+AX[1]+"<br>Correo: "+AX[2]+"<br>Fecha de Nacimiento: "+AX[3]+"<br>Auditoria: "+AX[6]+"</h5>",
          theme:"supervan",
          onDestroy:function(){
          }
        });
      }
    });
  });

  $(".editar").click(function(){
    alert("ED -> " + $(this).attr("data-boleta"));
  });

  $(".eliminar").click(function(){
    alert("EL -> " + $(this).attr("data-boleta"));
  });

  $(".pdf").click(function(){
    let boleta = $(this).attr("data-boleta");
    window.location.replace("./administradorPDF.php?boleta="+boleta);
  });

  $(".correo").click(function(){
    alert("CO -> " + $(this).attr("data-boleta"));
  });
});