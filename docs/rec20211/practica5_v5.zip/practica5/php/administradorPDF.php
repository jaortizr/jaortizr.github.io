<?php
  include("./configBD.php");
  include("./fpdf/fpdf.php");
  
  $boleta = $_GET["boleta"];

  $sqlInfAlmn = "SELECT * FROM alumno WHERE boleta = '$boleta'";
  $resInfAlmn = mysqli_query($conexion, $sqlInfAlmn);
  $infAlmn = mysqli_fetch_row($resInfAlmn);

  $pdf = new FPDF();
  $pdf->AddPage();
  $pdf->SetTextColor(0,0,255);
  $pdf->SetFont('Arial','B',16);
  $pdf->Cell(40,10,"Nombre: ".utf8_decode($infAlmn[1]));
  $pdf->Cell(40,30,"Boleta: ".$infAlmn[0]);
  $pdf->Cell(40,50,"Correo: ".$infAlmn[2]);
  //$pdf->Output("F","practica5.pdf");
  $pdf->Output();
?>