<?php
  include("./configBD.php");

  $boleta = $_POST["boleta"];

  $sqlVerAlmn = "SELECT * FROM alumno WHERE boleta = '$boleta'";
  $resInfAlmn = mysqli_query($conexion, $sqlVerAlmn);
  $infAlmn = mysqli_fetch_row($resInfAlmn);
  
  echo json_encode($infAlmn);
?>