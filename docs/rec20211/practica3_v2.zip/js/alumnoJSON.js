var alumno = '{"encabezado":{"escudoIPN":"./imgs/logoIPN_80.png","titulos":"Instituto Polit&eacute;cnico Nacional<br>Escuela Superior de C&oacute;mputo","escudoESCOM":"./imgs/escudoESCOM_80.jpg"},"introduccion":"Lorem ipsum dolor sit amet, consectetur adipiscing elit. In laoreet non sapien nec lobortis. Vestibulum ut enim a purus tempus aliquet. Vivamus auctor in diam in gravida. Vestibulum non nunc quis nunc fringilla faucibus sit amet a tellus. Praesent condimentum neque cursus lorem fringilla ullamcorper. Fusce at efficitur metus.","identificacion":{"nombre":"José Antonio","primerApe":"Ortiz","segundoApe":"Ramírez"},"contacto":{"direccion":" Av. Juan de Dios Batiz esq. Miguel Othón de Mendizábal","telefono":5557296000,"movil":5512345678,"email":"micorreo@dominio.com"},"procedimiento":["Praesent vulputate neque vitae massa gravida malesuada.","Morbi at elit sed ligula feugiat scelerisque.","Nam non mauris hendrerit, elementum elit nec, ullamcorper ipsum.","Nulla pharetra dolor vel interdum facilisis.","Donec accumsan turpis vel neque pulvinar lacinia."],"documentos":["Curabitur consectetur neque nec ligula convallis, vitae pulvinar urna consequat.","Duis sed orci imperdiet, viverra dui at, condimentum mi.","Vivamus at augue in diam vestibulum vehicula pulvinar vitae urna."],"horario":[{"ua":"Tecnologías para la web","clases":["13:30 a 15 horas","13:30 a 15 horas","---","13:30 a 15 horas","---"]},{"ua":"Ingeniería de software","clases":["---","12 a 13:30 horas","12 a 13:30 horas","---","12 a 13:30 horas"]},{"ua":"Base de Datos","clases":["10:30 a 12 horas","10:30 a 12 horas","10:30 a 12 horas","---","---"]}]}';

/*
{
  "encabezado":{
    "escudoIPN":"./imgs/logoIPN_80.png",
    "titulos":"Instituto Polit&eacute;cnico Nacional<br>Escuela Superior de C&oacute;mputo",
    "escudoESCOM":"./imgs/escudoESCOM_80.jpg"
  },
  "introduccion":"Lorem ipsum dolor sit amet, consectetur adipiscing elit. In laoreet non sapien nec lobortis. Vestibulum ut enim a purus tempus aliquet. Vivamus auctor in diam in gravida. Vestibulum non nunc quis nunc fringilla faucibus sit amet a tellus. Praesent condimentum neque cursus lorem fringilla ullamcorper. Fusce at efficitur metus.",
  "identificacion": {
    "nombre": "José Antonio",
    "primerApe": "Ortiz",
    "segundoApe": "Ramírez"
  },
  "contacto": {
    "direccion": " Av. Juan de Dios Batiz esq. Miguel Othón de Mendizábal",
    "telefono": 5557296000,
    "movil": 5512345678,
    "email": "micorreo@dominio.com"
  },
  "procedimiento": [
    "Praesent vulputate neque vitae massa gravida malesuada.",
    "Morbi at elit sed ligula feugiat scelerisque.",
    "Nam non mauris hendrerit, elementum elit nec, ullamcorper ipsum.",
    "Nulla pharetra dolor vel interdum facilisis.",
    "Donec accumsan turpis vel neque pulvinar lacinia."
  ],
  "documentos": [
    "Curabitur consectetur neque nec ligula convallis, vitae pulvinar urna consequat.",
    "Duis sed orci imperdiet, viverra dui at, condimentum mi.",
    "Vivamus at augue in diam vestibulum vehicula pulvinar vitae urna."
  ],
  "horario": [
    {
      "ua": "Tecnologías para la web",
      "clases": [
        "13:30 a 15 horas",
        "13:30 a 15 horas",
        "---",
        "13:30 a 15 horas",
        "---"
      ]
    },
    {
      "ua": "Ingeniería de software",
      "clases": [
        "---",
        "12 a 13:30 horas",
        "12 a 13:30 horas",
        "---",
        "12 a 13:30 horas"
      ]
    },
    {
      "ua": "Base de Datos",
      "clases": [
        "10:30 a 12 horas",
        "10:30 a 12 horas",
        "10:30 a 12 horas",
        "---",
        "---"
      ]
    }
  ]
}
*/