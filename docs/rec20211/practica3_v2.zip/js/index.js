let infAlumno = JSON.parse(alumno);
    
let escudoIPN = document.getElementById("escudoIPN");
escudoIPN.setAttribute("src",infAlumno.encabezado.escudoIPN);

let escudoESCOM = document.getElementById("escudoESCOM");
escudoESCOM.setAttribute("src",infAlumno.encabezado.escudoESCOM);

let ipnescom = document.getElementById("ipnescom");
ipnescom.innerHTML = infAlumno.encabezado.titulos;
ipnescom.className += " guinda";

let p = document.createElement("p");
p.innerHTML = infAlumno.introduccion;
let introduccion = document.getElementById("introduccion");
introduccion.appendChild(p);

let identificacion = document.getElementById("identificacion");
identificacion.innerHTML = infAlumno.identificacion.nombre+" "+infAlumno.identificacion.primerApe+" "+infAlumno.identificacion.segundoApe;
identificacion.style.color = "#006699";

document.getElementById("foto").style.backgroundColor = "#0088CC";
document.getElementById("contacto").style.backgroundColor = "#0099E6";

let direccion = document.getElementById("direccion");
direccion.innerHTML = infAlumno.contacto.direccion;

let telefono = document.getElementById("telefono");
telefono.innerHTML = infAlumno.contacto.telefono;

let movil = document.getElementById("movil");
movil.innerHTML = infAlumno.contacto.movil;

let email = document.getElementById("email");
email.innerHTML = infAlumno.contacto.email;

let contProcedimiento = "<ul>";
for(let i = 0; i < infAlumno.procedimiento.length; i++){
    contProcedimiento += "<li>"+infAlumno.procedimiento[i]+"</li>";
}
contProcedimiento += "</ul>"
let procedimiento = document.getElementById("procedimiento");
procedimiento.innerHTML = contProcedimiento;

let contDocumentos = "<ol>";
for(let i = 0; i < infAlumno.documentos.length; i++){
    contDocumentos += "<li>"+infAlumno.documentos[i]+"</li>";
}
contDocumentos += "</ol>"
let documentos = document.getElementById("documentos");
documentos.innerHTML = contDocumentos;

let contHorario = "";
for(let i = 0; i < infAlumno.horario.length; i++){
    contHorario += "<tr><td>"+infAlumno.horario[i].ua+"</td>";
    for(let x = 0; x < infAlumno.horario[i].clases.length; x++){
        contHorario += "<td>"+infAlumno.horario[i].clases[x]+"</td>";
    }
    contHorario += "</tr>";
}
let horario = document.getElementById("horario");
horario.innerHTML = contHorario;