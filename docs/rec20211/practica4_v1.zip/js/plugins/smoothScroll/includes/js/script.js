// Usage
'use strict';

// jQuery noConflict declaration
jQuery.noConflict();
// run jQuery
jQuery(document).ready(function( $ ){

    // jQuery Smooth Scroll Window
    $(this).smoothScrollWindow();

});