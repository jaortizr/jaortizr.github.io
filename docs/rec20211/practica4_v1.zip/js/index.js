$(document).ready(function(){
    let textos = '{"msjs":["<h5 class=\'center-align\'>Error. Favor de intentarlo nuevamente.</h5>","<h5 class=\'center-align\'>OK. Información recibida. Gracias :)</h5>"]}';
    let textosJS = JSON.parse(textos);

    $(this).smoothScrollWindow();

    $('.sidenav').sidenav();

    var rango = [2000,2020];
    $('.datepicker').datepicker({
      format:"yyyy-mm-dd",
      autoClose:true,
      minDate:new Date(2020,0,1),
      maxDate:new Date(2020,11,31),
      yearRange:rango,
      i18n:{
        months:['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'],
        monthsShort:["Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic"],
        weekdays:["Domingo","Lunes","Martes","Miércoles","Jueves","Viernes","Sábado"],
        weekdaysShort:["Dom","Lun","Mar","Mie","Jue","Vie","Sab"],
        weekdaysAbbrev:["D","L","M","M","J","V","S"]
      }
    });

    $('.carousel.carousel-slider').carousel({
      fullWidth: true,
      indicators:true
    });

    $("form#formUnete").validetta({
      bubblePosition: 'bottom',
      bubbleGapTop: 10,
      bubbleGapLeft: -5,
      onValid:function(e){
        e.preventDefault();
        let nombre = $("input#nombre").val();
        let codigo = 1;
        $.alert({
          title:"<h2>TWeb / 2021-1</h2>",
          content:"<h6 class='center-align'>"+nombre+":</h6>"+textosJS.msjs[codigo],
          theme:"dark",
          icon:"fab fa-servicestack fa-3x",
          type:"purple",
          boxWidth:"50%",
          useBootstrap: false
        });
      }
    });

    $("#elMenu").stickme();
});