<?php
    $conexion = mysqli_connect("localhost","root","","sem_20211");
    $sql = "SELECT * FROM alumno";
    $resultado = mysqli_query($conexion,$sql);
    $numFilas = mysqli_num_rows($resultado);

    $alumnos = "";
    while($filas = mysqli_fetch_array($resultado,MYSQLI_BOTH)){
        $alumnos .= "<tr><td>".$filas['usuario']."</td><td>".$filas[1]."</td></tr>";
    }
?>
<table>
    <thead>
        <tr><th>Usuario</th><th>Contrasena</th>
    </thead>
    <tbody>
        <?php echo $alumnos; ?>
    </tbody>
</table>