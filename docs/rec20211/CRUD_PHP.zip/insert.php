<?php
    //Recupero información del front-end
    $usuario = $_REQUEST["usuario"];
    $contrasena = $_REQUEST["contrasena"];

    //Conexión y autentificación a la BD
    $conexion = mysqli_connect("localhost","root","","sem_20211");
    //Preparación del SQL a utilizar
    $sql = "INSERT INTO alumno VALUES('$usuario','$contrasena')";
    //Ejecución de la consulta SQL sobre la BD
    $resultado = mysqli_query($conexion,$sql);


    echo "Bienvenido: ".$usuario. "!!! Tu contrasena es: ".$contrasena;
?>