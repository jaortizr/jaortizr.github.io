<!DOCTYPE html>
<html>
<script>
    
</script>
<body>

<h1>Mi primer PHP</h1>

<?php
    $variable = 2020;
    $Variable = 12.34;
    $VARIABLE = "ESCOM";
    echo $VARIABLE;
    echo "<h1 style='color:blue;'>".$VARIABLE."</h1>";

    function suma(){
        return 4+9;
    }

    function suma2($x, $y){
        return $x + $y;
    }

    echo suma();

    echo "<br>".suma2($variable, $Variable);
?>

</body>
</html>