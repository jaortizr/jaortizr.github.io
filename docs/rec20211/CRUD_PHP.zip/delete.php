<?php
    $usuario = $_REQUEST["usuario"];

    $conexion = mysqli_connect("localhost","root","","sem_20211");
    $sql = "DELETE FROM alumno WHERE usuario = '$usuario'";
    $resultado = mysqli_query($conexion,$sql);
    $filasAfectadas = mysqli_affected_rows($conexion);

    echo $filasAfectadas;

?>