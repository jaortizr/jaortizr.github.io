<?php
    $usuario = $_REQUEST["usuario"];

        
    $conexion = mysqli_connect("localhost","root","","sem_20211");
    $sql ="UPDATE alumno SET usuario = '$usuario' WHERE contrasena = 'sdflsjfklsjsl'";
    $resultado = mysqli_query($conexion,$sql);
    $filasAfectadas = mysqli_affected_rows($conexion);

    echo $filasAfectadas;
?>