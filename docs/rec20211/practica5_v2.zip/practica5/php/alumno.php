<?php
  session_start();
  if(isset($_SESSION["boleta"])){
    $boleta = $_SESSION["boleta"];
    $conexion = mysqli_connect("localhost","root","","sem20211");
    $sqlInfAlumno = "SELECT * FROM alumno WHERE boleta = '$boleta'";
    $resInfAlumno = mysqli_query($conexion, $sqlInfAlumno);
    $infAlumno = mysqli_fetch_row($resInfAlumno);

    echo "$infAlumno[0] $infAlumno[1] $infAlumno[2] $infAlumno[3]";
    echo "<br>";

  echo "<a href='./cerrarSesion.php?nombreSesion=boleta'>Cerrar Sesi&oacute;n</a>";

  }else{
    header("location:./../login.html");
  }

  
?>