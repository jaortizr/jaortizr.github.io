<?php
  session_start();

  $_SESSION["boleta"] = "2020630001";
  $x = "ESCOM";

  echo "Sesiones 1 <br>";
  echo $x;
  echo "<br>";
  echo $_SESSION["boleta"];
?>