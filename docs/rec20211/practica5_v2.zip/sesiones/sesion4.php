<?php
  session_start();

  if(isset($_SESSION["boleta"])){
    echo $_SESSION["boleta"];
  }else{
    header("location:http://www.ipn.mx");
  }

?>