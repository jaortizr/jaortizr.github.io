<?php
  session_start();

  echo "Sesiones 3 <br>";
  echo $x;
  echo "<br>";
  echo $_SESSION["boleta"];
?>