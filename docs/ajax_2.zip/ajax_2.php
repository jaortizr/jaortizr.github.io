<?php
    $boleta = $_POST["boleta"];
    $contrasena = $_POST["contrasena"];
    $mensaje = "El servidor contesta:<br>$boleta & $contrasena";

    //Una de las posibilidades que tenemos es que podemos/debemos configurar y definir que es lo que el servidor nos va a responder para que de esta manera el procesamiento por parte del front-end sea más sencilla; así pues en este ejemplo vamos a preparar una respuesta de servidor en formato JSON/HTML; para lo que aprovcharemos los arreglos asociativos que casualmente tienen una estructura interna/lógica muy parecida a JSON; la intención es poner en un arreglo asociativo todo aquello que necesitamos que el servidor nos responda y con ayuda de PHP tomar dicho arreglo y convertirlo a JSON

    $resp = []; //Un arreglo generico en PHP
    $resp["msj"] = $mensaje; //Arreglo asociativo ya que su índice es una cadena
    $resp["cod"] = 1;

    //La magia se hace con la funcion json_encode() de PHP
    $respAX = json_encode($resp);
    
    //En este contexto donde se pretende aplicar el concepto de AJAX, todo 'echo' se tomará como respuesta que se regresará de manera asíncrona al front-end, todo esto gestionado por su JS.
    echo $respAX;
?>