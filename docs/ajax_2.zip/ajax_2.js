$(document).ready(function(){
    /*
        Variantes al ejemplo anterior: los datos que se van a enviar al servidor se obtienen mediante serialize(), lo que hace es recorrer el formulario que se le indique y con base en el nombre de cada componente y el valor que el usuario capture armará una cadena con la siguiente estructura:
        nombreComponente=valor&nombreComponente2=valor2,...
        cada pareja componente=valor, encaso de que sean 2 o más, se separan con un '&'
    */

   $("#formAJAX2").submit(function(e){
        e.preventDefault();
        var boleta = $("#boleta").val();
        var contrasena = $("#contrasena").val();
        var formulario = $("#formAJAX2").serialize();
        alert(formulario);
        $.ajax({
            method:"POST", //similar al atributo 'method' de la etiqueta FORM
            url:"./ajax_2.php", //similar al atributo 'action' de la etiqueta FORM
            data: formulario,
            cache:false, //evitamos que la página del servidor se almacene en la cache del navegador
            success:function(respAX){ //cuando el servidor de la respuesta ¿qué haremos con ella?
                //Todo el contexto nos pone en alerta ya que sabemos que esperamos un JSON como respuesta del sevidor, pero como lo hemos platicado: JSON NO HACE NADA
                alert("JSON que regresa el servidor: "+respAX);
                //Para poder tener acceso a cada valor que contiene el JSON hay que convertirlo en algo que JS entienda, para eso usamos JSON.parse()
                var AX = JSON.parse(respAX);
                alert("Mensaje: "+AX.msj+"\nCodigo: "+AX.cod); //Hacer esto implica que estan involucrados en el diseño del sistema al conocer la estrutura del JSON que se generará. Con esta posibilidad de acceder a la información que devuelve el servidor, nosotros definimos como manejamos dicha información, ya sea como en este ejemplo a un alert() o intentar integrar plugins como confirm.js o para modificar el contenido/presentación de alguna sección de nuestra página HTML
            }
        });
   })
});