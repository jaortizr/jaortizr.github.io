$(document).ready(()=>{
  let objProductos = JSON.parse(productos);
  let arrProductos = Array.from(objProductos);
  
  let filasProductos = "";
  let contCols = 0;

  arrProductos.forEach((obj)=>{
    if(contCols % 4 == 0){
      filasProductos += `<div class='row'>`;
    }
    filasProductos += `
      <div class='col s12 m6 l3'>
        <div class='card'>
          <div class='card-image'>
            <img src='${obj.images[0]}'><span class='card-title'>${obj.title}</span>
          </div>
          <div class='card-content'>
            <p>${obj.description}</p>
          </div>
          <div class='card-action'>
            \$ ${obj.price} / Categoria: ${obj.category.name}
          </div>
        </div>
      </div>
    `;
    if(contCols % 4 == 3){
      filasProductos += `</div>`;
    }
    contCols++;
  });
  
  $("#filasProductos").html(filasProductos);
});