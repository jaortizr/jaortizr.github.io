$(document).ready(()=>{
  let objProductos = JSON.parse(productos);
  let arrProductos = Array.from(objProductos);
  let filasProductos = "";
  
  arrProductos.forEach((obj)=>{
    filasProductos += `
      <tr>
        <td>${obj.id}</td>
        <td>${obj.title}</td>
        <td>${obj.description}</td>
        <td><img src='${obj.images[0]}' class='materialboxed cambiaTamImg'><br>
        Categoria: ${obj.category.name}</td>
      </tr>
    `;
  });

  $("#filasProductos").html(filasProductos);
  $(".materialboxed").materialbox();
  $("table#tblProductos").filterTable({
    label:"Buscar",
    placeholder:"en esta tabla"
  });
  $("img.cambiaTamImg").aeImageResize({
    height: 160,
    width: 160
  });
});