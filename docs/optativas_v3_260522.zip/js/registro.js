$(document).ready(function(){
  $('select').formSelect();

  $("form#formRegistro").validetta({
    bubblePosition: "bottom",
    bubbleGapTop: 10,
    bubbleGapLeft: -5,
    onValid:(e)=>{
      e.preventDefault();
      $.ajax({
        method:"post",
        url:"./pages/registro_AX.php",
        data:$("form#formRegistro").serialize(),
        cache:false,
        success:(respAX)=>{
          let AX = JSON.parse(respAX);
          Swal.fire({
            title: 'TDAW-IIA',
            text: AX.msj,
            icon: 'info',
            confirmButtonText: 'OK'
          });
          if(AX.cod == 1){
            $("form")[0].reset();
          }
        }
      });
    }
  });
});