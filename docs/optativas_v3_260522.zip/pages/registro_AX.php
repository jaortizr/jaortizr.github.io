<?php
  include("./configBD.php");

  $nombre = $_POST["nombre"];
  $primerApe = $_POST["primerApe"];
  $segundoApe = $_POST["segundoApe"];
  $correo = $_POST["correo"];
  $carrera = $_POST["carrera"];
  $contrasena = md5($_POST["contrasena"]);

  $respAX = [];

  $sqlCheckAlmn = "SELECT * FROM alumno WHERE correo = '$correo'";
  $resCheckAlmn = mysqli_query($conexion, $sqlCheckAlmn);
  if(mysqli_num_rows($resCheckAlmn) == 1){
    $respAX["cod"] = 2;
    $respAX["msj"] = "Error. Correo ya registrado.";
  }else{
    $sqlInsAlmn = "INSERT INTO alumno VALUES('$nombre','$primerApe','$segundoApe','$correo','$carrera','$contrasena',NOW())";
    $resInsAlmn = mysqli_query($conexion, $sqlInsAlmn);
    if(mysqli_affected_rows($conexion) == 1){
      $respAX["cod"] = 1;
      $respAX["msj"] = "Gracias. Datos guardados.";
    }else{
      $respAX["cod"] = 0;
      $respAX["msj"] = "Error. No se pudo guardar los datos. Favor de intentarlo nuevamente.";
    }
  }

  echo json_encode($respAX);
?>