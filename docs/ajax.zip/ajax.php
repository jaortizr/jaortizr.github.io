<?php
sleep(3);
  $boleta = $_POST["boleta"];
  $correo = $_POST["correo"];

  echo "<h4>AJAX 160522 - $boleta ... $correo</h4>";
?>