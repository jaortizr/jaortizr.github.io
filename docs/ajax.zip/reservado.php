<?php
  session_start();
  if(isset($_SESSION["boleta"])){
    $boleta = $_SESSION["boleta"];
    $conexion = mysqli_connect("localhost","root","","sem20222_iia");
    $sql = "SELECT * FROM alumno WHERE boleta = '$boleta'";
    $res = mysqli_query($conexion, $sql);
    $inf = mysqli_fetch_row($res);
    echo "<h1>Bienvenid@: $inf[1]";

  }else{
    header("location:formulario.html");
  }
?>