<?php
  $usuario = $_POST["usuario"];
  $contrasena = $_POST["contrasena"];

  echo "Peticion AJAX del 180522 -> $usuario y $contrasena";
?>