<?php
  session_start();
  $boleta = $_POST["boleta"];
  $contrasena = md5($_POST["contrasena"]);
  $codigo = 0;

  $conexion = mysqli_connect("localhost","root","","sem20222_iia");
  $sql = "SELECT * FROM alumno WHERE boleta = '$boleta' AND contasena = '$contrasena'";
  $res = mysqli_query($conexion, $sql);
  $inf = mysqli_fetch_row($res);
  $respAX = [];
  if(mysqli_num_rows($res) == 1){
    $_SESSION["boleta"] = $boleta;
    $respAX["cod"] = 1;
    $respAX["msj"] = "Bienvenido 190522";
  }else{
    $respAX["cod"] = 0;
    $respAX["msj"] = "Error";
  }

  echo json_encode($respAX);
?>