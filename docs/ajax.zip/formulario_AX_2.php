<?php
  $correo = $_POST["correo"];
  echo "Tu correo es: $correo";
?>