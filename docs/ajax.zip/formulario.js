      $(document).ready(()=>{
        $.ajax({
          method:"post",
          url:"./formulario_AX_2.php",
          data:{correo:"uncorreo@correo.com",telcel:"5512345678"},
          cache:false,
          success:(respAX)=>{
            alert(respAX);
          }
        });



        $("form#formEntrar").validetta({
          onValid:(e)=>{
            e.preventDefault();
            $.ajax({
              method:"post",
              url:"./formulario_AX.php",
              data:$("form#formEntrar").serialize(),
              cache:false,
              success:(respAX)=>{
                let AX = JSON.parse(respAX);
                if(AX.cod == 1){
                  alert(AX.msj);
                  window.location.href = "./reservado.php";
                }else{
                  alert("Error, Favor de intentarlo nuevamente");
                }
              }
            });
          }
        });
      });