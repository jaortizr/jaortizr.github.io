<?php
/*
    Vamos a revisar como es que de una manera sencilla y rápida PHP nos permite conectarnos a una BD en MySQL y acceder a ésta para poder hacer las operaciones CRUD correspondientes.
    - Suponemos que la BD ya esta creada y disponible en MySQL.
    - En función a la herramienta _AMP que hayan elegido, deben identificar el usuario que por default se genero en MySQL, que en la mayoría de los casos, si no hicieron modificaciones es 'root' y contraseña ''.
    - El manejo de la BD, fuera de PHP, se puede hacer con diversas herramientas: Workbench, PHPMyAdmin, MySQLYog, consola, etc. queda a su gusto.
    - La BD que utilizaré es muy sencilla, solo para fines didácticos, en la vida real serán modelos de datos mucho más complejos.
    - El código sql se los comparto para que lo repliquen en sus servidores.
    - La tabla única tiene la siguiente estrutura:
    alumno(boleta,nombre,primerApe,segundoApe,correo,fechaNac,contrasena,auditoria)
    - Se usará el módulo MySQLi de PHP, en su versión estructural, para realizar la conexión a la BD (Este módulo cuenta tambien con una versión orientada a objetos por si es de su interes).
    - Se consideraran condiciones ideales, es decir, no haremos manejo de excepciones.
*/

// 1. Conectarme  al servidor MySQL, para ello necesitamos indicar: el servidor donde se encuentra en MySQL, en este caso como el código PHP y la BD MySQL se encuentrán en el mismo equipo de cómputo, lo referenciamos como 'localhost', en otros casos deberiamos indicar un dominio o una dirección IP; el usuario con los permisos adecuados sobre la BD de nuestro interes, en este caso 'root', aunque se recomienda que se genere uno diferente por aspectos de seguridad; la contraseña asignada al usuario con el que pretendemos identificarnos ante la BD, en este caso ''; y finalmente la BD con la que queremos trabajar, es muy probable que en un mismo servidor haya muchas BDs, en este caso la que usaremos es 'sem20202'. Si no hay ningun inconveniente tendremos una conexión abierta al sevidor, podemos tener tantas conexinones abiertas como necesitemos o nos permita el servidor. Esto nos ayuda par no tener que identificarnos cada vez que pretendamos una operación nueva sobre la BD.
$conexion = mysqli_connect("localhost","root","","sem20202");
// 2. Prepara la instrucción SQL necesaria para raalizar la operación que necesites
$sql = "SELECT * FROM alumno";
// 3. Ejecuta la consulta a la BD y resguarda el resultado que te dé MySQL, en función al tipo de operación que se haga será lo que tendremos que revisar: R(un arreglo de las filas que cumplen la condición impuesta) y C,U,D (cuantas filas fueron afectadas por esta operación). Se usa la función mysqli_query(), necesita la conexión con la que se hará la operación y la instrucción SQL bien escrita
$resultado = mysqli_query($conexion, $sql);
// 4. Validar el resultado en función a la operación realizada
$numFilasResultado = mysqli_num_rows($resultado);
// 5. Gestionar la presentación de los resultados
echo "Tenemos $numFilasResultado registro(s) en la tabla 'alumno' de nuestra BD";
// Listo!!! Así de facil. Claro que no será siempre así, pero eso es otra historia...
?>