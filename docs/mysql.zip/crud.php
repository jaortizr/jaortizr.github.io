<?php
    //Les comparto el código mínimo necesario para las operaciones CRUD con PHP-MySQL, sin considerar manejo de excepciones (llaves primarias, llaves foráneas, errores de escritura, etc.)

    $conexion = mysqli_connect("localhost","root","","sem20202");

    function verAlumnos(){
        global $conexion;
        $sqlSelect = "SELECT * FROM alumno";
        $resSelect = mysqli_query($conexion, $sqlSelect);
        $datos = "<p>";
        while($filas = mysqli_fetch_array($resSelect)){
            $datos .= "$filas[0] - $filas[1] $filas[2] $filas[3] - $filas[4] <br>";
        }
        $datos .= "</p>";

        echo $datos;
    }

    verAlumnos();
    
    //CREATE
    $sqlInsert = "INSERT INTO alumno VALUES('2020630002','Ana','Anaya','Anaya','ana@ana.com','1993-08-13',MD5('anaanaya'),NOW())";
    $resInsert = mysqli_query($conexion, $sqlInsert);
    $infInsert = mysqli_affected_rows($conexion);
    echo "Se insertaron $infInsert registro(s) a la tabla 'alumno'<br>";

    verAlumnos();

    //READ
    $sqlSelect = "SELECT * FROM alumno";
    $resSelect = mysqli_query($conexion, $sqlSelect);
    $infSelect = mysqli_num_rows($resSelect);
    echo "Se tienen $infSelect registro(s) en la tabla 'alumno'<br>";

    //UPDATE
    $sqlUpdate = "UPDATE alumno SET correo='anita@ana.com' WHERE boleta='2020630002'";
    $resUpdate = mysqli_query($conexion, $sqlUpdate);
    $infUpdate = mysqli_affected_rows($conexion);
    echo "Se actualizaron $infUpdate registro(s) de la tabla 'alumno'<br>";

    verAlumnos();

    //DELETE
    $sqlDelete = "DELETE FROM alumno WHERE boleta = '2020630002'";
    $resDelete = mysqli_query($conexion, $sqlDelete);
    $infDelete = mysqli_affected_rows($conexion);
    echo "Se eliminaron $infUpdate registro(s) de la tabla 'alumno'<br>";

    verAlumnos();
?>