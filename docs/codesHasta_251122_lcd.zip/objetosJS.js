const miAuto = {
  color:"azul",
  tipo:"sedan",
  km:12345,
  verificado:[2020,2021,2022],
  puertas:4,
  marca:[
    {nombre:"SEAT", pais:"España"},
    {nombre:"VW", pais:"Alemania"}
  ],
  modelo:2020,
  setKm:function(km){
    this.km = km;
  },
  getKm:function(){
    return this.km;
  }
};

miAuto.marca[0].pais = "Portugal";

console.log("El pais de origen modificado es: " + miAuto["marca"][0]["pais"]);

/*


console.log("El pais de origen modificado es: " + miAuto.marca[0].pais);

console.log("El pais de origen es: " + miAuto.marca[1].pais);

console.log("La marca de mi auto es: " + miAuto.marca);
console.log("La marca de mi auto es -arreglo-: " + miAuto["marca"]);

miAuto.setKm(23456);

console.log("Los kms de mi auto son: " + miAuto.km);
console.log("Los Km de mi auto son -metodo-: " + miAuto.getKm());

console.log("Años verificados -indice2-: " + miAuto.verificado[2]);
*/