document.addEventListener("DOMContentLoaded",()=>{
  const objDB = JSON.parse(jsonDB);
  const numPersonajes = objDB.length;
  const nombresDB = getValues(objDB,"name");
  const especiesDB = getValues(objDB,"specie");
  const rolesDB = getValues(objDB,"role");
  const estatusDB = getValues(objDB,"status");
  const universosDB = getValues(objDB,"universe");

  let htmlPersonajes = "";
  for(let i = 0; i < numPersonajes; i++){
    htmlPersonajes += "<div class='fila'><div class='sm-full'><h1>"+nombresDB[i]+"</h1><p>"+lorem+"</p></div></div>";
    htmlPersonajes += "<div class='fila'><div class='sm-full md-third'><img src='"+objDB[i].imageUrl+"'></div><div class='sm-full md-2third'><h3>Planeta de Origen: "+objDB[i].originplanet+"</h3><p>"+lorem+"<h3>Especie: "+especiesDB[i]+"</h3><p>"+lorem+"<h3>Rol: "+rolesDB[i]+"</h3><p>"+lorem+"</p><h3>Estatus: "+estatusDB[i]+"</h3><h3>Universo: "+universosDB[i]+"</h3></div></div>";
  }

  document.querySelector("div.container").innerHTML = htmlPersonajes;
});