const miJSON = '{"nombre":"Juan Perez", "edad":23, "correo":"juan@juan.com"}';

const menu = ' {"id": "file","value": "File","popup": {  "menuitem": [{"value": "New", "onclick": "CreateNewDoc()"},  {"value": "Open", "onclick": "OpenDoc()"},{"value": "Close", "onclick": "CloseDoc()"}]}}';

const objMenu = JSON.parse(menu);

//let objJSON = JSON.parse(miJSON);

console.log(objMenu.popup.menuitem[1].onclick);