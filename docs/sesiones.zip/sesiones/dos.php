<?php
  session_start();
  echo "Archivo 2: ".$_SESSION["b1"];
  echo "<a href='./tres.php'>Tres</a>";
?>