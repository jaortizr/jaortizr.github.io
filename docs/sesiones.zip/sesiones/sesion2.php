<?php
  session_start();
  $_SESSION["boleta2"] = "2022630012";
  $boletaLocal2 = "2022630002";

  echo $boletaLocal2;
  echo "<br> Session 'boleta': ".$_SESSION["boleta"];
?>