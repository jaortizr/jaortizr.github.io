<?php
  session_start();
  echo "Archivo 3: ".$_SESSION["b1"];
  echo "<a href='./uno.php'>Uno</a>";
?>