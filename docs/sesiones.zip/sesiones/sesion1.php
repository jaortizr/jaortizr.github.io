<?php
  session_start();
  $_SESSION["boleta"] = "2022630011";
  $_SESSION["usuario"] = "JAOR";
  $boletaLocal = "2022630001";

  echo $boletaLocal;
  echo "<br>".$_SESSION["boleta"];
  echo "<a href='./sesion2.php'>"
?>