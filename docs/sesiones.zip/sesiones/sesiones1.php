<?php
  session_start();
  $_SESSION["boleta"] = "2021630005";
  $_SESSION["correo"] = "juan@juan.com";

  echo $_SESSION["boleta"]."-".$_SESSION["correo"]."-".$_SESSION["telcel"];



?>