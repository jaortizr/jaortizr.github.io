<?php
  session_start();
  if(isset($_SESSION["nombre"]))
    echo "Sí está el nombre disponible";
  else
    echo "No hay nombre disponible";
  
    //echo $_SESSION["boleta"]."-".$_SESSION["correo"]."-".$_SESSION["telcel"];
?>