<?php
  session_start();
  $_SESSION["b1"] = "2022630001";
  $b1 = $_SESSION["b1"];
  echo $b1;
  echo "<a href='./dos.php'>Dos</a>";
?>