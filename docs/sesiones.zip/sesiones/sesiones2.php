<?php
  session_start();

$_SESSION["telcel"] = "5512345678";
$_SESSION["nombre"] = "Juan Pérez";
echo $_SESSION["boleta"];

?>