<?php
  session_start();
  if(isset($_SESSION["boleta"])){
    echo "Bienvenidos";
  }else{
    header("location:https://uteycv.escom.ipn.mx");
  }
  
  
?>