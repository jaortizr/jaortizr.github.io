<?php
  session_start();
  if(isset($_SESSION["boleta"])){
    $boleta = $_GET["boleta"];
    $conexion = mysqli_connect("localhost","root","","sem20221");
    mysqli_set_charset($conexion, "utf8");
    $sql = "SELECT * FROM alumno WHERE boleta = '$boleta'";
    $res = mysqli_query($conexion,$sql);
    $inf = mysqli_fetch_row($res);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>SEM20221 / Editar</title>
<meta name='viewport' content='width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no'/>
<meta name="description" content="">
<meta name="keywords" content="">
<link href="./../fontawesome/css/all.min.css" rel="stylesheet">
<link href="./../materialize/css/materialize.min.css" rel="stylesheet">
<link href="./../js/validetta/validetta.min.css" rel="stylesheet">
<link href="./../css/general.css" rel="stylesheet">
<script src="./../js/jquery-3.6.0.min.js"></script>
<script src="./../materialize/js/materialize.min.js"></script>
<script src="./../js/validetta/validetta.min.js"></script>
<script src="./../js/validetta/validettaLang-es-ES.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="./../js/editar.js"></script>
</head>
<body>
  <header>
    <img src="./../imgs/header.png" class="responsive-img">
  </header>
  <main class="valign-wrapper">
    <div class="container">
      <div class="row">
        <h4>Editar:</h4>
        <form id="formEdit" autocomplete="off">
        <div class="col s12 m6 l4 input-field">
          <i class="fas fa-user prefix"></i>
          <label for="boleta">Boleta</label>
          <input type="text" id="boleta" name="boleta" maxlength="10" data-validetta="required,number,minLength[10],maxLength[10]" value="<?php echo $inf[0]; ?>" readonly>
        </div>
        <div class="col s12 m6 l4 input-field">
          <i class="fas fa-cog prefix"></i>
          <label for="nombre">Nombre</label>
          <input type="text" id="nombre" name="nombre" data-validetta="required" value="<?php echo $inf[1]; ?>">
        </div>
        <div class="col s12 m6 l4 input-field">
          <i class="fas fa-cog prefix"></i>
          <label for="primerApe">Primer Apellido</label>
          <input type="text" id="primerApe" name="primerApe" data-validetta="required" value="<?php echo $inf[2]; ?>">
        </div>
        <div class="col s12 m6 l4 input-field">
          <i class="fas fa-cog prefix"></i>
          <label for="segundoApe">Segundo Apellido</label>
          <input type="text" id="segundoApe" name="segundoApe" data-validetta="" value="<?php echo $inf[3]; ?>">
        </div>
        <div class="col s12 m6 l4 input-field">
          <i class="fas fa-envelope prefix"></i>
          <label for="correo">Correo</label>
          <input type="text" id="correo" name="correo" data-validetta="required,email" value="<?php echo $inf[4]; ?>">
        </div>
        <div class="col s12 m6 l4 input-field">
          <i class="fas fa-phone prefix"></i>
          <label for="telcel">Tel-Cel</label>
          <input type="text" id="telcel" name="telcel" data-validetta="required" value="<?php echo $inf[5]; ?>">
        </div>
        <div class="col s12 m6 l4 input-field">
          <i class="fas fa-key prefix"></i>
          <label for="contrasena">Contraseña</label>
          <input type="password" id="contrasena" name="contrasena" maxlength="16">
        </div>
      </div>
      <div class="row">
        <div class="col s12">
          <input type="submit" class="btn blue" style="width:100%" value="Editar">
        </div>
      </div>
      </form>
    </div>
  </main>
  <footer class="page-footer blue">
    <div class="footer-copyright">
      <div class="container">
      © 2021 Copyright TDAW-20221
      <a class="grey-text text-lighten-4 right" href="https://www.escom.ipn.mx">ESCOM</a>
      </div>
    </div>
  </footer>
</body>
</html>
<?php
  }else{
    header("location:./../login.html");
  }
?>