<?php
  session_start();
  if(isset($_SESSION["boleta"])){
    include("./privado_BD.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>Privado / Sem 20221</title>
<meta name='viewport' content='width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no'/>
<meta name="description" content="">
<meta name="keywords" content="">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
<link rel="stylesheet" href="./../css/general.css">
<script src="./../js/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="./../js/privado.js"></script>
</head>
<body>
  <header>
    <img src="./../imgs/header.png" class="responsive-img">
    <div class="fixed-action-btn">
      <a class="btn-floating btn-large teal">
        <i class="large fas fa-bars"></i>
      </a>
      <ul>
        <li><a href="./cerrarSesion.php?nombreSesion=boleta" class="btn-floating tooltipped green" data-position="left" data-tooltip="Cerrar Sesión"><i class="fas fa-sign-out-alt"></i></a></li>
        <li><a href="./registro.php" class="btn-floating tooltipped grey" data-position="left" data-tooltip="Agregar Usuario"><i class="fas fa-user-plus"></i></a></li>
      </ul>
    </div>
  </header>
  <main>
    <div class="container">
      <h1>Bienvenido <?php echo "$infAdm[1] !";  ?></h1>
      <table class="striped centered responsive-table">
        <thead>
          <tr><th>Boleta</th><th>Nombre</th><th>correo</th><th>Opciones</th></tr>
        </thead>
        <tbody>
          <?php echo $trsGetAlumnos; ?>
        </tbody>
      </table>
    </div>
  </main>
  <footer class="page-footer blue">
    <div class="footer-copyright">
      <div class="container">
      © 2021 Copyright TDAW-20221
      <a class="grey-text text-lighten-4 right" href="https://www.escom.ipn.mx">ESCOM</a>
      </div>
    </div>
  </footer>
</body>
</html>
<?php
  }else{
    header("location: ./../login.html");
  }
?>