$(document).ready(()=>{
  $("form#formUpload").submit((e)=>{
    e.preventDefault();
    var formData = new FormData($("form")[0]);
    $.ajax({
      method:"post",
      url:"./upload.php",
      data:formData,
      cache: false,
      contentType: false,
      processData:false,
      success:function(respAX){
        let AX = JSON.parse(respAX);
        $("div#respAX").html(AX.info + AX.msj);
      }
    });
  });
});