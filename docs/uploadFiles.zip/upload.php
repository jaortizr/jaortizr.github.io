<?php
  $usuario = $_POST["usuario"];
  $contrasena = $_POST["contrasena"];
  $respAX = [];

  if(isset($_FILES["archivo"])){
    $respAX["info"] = "Tamaño(KB): ".$_FILES["archivo"]["size"]."<br>Nombre: ".$_FILES["archivo"]["name"]."<br>Tipo: ".$_FILES["archivo"]["type"]."<br>Nombre temporal: ".$_FILES["archivo"]["tmp_name"]."<br>";
    if($_FILES["archivo"]["size"] > 0){
      $dirDestino = "./uploads/";
      $archDestino = "$dirDestino"."$usuario".".pdf";
      if($_FILES["archivo"]["size"] > 1048576) { //1M
        $respAX["cod"] = 2;
        $respAX["msj"] = "<h5 class='center-align'>Error en el archivo. No se permiten archivos de m&aacute;s de 1M. Favor de intentarlo nuevamente.</h5>";
      }else{
        if(move_uploaded_file($_FILES["archivo"]["tmp_name"], $archDestino)){
          $respAX["cod"] = 1;
          $respAX["msj"] = "<h5 class='center-align'>El archivo se guardo correctamente en el servidor.</h5>";
        }else{
          $respAX["cod"] = 0;
          $respAX["msj"] = "<h5 class='center-align'>Error en el archivo. No se pudo copiar al servidor. Favor de intentarlo nuevamente.</h5>";
        }
      }
    }
  }

  echo json_encode($respAX);
?>