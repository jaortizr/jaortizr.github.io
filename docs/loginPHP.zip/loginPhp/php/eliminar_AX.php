<?php
  include("./configBD.php");

  $boleta = $_REQUEST["boleta"];
  $respAX = [];

  $sqlDelAlumno = "DELETE FROM alumno WHERE boleta = '$boleta'";
  $resDelAlumno = mysqli_query($conexion, $sqlDelAlumno);
  if(mysqli_affected_rows($conexion) == 1){
    $respAX["cod"] = 1;
    $respAX["msj"] = "Se elimino el alumno con boleta $boleta correctamente.";
    $respAX["icono"] = "success";
  }else{
    $respAX["cod"] = 0;
    $respAX["msj"] = "Error. Favor de intentarlo nuevamente";
    $respAX["icono"] = "error";
  }

  echo json_encode($respAX);
?>