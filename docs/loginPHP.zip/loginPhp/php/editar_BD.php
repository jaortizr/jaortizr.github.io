<?php
  include("./configBD.php");

  $boleta = $_REQUEST["boleta"];

  $sqlGetAlumno = "SELECT * FROM alumno WHERE boleta = '$boleta'";
  $resGetAlumno = mysqli_query($conexion, $sqlGetAlumno);
  $infGetAlumno = mysqli_fetch_assoc($resGetAlumno);

  echo json_encode($infGetAlumno);
?>