<?php
  include("./configBD.php");

  $sqlGetAlumnos = "SELECT * FROM alumno";
  $resGetAlumnos = mysqli_query($conexion, $sqlGetAlumnos);
  $trsAlumnos = "";
  while($filas = mysqli_fetch_row($resGetAlumnos)){
    $trsAlumnos .= "
      <tr><td>$filas[0]</td><td>$filas[1] $filas[2] $filas[3]</td><td><i class='fa-solid fa-pen-to-square editar' data-boleta='$filas[0]'></i>&nbsp;&nbsp;<i class='fa-solid fa-trash eliminar' data-boleta='$filas[0]'></i></td></tr>
    ";
  }
?>