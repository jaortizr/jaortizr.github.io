<?php
  include("./configBD.php");

  $boleta = $_REQUEST["boleta"];
  $nombre = $_REQUEST["nombre"];
  $primerApe = $_REQUEST["primerApe"];
  $segundoAPe = $_REQUEST["segundoApe"];

  $respAX = [];
  $sqlUpdAlumno = "UPDATE alumno SET nombre = '$nombre', primerApe = '$primerApe', segundoApe = '$segundoAPe', auditoria = NOW() WHERE boleta = '$boleta'";
  $resUpdAlumno = mysqli_query($conexion, $sqlUpdAlumno);
  if(mysqli_affected_rows($conexion) == 1){
    $respAX["cod"] = 1;
    $respAX["msj"] = "Los datos del alumno se actualizaron correctamente.";
    $respAX["icono"] = "success";
  }else{
    $respAX["cod"] = 0;
    $respAX["msj"] = "Error. Favor de intentarlo nuevamente.";
    $respAX["icono"] = "error";
  }

  echo json_encode($respAX);
?>