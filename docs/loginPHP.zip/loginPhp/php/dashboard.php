<?php
  include("./dashboard_BD.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <link href="./../libs/materialize/css/materialize.min.css" rel="stylesheet">
  <link href="./../css/flex.css" rel="stylesheet">
  <script src="./../libs/jquery-3.7.1.min.js"></script>
  <script src="./../libs/materialize/js/materialize.min.js"></script>
  <script src="./../libs/sweetAlert_min.js"></script>
  <script src="./../js/dashboard.js"></script>
  <style>
    .editar, .eliminar{
      cursor:pointer;
    }
  </style>
</head>
<body>
  <header>
    <img src="./../imgs/header.jpg" class="responsive-img">
  </header>
  <main class="valign-wrapper">
    <div class="container">
      <div class="row">
        <h3>Lista alumnos:</h3>
      </div>
      <div class="row">
        <table class="centered striped responsive-table">
          <thead>
            <tr><th>Boleta</th><th>Nombre</th><th>Opciones</th></tr>
          </thead>
          <tbody id="trsAlumnos">
            <?php echo $trsAlumnos; ?>
          </tbody>
        </table>
      </div>
    </div>
  </main>
  <footer class="page-footer blue">
    <div class="footer-copyright">
      <div class="container">
      © 2023 Copyright DAW-4CV3
      <a class="grey-text text-lighten-4 right" href="https://escom.ipn.mx">escom.ipn.mx</a>
      </div>
    </div>
  </footer>
</body>
</html>