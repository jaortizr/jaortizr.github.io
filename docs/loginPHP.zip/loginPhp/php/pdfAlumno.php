<?php
  session_start();
  include("./configBD.php");
  include("./../libs/mpdfV8/vendor/autoload.php");

  $boleta = $_SESSION["boleta"];
  $sqlGetAlumno = "SELECT * FROM alumno WHERE boleta = '$boleta'";
  $resGetAlumno = mysqli_query($conexion, $sqlGetAlumno);
  $infGetAlumno = mysqli_fetch_row($resGetAlumno);

  $estilos = "
    <style>
      img.responsive{width:100%; max-width:100%;}
      table{width:100%;}
      p,h1,h2,h3{text-align:center;}
    </style>
  ";

  $header = "
    <table>
      <tr><td><img src='./../imgs/header.jpg' class='responsive'></td></tr>
    </table>
  ";

  $html = $estilos;
  $html .= "
    <h1>$infGetAlumno[1] $infGetAlumno[2] $infGetAlumno[3]</h1>
    <h2>$infGetAlumno[0]</h2>
    <h3>$infGetAlumno[4] / $infGetAlumno[5]</h3>
    <img src='./../imgs/user.jpg' class='responsive'>
  ";

  $pie = "
    <p>
      JAOR - TDAW / Semestre 2024-1<br>
      <a href='https://www.escom.ipn.mx'>ESCOM</a>
    </p>
  ";

  $mpdf = new \Mpdf\Mpdf(["mode"=>"c", "oreintation"=>"P", "format"=>"Letter", "default_font_size"=>12, "default_font"=>"dejavusans", "margin_left"=>15, "margin_right"=>10, "margin_top"=>30, "margin_bottom"=>10, "margin_header"=>5, "margin_footer"=>5]);

  $mpdf->SetWatermarkText("JAOR-TDAW-20241", 0.1);
  $mpdf->showWatermarkText = true;

  $mpdf->SetHTMLHeader($header);
  $mpdf->WriteHTML($html);
  $mpdf->SetHTMLFooter($pie);
  
  $mpdf->output();
?>