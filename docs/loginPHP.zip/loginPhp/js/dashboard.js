$(document).ready(()=>{
  $(".editar").on("click", function(){
    let boleta = $(this).attr("data-boleta");
    sessionStorage.setItem("boleta", boleta);
    window.location.href = "./../html/editar.html";
  });

  $(".eliminar").on("click", function(){
    let boleta = $(this).attr("data-boleta");
    Swal.fire({
      title: "TDAW / 2024-1",
      text:"¿Eliminar alumno con boleta "+ boleta + "?",
      showDenyButton: true,
      denyButtonText: "No",
      confirmButtonText: "Sí",
    }).then((res) => {
      if(res.isConfirmed){
        $.ajax({
          url:"./eliminar_AX.php",
          method:"post",
          data:{boleta:boleta},
          cache:false,
          success:(respAX)=>{
            let objRespAX = JSON.parse(respAX);
            Swal.fire({
              title:"TDAW / 2024-1",
              text:objRespAX.msj,
              icon:objRespAX.icono,
              didDestroy:()=>{
                if(objRespAX.cod == 1){
                  window.location.reload();
                }
              }
            });
          }
        });
      }else if(res.isDenied){
        console.log("Noooo");
      }
    });
  });
});