$(document).ready(()=>{
  let boleta = sessionStorage.getItem("boleta");
  $.ajax({
    url:"./../php/editar_BD.php",
    method:"post",
    data:{boleta:boleta},
    cache:false,
    success:(respAX)=>{
      console.log(respAX);
      let objRespAX = JSON.parse(respAX);
      $("#boleta").val(objRespAX.boleta);
      $("#nombre").val(objRespAX.nombre);
      $("#primerApe").val(objRespAX.primerApe);
      $("#segundoApe").val(objRespAX.segundoApe);
      M.updateTextFields();
    }
  });

  const validarEditar = new window.JustValidate("#formEditar");
  validarEditar
  .addField("#nombre",[
    {rule:"required", errorMessage:"Falta el nombre"}
  ])
  .addField("#primerApe",[
    {rule:"required", errorMessage:"Falta el primer apellido"}
  ])
  .addField("#segundoApe",[
    {rule:"required", errorMessage:"Falta el segundo apellido"}
  ])
  .onSuccess((evt)=>{
    evt.preventDefault();
    $.ajax({
      url:"./../php/editar_AX.php",
      method:"post",
      data:$("#formEditar").serialize(),
      cache:false,
      success:(respAX)=>{
        let objRespAX = JSON.parse(respAX);
        Swal.fire({
          title:"TDAW / 2024-1",
          text:objRespAX.msj,
          icon:objRespAX.icono,
          didDestroy:()=>{
            if(objRespAX.cod == 1){
              sessionStorage.removeItem("boleta");
              window.location.href = "./../php/dashboard.php";
            }
          }
        });
      }
    });
  });
});