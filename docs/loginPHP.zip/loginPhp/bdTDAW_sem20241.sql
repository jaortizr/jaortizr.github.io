/*
SQLyog Community v13.1.9 (64 bit)
MySQL - 10.4.28-MariaDB : Database - bdSem20241
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`bdSem20241` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci */;

USE `bdSem20241`;

/*Table structure for table `alumno` */

DROP TABLE IF EXISTS `alumno`;

CREATE TABLE `alumno` (
  `boleta` varchar(10) NOT NULL,
  `nombre` varchar(64) NOT NULL,
  `primerApe` varchar(64) NOT NULL,
  `segundoApe` varchar(64) DEFAULT NULL,
  `correo` varchar(128) NOT NULL,
  `telCel` varchar(10) DEFAULT NULL,
  `contrasena` varchar(32) NOT NULL,
  `auditoria` datetime NOT NULL,
  PRIMARY KEY (`boleta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

/*Data for the table `alumno` */

insert  into `alumno`(`boleta`,`nombre`,`primerApe`,`segundoApe`,`correo`,`telCel`,`contrasena`,`auditoria`) values 
('2023630001','Juan','Perez','Perez','uncorreo@correo.com','5512345678','fbff2b2ea096a99e55f6e115f220a1a3','2023-11-24 19:26:37'),
('2023630002','Blanca','Nieves','Nieves','uncorreo@correo.com','5587654321','4d33776f1612cadff8a584ea6596efde','2023-12-21 14:49:22'),
('2023630003','Maria','Mendez','Mendez','uncorreo@correo.com','5511223344','7b12c6bfe49a458dfc0583d9bdef3945','2023-12-05 12:43:50');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
