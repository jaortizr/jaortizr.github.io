<?php
    /*
        En el archivo anterior se destruyeron todas las sesiones, así que cualquier intento de acceso desde este archivo generará un error de variables no definidas.
    */
    session_start();
    $nombre = $_SESSION["nombre"];
    $boleta = $_SESSION["boleta"];
    $escuela = $_SESSION["escuela"];
    echo "<p>Hola <span style='color:#F00;'>$nombre</span> tu boleta es <span style='color:#F00;'>$boleta</span> y estudias en <span style='color:#F00;'>$escuela</span></p>";
    echo "<a href='sesion_1.php'>Volver a empezar</a>";
?>