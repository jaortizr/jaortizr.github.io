<?php
    /*
        Aquí la gran característica de las sesiones, en cuanto se declara e inicializa una variable de sesión, ésta se mantendrá disponible para todas las otras páginas que pertenecen a nuestro proyecto hasta que se cierre la ventana del navegador o se eliminen, vía programación o pasado cierto tiempo, las sesiones.
    */
    session_start();
    $nombre = $_SESSION["nombre"];
    echo "<p>Hola <span style='color:#00FF00;'>$nombre</span></p>";
    $_SESSION["escuela"] = "ESCOM";
    echo "<a href='sesion_3.php'>Sesiones 3</a>";
?>