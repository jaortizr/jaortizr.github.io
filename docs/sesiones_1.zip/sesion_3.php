<?php
    /*
        Otro archivo que pretende acceder a sesiones definidas fuera de este archivo y no hay ningun problema.
        El detalle es que al final del código destruimos todas las sesiones por lo que dejan de estar disponibles para un archivo siguiente
    */
    session_start();
    $nombre = $_SESSION["nombre"];
    $boleta = $_SESSION["boleta"];
    $escuela = $_SESSION["escuela"];
    echo "<p>Hola <span style='color:#F00;'>$nombre</span> tu boleta es <span style='color:#F00;'>$boleta</span> y estudias en <span style='color:#F00;'>$escuela</span></p>";
    session_destroy();
    echo "<a href='sesion_4.php'>Sesiones 4</a>";
?>