<?php
    /*
        Sesiones PHP
        PHP ofrece una variable 'especial': SESIONES.
        Como lo dije no es más que una variable, como con las que hemos trabajado previamente, solo que a diferencia de éstas, las sesiones se definen en un arreglo asociativo global, como $_POST[], nosotros definimos el índice de dicho arreglo directamente y a partir de aquí se comporta como una variable más, se accede directamente a su valor, se pueden asignar a otra variable, se pueden hacer operaciones entre ellas, etc.

        IMPORTANTE!!!
        A PARTIR DE AQUÍ PARA QUE ESTO FUNCIONE NECESITAMOS COLOCAR COMO PRIMER LÍNEA DE NUESTRO CÓDIGO FUNCIONAL LA INSTRUCCIÓN: session_start() OMITIRLA O NO HACERLO EN LA PRIMERA LÍNEA GENERARÁ ERRORES.
    */

    session_start();
    $_SESSION["nombre"] = "JAOR";
    $_SESSION["boleta"] = "12345678";

    echo $_SESSION["nombre"];
    $boleta = $_SESSION["boleta"];
    echo "<p>Boleta: <span style='color:#FF0000;'>$boleta</span></p>";

    echo "<a href='sesion_2.php'>Sesiones 2</a>";
?>