<?php
    /*
        Una de las características de PHP es su soporte total a la POO, así pues mucho de lo que ya saben aplicará sin muchos problemas. Les comparto un pequeño ejemplo.

        Una explicación más extensa y especifíca sobre POO en PHP la pueden encontrar en:
        https://diego.com.es/programacion-orientada-a-objetos-en-php
    */

    class Empleado{
        public $nombre;
        public $clave;
        public function darsaludo() {
            echo "¡Buenos dias $this->nombre ! <br>";
        }
    }

    $antonio = new Empleado;
    $antonio->nombre = "Jose Antonio";
    $antonio->darsaludo(); // ¡Buenos dias Jose Antonio!
    
    $empleados = []; //Declaración de un arreglo vacio
    //PHP de manera automática va incrementanto el índice
    $empleados[] = new Empleado;
    $empleados[] = new Empleado;
    $empleados[0]->nombre = "Blanca E";
    $empleados[1]->nombre = "Miguel Angel";
    foreach ($empleados as $empleado) {
        $empleado->darsaludo();
    }
?>