<?php
    /*
        Lo más comun será que agreguemos código PHP a nuestras páginas HTML, así pues PHP se puede incluir como si de otra etiqueta se tratará y además podemos hacerlo también tantas veces se necesite. Las etiquetas son: '<?php' etiqueta de apertura y '?>' comoetiqueta de cierre.
        
        Y complementando el ejemplo anterior, pueden hacer sus propias clases o utilizar las muchas disponibles en la internet. Aqui un ejemplo haciendo uso de la clase 'PHPChart' https://phpchart.com
        Igual que con los plugins de jQuery es cuestión de buscarlos, integrarlos y consultar su documentación.
    */

    include("./phpChart_Lite/conf.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>PHP Chart</title>
<meta name='viewport' content='width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no'/>
<meta name="description" content="">
<meta name="keywords" content="">
<link href="" rel="stylesheet">
</head>
<body>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras sit amet elementum turpis. Praesent vel est vestibulum, auctor arcu sit amet, porta nisl. Praesent eleifend velit felis, at suscipit magna cursus vel. Integer id nisi ut metus ultricies iaculis a ac arcu. Cras ac scelerisque nulla. Suspendisse elementum tincidunt elit vel eleifend. Duis sit amet turpis ac augue pulvinar accumsan ac sit amet sem. Nullam justo metus, viverra sed gravida at, euismod eu leo. Nulla ultrices erat quis justo ultricies, id varius ex pharetra.</p>
<h3>Gr&aacute;fica generada con PHPChart</h3>
<?php
    $pc = new C_PhpChartX(array(array(11, 9, 5, 12, 14, 23, 2, 8, 8)),'Ejemplo');
    $pc->draw();
?>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras sit amet elementum turpis. Praesent vel est vestibulum, auctor arcu sit amet, porta nisl. Praesent eleifend velit felis, at suscipit magna cursus vel. Integer id nisi ut metus ultricies iaculis a ac arcu. Cras ac scelerisque nulla. Suspendisse elementum tincidunt elit vel eleifend. Duis sit amet turpis ac augue pulvinar accumsan ac sit amet sem. Nullam justo metus, viverra sed gravida at, euismod eu leo. Nulla ultrices erat quis justo ultricies, id varius ex pharetra.</p>
</body>
</html>