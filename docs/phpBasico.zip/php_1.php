<?php
    //Linea de comentarios
    /*
        PHP es un lenguaje de programación de servidor, es decir, requiere de un compilador situado en un equipo identificado como servidor al cual se puede acceder de manera remota (por internet, por ejemplo) para solicitar que se compile nueestro código y devuelva el resultado que procesaremos segun nuestras necesidades.
        En nuestro caso ese servidor será nuestro propio equipo de cómputo que habilitaremos como tal, sin necesidad de ir a otro equipo; acceder a este servidor regularmente se haría por medio de un dominio (www.escom.ipn.mx/mipagina.php) y el directorio donde se encuentre dicho archivo, por el momento y suponiendo que ya se ha instalado algun _AMP nuestro dominio será localhost, así entonces acceder a la funcionalidad de nuestro PHP sería: http://localhost/mipagina.php. http://localhost es un alias/apuntador a su 'directorio de publicación' todo lo que se coloque en éste será visible para todos aquellos que tengan acceso a este.

        No hay muho que hablar sobre PHP en el sentido de su sintaxis y potencial, es un lenguaje formal (compilado), orientado a objetos, no tipeado, multiplataforma, extensible con un gran número de bibliotecas y/o APIs. Usado para desarrollar algunos bloques de Facebook y Twitter.

        Lo que saben de programación es altamente probable que se aplique sin muchos problemas en PHP: variables, constantes, arreglos, objetos, operadores lógicos, matemáticos, funciones, etc.
        Como con las otras tecnologías también PHP ya tiene muchas cosas hechas de manera nativa o a través de bibliotecas de terceros o repositorios (https://pear.php.net/), lo que significa que deben husmear para saber que tanto pueden hacer.
    */

    //Declarar una variable PHP
    $miVariable = "Hola mundo";
    $otraVariable = 314;
    $variable = 3.14;

    //Salida estandard a pantalla
    echo $miVariable;

    //El resultado de la compilación de su código PHP siempre será regresado al navegador y el navagador solo entiende los estandares de HTML, CSS y JS, entonces algo como lo siguiente es válido y aplica para todo lo que hemos revisado de front-end.
    echo "<br>";

    //PHP siempre revisará si se ha declarado una variable, cuando encuentre el caracter '$' en caso de ser cierto mostrará el valor que se le asignó, de lo contrario marcará un error de variable no definida.
    echo "<h1 style='color:#F00;'>Faltan $otraVariable d&iacute;as para que inicie el evento...</h1>";

    //Funciones y estructuras de control
    //Se declara la función
    function compara($a,$b){
        if($a > $b){
            echo "$a es mayor que $b";
        }else if($b > $a){
            echo "$b es mayor que $a";
        }else if($a == $b){
            echo "$a es igual que $b";
        }
    };

    //Se manda a llamar la función
    $be = 82;
    $ja = 79;
    compara($be, $ja);
    echo "<br>";
    compara($ja+3, $be);
    echo "<br>";

    //Arreglos tal y como los conocemos más un concepto de mucha utilidad denominado 'arreglo asociativo' cuya característica es que su indice es un cadena de texto
    $arregloNormal = ["h","o","l","a"];
    echo $arregloNormal[3]; //en pantalla 'a'
    echo "<br>";

    $arregloAsociativo = ["primero"=>"e","segundo"=>"s","tercero"=>"c"];
    echo $arregloAsociativo["segundo"]; //en pantalla 's'
    echo "<br>";
    
?>