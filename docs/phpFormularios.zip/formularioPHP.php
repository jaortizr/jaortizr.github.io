<?php
    /*
        PHP hace muy sencilla la obtención de los datos desde el front-end. PHP entre sus características es la disponibilidad de un conjunto de arreglos denominados 'arreglos globales' en esta primera oportunidad nos enfocaremos en el arreglo $_POST[] que contiene todos los datos que llegan a esta página por medio del método POST definido en el atributo METHOD de la etiqueta FORM de su HTML, no olviden que llegamos aquí porque lo indicaron en el atributo ACTION de la misma etiqueta. Funciona de la siguiente manera, este arreglo contiene todos los datos que llegan a la página por POST, estos corresponden a cada componente de su formulario, para acceder a éstos se accede al índice adecuado de dicho arreglo, el detalle es que los índices son cadenas que corresponden al valor del atributo NAME de cada componente del formulario (sí, es un arreglo asocialtivo); se puede utilizar directamente o vaciarlo en una variable PHP, una variable PHP por cada componente del formulario.
        
        A partir de aquí se tienen los datos/información que el usuario proporcionó por medio del formulario y podemos procesarlos segun nuestras necesidades (por ejemplo almacenarlos en una BD MySQL), cabe aclarar que no es la única manera de lograr esa transferecnia de datos.

        Estamos en el supuesto que la información que llegó hasta este punto ha pasado por las validaciones adecuadas.      
    */
    $boleta = $_POST["boleta"];
    $contrasena = $_POST["contrasena"];
    echo "$boleta y $contrasena";
?>