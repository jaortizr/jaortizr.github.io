/*
SQLyog Community v13.1.5  (64 bit)
MySQL - 10.4.24-MariaDB : Database - uaoptativas222
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`uaoptativas222` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `uaoptativas222`;

/*Table structure for table `alumno` */

DROP TABLE IF EXISTS `alumno`;

CREATE TABLE `alumno` (
  `nombre` varchar(64) NOT NULL,
  `primerApe` varchar(64) NOT NULL,
  `segundoApe` varchar(64) DEFAULT NULL,
  `correo` varchar(256) NOT NULL,
  `carrera` varchar(4) NOT NULL,
  `contrasena` varchar(32) NOT NULL,
  `auditoria` datetime DEFAULT NULL,
  PRIMARY KEY (`correo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `alumno` */

insert  into `alumno`(`nombre`,`primerApe`,`segundoApe`,`correo`,`carrera`,`contrasena`,`auditoria`) values 
('Ana','Anaya','Anaya','ana@ana.com','IIA','9aba45a7f1999a9c5fc96ef2a45810fb','2022-05-26 14:12:26'),
('Blanca','Nieves','Nieves','blanca@blanca.com','ISC','b9b7d2dfdbbe18850557a97bc0c613bf','2022-05-26 13:57:43'),
('Diana','Diaz','Diaz','diana@diana.com','LCD','93b63feb993716772ef3b15b08b8e8a8','2022-05-26 14:30:29'),
('Juan','Pérez','Pérez','juan@juan.com','ISC','92eaf3719159c372f3d50337e0a14f57','2022-05-24 14:45:31'),
('Luis','Lopez','Lopez','luis@luis.com','IIA','c44688b5061756b3cca2b86c016a1535','2022-05-26 14:45:25');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
