/*
SQLyog Community v13.1.5  (64 bit)
MySQL - 10.4.24-MariaDB : Database - uaoptativas222
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`uaoptativas222` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `uaoptativas222`;

/*Table structure for table `alumno` */

DROP TABLE IF EXISTS `alumno`;

CREATE TABLE `alumno` (
  `nombre` varchar(64) NOT NULL,
  `primerApe` varchar(64) NOT NULL,
  `segundoApe` varchar(64) DEFAULT NULL,
  `correo` varchar(256) NOT NULL,
  `carrera` varchar(4) NOT NULL,
  `contrasena` varchar(32) NOT NULL,
  `auditoria` datetime DEFAULT NULL,
  PRIMARY KEY (`correo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `alumno` */

insert  into `alumno`(`nombre`,`primerApe`,`segundoApe`,`correo`,`carrera`,`contrasena`,`auditoria`) values 
('Ana','Anaya','Anaya','ana@ana.com','IIA','d8578edf8458ce06fbc5bb76a58c5ca4','2022-05-26 14:12:26'),
('Blanca','Nieves','Nieves','blanca@blanca.com','ISC','d8578edf8458ce06fbc5bb76a58c5ca4','2022-05-26 13:57:43'),
('Diana','Diaz','Diaz','diana@diana.com','LCD','d8578edf8458ce06fbc5bb76a58c5ca4','2022-05-26 14:30:29'),
('Juan','Pérez','Pérez','juan@juan.com','ISC','d8578edf8458ce06fbc5bb76a58c5ca4','2022-05-24 14:45:31'),
('Luis','Lopez','Lopez','luis@luis.com','IIA','d8578edf8458ce06fbc5bb76a58c5ca4','2022-05-26 14:45:25');

/*Table structure for table `encuesta` */

DROP TABLE IF EXISTS `encuesta`;

CREATE TABLE `encuesta` (
  `correo` varchar(256) NOT NULL,
  `uao_1` varchar(16) NOT NULL,
  `uao_2` varchar(16) NOT NULL,
  `auditoria` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `encuesta` */

insert  into `encuesta`(`correo`,`uao_1`,`uao_2`,`auditoria`) values 
('juan@juan.com','uao_01','uao_02','2022-05-31 14:52:25'),
('blanca@blanca.com','uao_02','uao_04','2022-06-02 14:12:45');

/*Table structure for table `uaoptativa` */

DROP TABLE IF EXISTS `uaoptativa`;

CREATE TABLE `uaoptativa` (
  `id` varchar(16) NOT NULL,
  `nombre` varchar(256) NOT NULL,
  `carrera` varchar(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `uaoptativa` */

insert  into `uaoptativa`(`id`,`nombre`,`carrera`) values 
('uao_01','UA Optativa 1 ISC','ISC'),
('uao_02','UA Optativa 2 ISC','ISC'),
('uao_03','UA Optativa 3 ISC','ISC'),
('uao_04','UA Optativa 4 ISC','ISC'),
('uao_05','UA Optativa 1 IIA','IIA'),
('uao_06','UA Optativa 2 IIA','IIA'),
('uao_07','UA Optativa 3 IIA','IIA'),
('uao_08','UA Optativa 4 IIA','IIA'),
('uao_09','UA Optativa 1 LCD','LCD'),
('uao_10','UA Optativa 2 LCD','LCD'),
('uao_11','UA Optativa 3 LCD','LCD'),
('uao_12','UA Optativa 4 LCD','LCD');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
