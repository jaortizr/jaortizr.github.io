<?php
  session_start();
  include("./configBD.php");

  $correo = $_POST["correo"];
  $contrasena = md5($_POST["contrasena"]);

  $respAX = [];

  $sqlCheckAlmn = "SELECT * FROM alumno WHERE correo = '$correo' AND contrasena = '$contrasena'";
  $resCheckAlmn = mysqli_query($conexion, $sqlCheckAlmn);
  if(mysqli_num_rows($resCheckAlmn) == 1){
    $infAlmn = mysqli_fetch_row($resCheckAlmn);
    $respAX["cod"] = 1;
    $respAX["msj"] = "<h5>Bienvenido $infAlmn[0]</h5>";
    $_SESSION["correo"] = $correo;
  }else{
    $respAX["cod"] = 0;
    $respAX["msj"] = "<h5>Error. Favor de verificar los datos proporcionados</h5>";
  }

  echo json_encode($respAX);
  
?>