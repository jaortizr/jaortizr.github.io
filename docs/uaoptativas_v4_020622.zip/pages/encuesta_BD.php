<?php
include("./configBD.php");

$correo = $_SESSION["correo"];
$sqlGetCarrera = "SELECT carrera FROM alumno WHERE correo = '$correo'";
$resGetCarrera = mysqli_query($conexion, $sqlGetCarrera);
$infCarrera = mysqli_fetch_row($resGetCarrera);
$sqlGetUAO = "SELECT * FROM uaoptativa WHERE carrera = '$infCarrera[0]'";
$resGetUAO = mysqli_query($conexion, $sqlGetUAO);
$optUAO = "";
while($filas = mysqli_fetch_row($resGetUAO)){
  $optUAO .= "<option value='$filas[0]'>$filas[1]</option>";
}

$sqlCheckEncuesta = "SELECT * FROM encuesta WHERE correo = '$correo'";
$resCheckEncuesta = mysqli_query($conexion, $sqlCheckEncuesta);
$encuesta = 0;
if(mysqli_num_rows($resCheckEncuesta) == 1){
  $encuesta = 1;

  $sqlGetNombre = "SELECT * FROM alumno WHERE correo = '$correo'";
  $resGetNombre = mysqli_query($conexion, $sqlGetNombre);
  $infGetNombre = mysqli_fetch_row($resGetNombre);

  $sqlGetUAO1 = "SELECT uao.nombre FROM encuesta AS enc, uaoptativa AS uao
  WHERE enc.uao_1 = uao.id AND enc.correo = '$correo'";
  $resGetUAO1 = mysqli_query($conexion, $sqlGetUAO1);
  $infGetUAO1 = mysqli_fetch_row($resGetUAO1);

  $sqlGetUAO2 = "SELECT uao.nombre FROM encuesta AS enc, uaoptativa AS uao
  WHERE enc.uao_2 = uao.id AND enc.correo = '$correo'";
  $resGetUAO2 = mysqli_query($conexion, $sqlGetUAO2);
  $infGetUAO2 = mysqli_fetch_row($resGetUAO2);
}
?>