<?php
session_start();
$correo = $_SESSION["correo"];
include("./configBD.php");
include("./../classphp/fpdf183/fpdf.php");

$sqlGetNombre = "SELECT * FROM alumno WHERE correo = '$correo'";
  $resGetNombre = mysqli_query($conexion, $sqlGetNombre);
  $infGetNombre = mysqli_fetch_row($resGetNombre);

  $sqlGetUAO1 = "SELECT uao.nombre FROM encuesta AS enc, uaoptativa AS uao
  WHERE enc.uao_1 = uao.id AND enc.correo = '$correo'";
  $resGetUAO1 = mysqli_query($conexion, $sqlGetUAO1);
  $infGetUAO1 = mysqli_fetch_row($resGetUAO1);

  $sqlGetUAO2 = "SELECT uao.nombre FROM encuesta AS enc, uaoptativa AS uao
  WHERE enc.uao_2 = uao.id AND enc.correo = '$correo'";
  $resGetUAO2 = mysqli_query($conexion, $sqlGetUAO2);
  $infGetUAO2 = mysqli_fetch_row($resGetUAO2);


$pdf=new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(80,10, "Nombre: $infGetNombre[0] $infGetNombre[1] $infGetNombre[2]");
$pdf->Cell(80,20, "UAO1: $infGetUAO1[0]");
$pdf->Cell(80,20, "UAO2: $infGetUAO2[0]");
$pdf->Output();
?>