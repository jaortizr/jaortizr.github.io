<?php
require("./../classphp/fpdf183/fpdf.php");

$pdf=new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(80,10,'¡___Mi primera página pdf con FPDF!');
$pdf->AddPage();
$pdf->SetFont('Arial','B',30);
$pdf->Cell(80,10,'ESCOM-IPN');
$pdf->Output();
?>