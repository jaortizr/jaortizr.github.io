<?php
  session_start();
  if(!isset($_SESSION["correo"])){
    header("location:./../login.html");
  }else{
    include("./encuesta_BD.php");
?>
<!DOCTYPE HTML>
<html lang="es">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href=  "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="./../js/materialize/css/materialize.min.css" rel="stylesheet">
    <link href="./../js/validetta/dist/validetta.min.css" rel="stylesheet"> 
    <link href="./../css/general.css" rel="stylesheet">
    <script src="./../js/jquery-3.6.0.min.js"></script>
    <script src="./../js/materialize/js/materialize.min.js"></script>
    <script src="./../js/validetta/dist/validetta.min.js"></script> 
    <script src="./../js/validetta/localization/validettaLang-es-ES.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="./../js/encuesta.js"></script>
    <script>
      
    </script>
  </head>
  <body>
    <header>
      <img src="./../imgs/header.jpg" class="responsive-img">
      <!-- Menu -->
      <div class="fixed-action-btn">
        <a class="btn-floating btn-large red" href="./cerrarSesion.php?sesion=correo">
          <i class="large fas fa-bars"></i>
        </a>
        <ul>
        </ul>
      </div>
    </header>
    <main class="valign-wrapper">
      <div class="container">
        <h3>Encuesta</h3>
        <?php
          if($encuesta == 0){
        ?>
        <form id="formUAO">
          <div class="row">
            <div class="col s12 m6 input-field">
              <select id="uao_1" name="uao_1" data-validetta="required">
                <option value="">--- Seleccionar ---</option>
                <?php
                  echo $optUAO;
                ?>
              </select>
              <label for="uao_1">UA Optativa 1</label> 
            </div>
            <div class="col s12 m6 input-field">
              <select id="uao_2" name="uao_2" data-validetta="required">
              <option value="">--- Seleccionar ---</option>
              <?php
                echo $optUAO;
              ?>
              </select>
              <label for="uao_2">UA Optativa 2</label> 
            </div>
          </div>
          <div class="row">
            <button type="submit" class="btn blue" style="width:100%">Guardar</button>
          </div>
        </form>
        <?php
          }else{          
        ?>
        <h5>Hola <?php echo "$infGetNombre[0] $infGetNombre[1] $infGetNombre[2]" ?> ya has contestado la encuesta. Gracias.</h5>
        <h5>Tu selección fué:</h5>
        <ul>
          <li><?php echo "$infGetUAO1[0]" ?></li>
          <li><?php echo "$infGetUAO2[0]" ?></li>
        </ul>
        <a href="./encuesta_FPDF.php">PDF</a>
        <?php
          }
        ?>
      </div>
    </main>
    <footer class="page-footer blue">
      <div class="footer-copyright">
        <div class="container">
        © 2022 Copyright TWeb        <a class="grey-text text-lighten-4 right" href="https://www.escom.ipn.mx">ESCOM</a>
        </div>
      </div>
    </footer>
  </body>
</html>
<?php
}
?>