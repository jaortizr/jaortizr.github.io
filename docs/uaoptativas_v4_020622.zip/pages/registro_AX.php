<?php
  include("./configBD.php");

  $nombre = $_POST["nombre"];
  $primerApe = $_POST["primerApe"];
  $segundoApe = $_POST["segundoApe"];
  $correo = $_POST["correo"];
  $carrera = $_POST["carrera"];
  $contrasena = md5($_POST["nombre"]);

  $respAX = [];

  $sqlCheckCorreo = "SELECT * FROM alumno WHERE correo = '$correo'";
  $resCheckCorreo = mysqli_query($conexion, $sqlCheckCorreo);
  if(mysqli_num_rows($resCheckCorreo) == 1){
    $respAX["cod"] = 2;
    $respAX["msj"] = "<h5>Error. Correo ya registrado</h5>";
  }else{
    $sqlInsAlumno = "INSERT INTO alumno VALUE('$nombre','$primerApe','$segundoApe','$correo','$carrera','$contrasena',NOW())";
    $resInsAlumno = mysqli_query($conexion, $sqlInsAlumno);
    if(mysqli_affected_rows($conexion) == 1){
      $respAX["cod"] = 1;
      $respAX["msj"] = "Gracias. Registro realizado correctamente";
    }else{
      $respAX["cod"] = 0;
      $respAX["msj"] = "Error. No se pudo guardar el registro. Favor de intentarlo nuevamente";
    }
  }

  echo json_encode($respAX);
?>