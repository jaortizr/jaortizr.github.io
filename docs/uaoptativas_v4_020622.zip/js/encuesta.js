$(document).ready(()=>{
  $('select').formSelect();
  $('.fixed-action-btn').floatingActionButton();

  $("form#formUAO").validetta({
    onValid:(e)=>{
      e.preventDefault();
      if($("select#uao_1").val() == $("select#uao_2").val()){
        let msj = "<h5>Error. No puedes seleccionar dos veces la misma UAO.</h5>"
        Swal.fire({
          title: 'TWeb - 20222',
          html: msj,
          icon: 'error',
          confirmButtonText: 'OK',
          didDestroy:()=>{
            
          }
        });
      }else{
        $.ajax({
          method:"post",
          url:"./encuesta_AX.php",
          data:$("form#formUAO").serialize(),
          cache:false,
          success:(respAX)=>{
            let AX = JSON.parse(respAX);
            let icono = "";
            if(AX.cod == 1){icono = "success";}else{icono = "error";}
            Swal.fire({
              title: 'TWeb - 20222',
              html: AX.msj,
              icon: icono,
              confirmButtonText: 'OK',
              didDestroy:()=>{
                if(AX.cod == 1) location.reload();
              }
            });
          }
        })
      }
    }
  });
});