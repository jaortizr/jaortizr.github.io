$(document).ready(()=>{
  $('select').formSelect();

  $("form#formRegistro").validetta({
    bubblePosition: "bottom",
    bubbleGapTop: 10,
    bubbleGapLeft: -5,
    onValid:(e)=>{
      e.preventDefault();
      $.ajax({
        method:"post",
        url:"./pages/registro_AX.php",
        data:$("form#formRegistro").serialize(),
        cahe:false,
        success:(respAX)=>{
          let AX = JSON.parse(respAX);
          if(AX.cod == 1){
            $("form")[0].reset();
            Swal.fire({
              title: 'TWeb - 20222',
              html: AX.msj,
              icon: 'success',
              confirmButtonText: 'OK',
              didDestroy:()=>{
                window.location.href = "http://www.w3schools.com";
              }
            });
          }else{
            //$("input#correo").val("");
            Swal.fire({
              title: 'TWeb - 20222',
              html: AX.msj,
              icon: 'error',
              confirmButtonText: 'OK',
              footer:"ESCOM-IPN"
            });
          }
        }
      });
    }
  });
});