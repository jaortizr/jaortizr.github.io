<?php
    $boleta = $_POST["boleta"];
    $contrasena = $_POST["contrasena"];
    $respAX = "El servidor contesta: $boleta & $contrasena";
    
    //En este contexto donde se pretende aplicar el concepto de AJAX, todo 'echo' se tomará como respuesta que se regresará de manera asíncrona al front-end, todo esto gestionado por su JS.
    echo $respAX;
?>