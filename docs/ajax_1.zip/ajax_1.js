$(document).ready(function(){
    /*
        Primero debemos detectar en que momento el usuario quiere hacer el envío del correo para interceptar esa petición y deshabilitar el comportamiento por default que tiene el componente SUBMIT de nuestro formulario. Para esto nos ayudaremos de jQuery usando el manejador de evento submit() que se activa cuando enviamos el formulario al servidor y en cuanto sucede esto cancelamos el comportamiento con preventDefault().

        A continuación nos tocará configurar manualmente todo aquello que la etiqueta FORM hacia por nosotros, usaremos jQuery, concretamente la función $.ajax({}) que tiene un extenso número de propiedades que se pueden configurar, yo les presentaré las mínimas necesarias.

        Es importante que les quede claro que AJAX NO es un lenguaje de programación, es una manera de hacer ciertas cosas y además AJAX NO es responsable de lo que se envía al servidor y mucho menos de lo que el servidor responde. AJAX es un simple mensajero, un intermediario.

        HTML <------> JS <------> PHP
    */

   $("#formAJAX1").submit(function(e){
        e.preventDefault();
        var boleta = $("#boleta").val();
        var contrasena = $("#contrasena").val();
        $.ajax({
            method:"POST", //similar al atributo 'method' de la etiqueta FORM
            url:"./ajax_1.php", //similar al atributo 'action' de la etiqueta FORM
            data:{boleta:boleta, contrasena:contrasena}, //que datos se enviarán al servidor, nos toca armar un objeto JS de manera manual. No confundirse, simplemente recuerden la sintaxis, a la izquierda el identificador y a la derecha el valor; los identificadores fungen como el nombe de cada componente de nuestro formulario
            //Una alternativa más práctica para enviar nuestra información al servidor sería utilizar la función serialize() de jQuery, algo como: 'data:$("#formAJAX1").serialize()'
            cache:false, //evitamos que la página del servidor se almacene en la cache del navegador
            success:function(respAX){ //cuando el servidor de la respuesta ¿qué haremos con ella?
                alert(respAX);
                //también podriamos poner la respuesta del servidor en cualquier lugar de nuestra página web, suponiendo que el servidor da su respuesta en formato HTML: $("#unDiv").html(respAX)
            }
        });
   })
});