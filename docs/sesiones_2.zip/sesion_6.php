<?php
    /*
        Esta página debe tener un acceso restringido solo a aquellos a los que se les haya validado su información previamente; así pues debemos buscar la manre de 'investigar' si al legar a esta página se ha generado una variable de sesión con cierto nombre y en función a ello desplegar la información reservada al usuario validado o hacer que el 'niño curioso' se identifique.

        Para ello haremos uso de la función PHP isset()
        https://www.w3schools.com/php/func_var_isset.asp
    */

    session_start();

    if(isset($_SESSION["boleta"])){
        //La sesion existe SSI pasó por el login y los datos fueron correctos
        $boleta = $_SESSION["boleta"];
        echo "<h3>P&aacute;gina personalizada para $boleta</h3>";
        //También podemos pasar datos a una página por el método GET, poniendo al final del archivo un signo '?' y armar parejas variable=valor, es decir, en este caso enviamos una variable que se llama 'nombreSesion' con el valor 'boleta' al archivo cerrarSesion.php
        echo "<a href='./cerrarSesion.php?nombreSesion=boleta'>Cerrar Sesi&oacute;n</a>";

    }else{
        //No está definida la sesion 'boleta' porque los datos del login fueron incorrectos, hay que mandarlos al login
        //SI SE INTENTARÁ ACCEDER DIRECTAMENTE A ESTA PÁGINA, NO SE ENCUENTRA LA SESION Y SE REDIRIGE AL LOGIN
        header("location:./sesion_5.php");
    }
?>