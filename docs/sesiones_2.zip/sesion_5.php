<?php
    /*
        Vamos a usar el concepto de sesiones para implementar un esquema de seguridad para restringir el acceso a ciertas áreas. Una sesion se generará SSI verificamos que las credenciales o información proporcionadas por un usuario son correctas.
    */

    //Suponemos que esta es nuestra pantalla de validación de datos del usuario
    echo "<h3>Suponemos que aquí hay un formulario de login</h3>";
    echo "<a href='./sesion_5b.php'>Entrar al sistema</a>";
?>