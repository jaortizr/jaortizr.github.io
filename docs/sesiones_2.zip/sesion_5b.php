<?php
    //Suponemos que los datos que llegaron desde el supuesto formulario anterior se checan contra una BD y los resultados simplemente son: datos correctos o datos incorrectos. En función a esto habra que redirigir a la página exclusiva del alumno o volverlo al formulario de login. El redireccionamiento, independientemente del caso se logra con php usando la función header() https://www.php.net/manual/es/function.header.php
    
    session_start();
    //Cambiar valor de 0 a 1 para poder ver las variantes de la funcionalidad
    $resultadoBD = 1;
    if($resultadoBD == 1){
        //Solo cuando los datos del login sean correctos genero una sesion esto será señal de que se ha validado al usuario y está asociado a dicha sesion
        $_SESSION["boleta"] = "2020630001";
        header("location:./sesion_6.php");
    }else{
        header("location: ./sesion_5.php");
    }
?>