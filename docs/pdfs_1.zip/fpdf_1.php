<?php
    /*
        El formato PDF en los últimos años se ha convertido en un estandar para plasmar y compartir información por lo que es necesario que conozcamos las diferentes opciones que se tienen para crear documentos en este formato desde nuestras aplicaciones PHP. Afortunadamente se tienen muchas opciones, desde aquellas que vienen integradas en el core de PHP hasta bibliotecas/clases de terceros que nos pueden simplificar o complicar esta tarea.
        Para introducirnos en este tema empezaremos con una clase PHP veterana que ha servido como base para otras tantas, se trata de FPDF http://www.fpdf.org

        Es gratuita muy sencillo, simplemente hacer uso de propiedades y métodos ya definidos, y su documentación es más que suficiente para empezar en este campo, además tiene la coloboración de un gran número de 'socios' que aportan extensiones al código base o nos comparten soluciones específicas para ciertos escenarios.
    */

    include("./fpdf182/fpdf.php");

    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Courier','B',16);
    $pdf->Cell(40,10,'Hola Mundo!!!');
    $pdf->Output();
?>