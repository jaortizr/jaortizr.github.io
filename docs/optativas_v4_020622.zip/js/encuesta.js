$(document).ready(function(){
  $('.fixed-action-btn').floatingActionButton();
  $('select').formSelect();

  $("form#formUAO").validetta({
    onValid:(e)=>{
      e.preventDefault();
      if($("select#uao_1").val() == $("select#uao_2").val()){
        let msj = "<h5>UAO repetidas. Favor de verificar tu selección</h5>";
        Swal.fire({
          title: 'TDAW-IIA',
          html: msj,
          icon:"error",
          confirmButtonText: 'OK',
          didDestroy:()=>{
          }
        });
      }else{
        $.ajax({
          method:"post",
          url:"./encuesta_AX.php",
          data:$("form#formUAO").serialize(),
          cache:false,
          success:(respAX)=>{
            let AX = JSON.parse(respAX);
            let icono = "";
            if(AX.cod == 1){icono = "success"}else{icono="error"}
            Swal.fire({
              title: 'TDAW-IIA',
              html: AX.msj,
              icon:icono,
              confirmButtonText: 'OK',
              didDestroy:()=>{
                if(AX.cod == 1){
                  location.reload();
                }
              }
            });
          }
        });
      }
    }
  });
});