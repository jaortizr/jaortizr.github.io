$(document).ready(function(){
  $("form#formLogin").validetta({
    bubblePosition: "bottom",
    bubbleGapTop: 10,
    bubbleGapLeft: -5,
    onValid:(e)=>{
      e.preventDefault();
      $.ajax({
        method:"post",
        url:"./pages/login_AX.php",
        data:$("form#formLogin").serialize(),
        cache:false,
        success:(respAX)=>{
          let AX = JSON.parse(respAX);
          let icono = "";
          if(AX.cod == 1){
            icono = "success";
          }else{
            icono = "error";
          }

          Swal.fire({
            title: 'TDAW-IIA',
            html: AX.msj,
            icon: icono,
            confirmButtonText: 'OK',
            didDestroy:()=>{
              if(AX.cod == 1){
                window.location.href = "./pages/encuesta.php";
              }
            }
          });
        }
      });
    }
  });
});