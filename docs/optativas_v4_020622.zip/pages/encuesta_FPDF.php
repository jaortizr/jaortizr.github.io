<?php
session_start();
$correo = $_SESSION["correo"];
include("./configBD.php");
include("./../classphp/fpdf183/fpdf.php");

$sqlGetNombre = "SELECT * FROM alumno WHERE correo = '$correo'";
$resGetNombre = mysqli_query($conexion, $sqlGetNombre);
$infGetNombre = mysqli_fetch_row($resGetNombre);

$sqlGetUAO1 = "SELECT uao.nombre FROM encuesta AS enc, uaoptativa AS uao WHERE enc.uao_1 = uao.id AND enc.correo = '$correo'";
  $resGetUAO1 = mysqli_query($conexion, $sqlGetUAO1);
  $infUAO1 = mysqli_fetch_row($resGetUAO1);
  $sqlGetUAO2 = "SELECT uao.nombre FROM encuesta AS enc, uaoptativa AS uao WHERE enc.uao_2 = uao.id AND enc.correo = '$correo'";
  $resGetUAO2 = mysqli_query($conexion, $sqlGetUAO2);
  $infUAO2 = mysqli_fetch_row($resGetUAO2);



$pdf=new FPDF('P','pt','Letter');
$pdf->AddPage();
$pdf->SetFont('Arial','B',32);
$pdf->Image("./../imgs/header.jpg",20,20,400);
$pdf->Cell(40,80,"$infGetNombre[0] $infGetNombre[1] $infGetNombre[2]");
$pdf->Cell(40,140,"$infUAO1[0] | $infUAO2[0]");
$pdf->AddPage();
$pdf->SetFont('Arial','B',24);
$pdf->Cell(40,10,'ESCOM - IPN / IIA 2');
$pdf->Output();
?>