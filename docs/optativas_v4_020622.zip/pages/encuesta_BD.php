<?php
include("./configBD.php");
$correo = $_SESSION["correo"];
$sqlCheckAlmn = "SELECT * FROM alumno where correo = '$correo'";
$resCheckAlmn = mysqli_query($conexion, $sqlCheckAlmn);
$infAlmn = mysqli_fetch_row($resCheckAlmn);
$sqlGetUAO = "SELECT * FROM uaoptativa WHERE carrera = '$infAlmn[4]'";
$resGetUAO = mysqli_query($conexion, $sqlGetUAO);
$uaos = "";
while($filas = mysqli_fetch_row($resGetUAO)){
  $uaos .= "<option value='$filas[0]'>$filas[1]</option>";
}

$sqlCheckEncuesta = "SELECT * FROM encuesta WHERE correo = '$correo'";
$resCheckEncuesta = mysqli_query($conexion, $sqlCheckEncuesta);
$encuesta = 0;
if(mysqli_num_rows($resCheckEncuesta) == 1){
  $encuesta = 1;
  $nombreAlmn = "$infAlmn[0] $infAlmn[1] $infAlmn[2]";
  $sqlGetUAO1 = "SELECT uao.nombre FROM encuesta AS enc, uaoptativa AS uao WHERE enc.uao_1 = uao.id AND enc.correo = '$correo'";
  $resGetUAO1 = mysqli_query($conexion, $sqlGetUAO1);
  $infUAO1 = mysqli_fetch_row($resGetUAO1);
  $sqlGetUAO2 = "SELECT uao.nombre FROM encuesta AS enc, uaoptativa AS uao WHERE enc.uao_2 = uao.id AND enc.correo = '$correo'";
  $resGetUAO2 = mysqli_query($conexion, $sqlGetUAO2);
  $infUAO2 = mysqli_fetch_row($resGetUAO2);
}
?>