<?php
  session_start();
  if(!isset($_SESSION["correo"])){
    header("location:./../login.html");
  }else{
    include("./encuesta_BD.php");
?>
<!DOCTYPE html>
    <html>
    <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>ENCUESTA</title>
    <meta name='viewport' content='width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no'/>
    <meta name="description" content="">
    <meta name="keywords" content="">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="./../js/materialize/css/materialize.min.css" rel="stylesheet">
    <link href="./../js/validetta/dist/validetta.min.css" rel="stylesheet">
    <link href="./../css/general.css" rel="stylesheet">
    <script src="./../js/jquery-3.6.0.min.js"></script>
    <script src="./../js/validetta/dist/validetta.min.js"></script>
    <script src="./../js/validetta/localization/validettaLang-es-ES.js"></script>
    <script src="./../js/materialize/js/materialize.min.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="./../js/encuesta.js"></script>
    </head>
    <body>
      <header>
        <img src="./../imgs/header.jpg" class="responsive-img">
        <!-- Menu -->
        <div class="fixed-action-btn">
          <a class="btn-floating btn-large blue" href="./cerrarSesion.php?sesion=correo">
            <i class="large fas fa-sign-out-alt"></i>
          </a>
        </div>
        <!-- ------ -->



      </header>
      <main class="valign-wrapper">
        <div class="container">
          <h3>Encuesta</h3>
          <?php
            if($encuesta == 0){
          ?>
          <form id="formUAO">
          <div class="row">
            <div class="col s12 m6 input-field">
              <select id="uao_1" name="uao_1" data-validetta="required">
                <option value="">--- Seleccionar ---</option>
                <?php
                  echo $uaos;
                ?>
              </select>
              <label for="uao_1">UA Optativa 1</label>
            </div>
            <div class="col s12 m6 input-field">
            <select id="uao_2" name="uao_2" data-validetta="required">
                <option value="">--- Seleccionar ---</option>
                <?php
                  echo $uaos;
                ?>
              </select>
              <label for="uao_2">UA Optativa 2</label>
            </div>
          </div>
          <div class="row">
            <button type="submit" class="btn blue" style="width:100%;">Seleccionar</button>
          </div>
          </form>
          <?php
            }else{
          ?>
            <h5><?php echo "Hola $nombreAlmn, ya contestasté la encuesta. Gracias." ?></h5>
            <h5>Las UA Optativas que seleccionaste son:</h5>
            <ul>
              <li><?php echo "$infUAO1[0]"; ?></li>
              <li><?php echo "$infUAO2[0]"; ?></li>
            </ul>
            <a href="./encuesta_mPDF.php"><i class="fas fa-file-pdf"></i> PDF</a>
          <?php
            }
          ?>
        </div>
      </main>
      <footer class="page-footer blue darken-3">
        <div class="footer-copyright">
          <div class="container">
          © 2022 Copyright TDAW-IIA
          <a class="grey-text text-lighten-4 right" href="https://www.escom.ipn.mx">ESCOM</a>
          </div>
        </div>
      </footer>
    </body>
    </html>
<?php
  }
?>