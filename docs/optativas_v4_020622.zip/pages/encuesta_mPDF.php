<?php
session_start();
$correo = $_SESSION["correo"];
include("./configBD.php");
include("./../classphp/mpdf80/vendor/autoload.php");

$sqlGetNombre = "SELECT * FROM alumno WHERE correo = '$correo'";
$resGetNombre = mysqli_query($conexion, $sqlGetNombre);
$infGetNombre = mysqli_fetch_row($resGetNombre);

$sqlGetUAO1 = "SELECT uao.nombre FROM encuesta AS enc, uaoptativa AS uao WHERE enc.uao_1 = uao.id AND enc.correo = '$correo'";
  $resGetUAO1 = mysqli_query($conexion, $sqlGetUAO1);
  $infUAO1 = mysqli_fetch_row($resGetUAO1);
  $sqlGetUAO2 = "SELECT uao.nombre FROM encuesta AS enc, uaoptativa AS uao WHERE enc.uao_2 = uao.id AND enc.correo = '$correo'";
  $resGetUAO2 = mysqli_query($conexion, $sqlGetUAO2);
  $infUAO2 = mysqli_fetch_row($resGetUAO2);



$mpdf = new \Mpdf\Mpdf();
$html = "
  <style>h1{color:red;}</style>
  <h1>ESCOM - IPN / IIA</h1>
  <img src='./../imgs/header.jpg'>
  <p>$infGetNombre[0] $infGetNombre[1] $infGetNombre[2]</p>
  <p>$infUAO1[0] | $infUAO2[0]</p>
";
$mpdf->WriteHTML($html);
$mpdf->Output();
?>