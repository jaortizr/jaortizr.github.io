<?php
  session_start();
  include("./configBD.php");

  $correo = $_SESSION["correo"];
  $uao_1 = $_POST["uao_1"];
  $uao_2 = $_POST["uao_2"];

  $sqlInsUAO = "INSERT INTO encuesta VALUES('$correo','$uao_1','$uao_2',NOW())";
  $resInsUAO = mysqli_query($conexion, $sqlInsUAO);
  $respAX = [];
  if(mysqli_affected_rows($conexion) == 1){
    $respAX["cod"] = 1;
    $respAX["msj"] = "<h5>Gracias. Tu selección ha sido guardada.</h5>";
  }else{
    $respAX["cod"] = 0;
    $respAX["msj"] = "<h5>Error. Favor de intentarlo nuevamente.</h5>";
  }

  echo json_encode($respAX);
?>