let x = "Hola Mundo x";
let y = "Otro Hola Mundo y";
var z = 23;

function suma(){
  return 3+8;
}

alert(z);
alert(suma());

console.log(suma());