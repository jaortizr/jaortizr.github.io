$(document).ready(()=>{
  

  const validarFormLogin = new JustValidate("#formLogin",{
    tooltip: {
      position: "bottom"
    }
  });

  validarFormLogin
  .addField("#boleta",[
    {
      rule:"required",
      errorMessage:"Por favor escribe tu boleta",
    },
    {
      rule:"integer",
      errorMessage:"La boleta es de solo digitos"
    },
    {
      rule: "maxLength",
      value: 10,
      errorMessage:"La boleta no debe tener más de 10 digitos"
    },
    {
      rule: "minLength",
      value: 8,
      errorMessage:"La boleta debe tener al menos 8 digitos"
    }
  ]).addField("#contrasena",[
    {
      rule:"required",
      errorMessage:"Escribe tu contraseña"
    },
    {
      rule:"password",
      errorMessage:"Revisa que tu contraseña tenga al menos 8 caracteres"
    }
  ]).onSuccess((evt)=>{
    $("#formLogin").submit((subm)=>{
      subm.preventDefault();
      let dataForm = document.forms["formLogin"];
      let boleta = md5(dataForm.boleta.value);
      let contrasena = md5(dataForm.contrasena.value);
      
      //usr = "2023630023" pass="escomipn23"
      if(boleta == "9da81afe75cfd6f763b7fd9982ad0785" && contrasena == "ef31c7b19970f19c66349c5335970572"){
        sessionStorage.setItem("boleta",boleta);
        Swal.fire({
          title: 'TDAW - 4CV3',
          text: 'Bienvenido :)',
          icon: 'success',
          confirmButtonText: 'OK',
          didClose:()=>{
            window.location.href="reservado.html";
          }
        });
      }else{
        Swal.fire({
          title: 'TDAW - 4CV3',
          text: 'Error. Revisa tus datos por favor',
          icon: 'error',
          confirmButtonText: 'OK'
        });
      }
    });
  }).onFail((evt)=>{
    console.log("Error");
  })
});