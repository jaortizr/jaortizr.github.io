/*
SQLyog Community v13.1.9 (64 bit)
MySQL - 10.4.24-MariaDB : Database - uaopts_lcd_231
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`uaopts_lcd_231` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `uaopts_lcd_231`;

/*Table structure for table `carrera` */

DROP TABLE IF EXISTS `carrera`;

CREATE TABLE `carrera` (
  `idCarrera` varchar(4) NOT NULL,
  `nombre` varchar(64) NOT NULL,
  `version` varchar(4) NOT NULL,
  PRIMARY KEY (`idCarrera`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `carrera` */

insert  into `carrera`(`idCarrera`,`nombre`,`version`) values 
('IIA','Ingeniería en Inteligencia Artificial','2020'),
('ISC','Ingeniería en Sistemas Computacinales','2009'),
('LCD','Licenciatura en Ciecia de Datos','2020');

/*Table structure for table `encuesta` */

DROP TABLE IF EXISTS `encuesta`;

CREATE TABLE `encuesta` (
  `boleta` varchar(10) NOT NULL,
  `idUAO` varchar(8) DEFAULT NULL,
  `auditoria` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `encuesta` */

/*Table structure for table `estudiante` */

DROP TABLE IF EXISTS `estudiante`;

CREATE TABLE `estudiante` (
  `boleta` varchar(10) NOT NULL,
  `curp` varbinary(18) NOT NULL,
  `nombre` varchar(64) NOT NULL,
  `primerApe` varchar(32) NOT NULL,
  `segundoApe` varchar(32) DEFAULT NULL,
  `correo` varchar(128) NOT NULL,
  `carrera` varchar(4) NOT NULL,
  `status` varchar(2) NOT NULL,
  `auditoria` datetime DEFAULT NULL,
  PRIMARY KEY (`boleta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `estudiante` */

insert  into `estudiante`(`boleta`,`curp`,`nombre`,`primerApe`,`segundoApe`,`correo`,`carrera`,`status`,`auditoria`) values 
('2023630001','ABCD123456EFGHIJ56','Juan','Pérez','Pérez','juan@juan.com','ISC','0','2022-12-13 09:49:47'),
('2023630002','ABCD','Luis','Lopez','Lopez','luis@luis.com','ISC','0','2022-12-15 11:26:36'),
('2023630003','ABCD123456EFGHIJ78','Blanca','Nieves','Nieves','blanca@blanca.com','LCD','0','2022-12-16 17:08:43'),
('2023630004','ABCD123456EFGHIJ78','Sergio','SÃ¡nchez','SÃ¡nchez','sergio@sergio.com','IIA','0','2022-12-16 18:44:59');

/*Table structure for table `uaoptativas` */

DROP TABLE IF EXISTS `uaoptativas`;

CREATE TABLE `uaoptativas` (
  `idUAO` varchar(8) NOT NULL,
  `nombre` varchar(64) NOT NULL,
  `semestre` varchar(2) NOT NULL,
  `idCarrera` varchar(4) NOT NULL,
  PRIMARY KEY (`idUAO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `uaoptativas` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
