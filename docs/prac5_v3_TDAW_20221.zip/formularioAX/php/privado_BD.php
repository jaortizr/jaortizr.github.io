<?php
  $boleta = $_SESSION["boleta"];
  $conexion = mysqli_connect("localhost","root","","sem20221");
  mysqli_set_charset($conexion, "utf8");
  $sqlCheckAdm = "SELECT * FROM alumno WHERE boleta = '$boleta'";
  $resCheckAdm = mysqli_query($conexion, $sqlCheckAdm);
  $infAdm = mysqli_fetch_row($resCheckAdm);
  $sqlGetAlumnos = "SELECT * FROM alumno WHERE boleta NOT IN($boleta)";
  $resGetAlumnos = mysqli_query($conexion, $sqlGetAlumnos);
  $trsGetAlumnos = "";
  while($filas = mysqli_fetch_array($resGetAlumnos, MYSQLI_BOTH)){
    $trsGetAlumnos .= "
    <tr>
      <td>$filas[0]</td>
      <td>$filas[1] $filas[2] $filas[3]</td>
      <td>$filas[4]</td>
      <td>
        <i class='fas fa-times icoEliminar' data-boleta='$filas[0]'></i>&nbsp;&nbsp;&nbsp;<i class='fas fa-edit icoEditar' data-boleta='$filas[0]'></i>&nbsp;&nbsp;&nbsp;<i class='fas fa-file-pdf icoPDF' data-boleta='$filas[0]'></i>&nbsp;&nbsp;&nbsp;<i class='fas fa-envelope icoCorreo' data-boleta='$filas[0]'></i>
      </td>
    </tr>";
  }

  $sqlGraf = "SELECT COUNT(*) AS numAlumnos,programa FROM alumno GROUP BY programa";
  $resGraf = mysqli_query($conexion, $sqlGraf);
  $datosJSON = [];
  while($filas = mysqli_fetch_array($resGraf, MYSQLI_BOTH)){
    $tempJSON["label"] = $filas[1];
    $tempJSON["y"] = (int)$filas[0];
    array_push($datosJSON,$tempJSON);
  }

  $json = json_encode($datosJSON);
?>