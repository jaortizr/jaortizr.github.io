<?php
  $conexion=mysqli_connect("localhost","root","","sem20221");
  $sql = "SELECT COUNT(*) AS numInscritos, programa FROM alumno GROUP BY programa";
  $res = mysqli_query($conexion,$sql);
  $x = [];
  while($filas = mysqli_fetch_array($res,MYSQLI_BOTH)){
    $tmp["label"] = $filas[1];
    $tmp["y"] = (int)$filas[0];
    array_push($x,$tmp);
  }

  $datos = json_encode($x);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>Grafica Canvas JS</title>
<meta name='viewport' content='width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no'/>
<meta name="description" content="">
<meta name="keywords" content="">
<link href="" rel="stylesheet">
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</head>
<body>
<div id="chartContainer" style="height: 300px; width: 600px;"></div>
<script type="text/javascript">
  let arrDatos = '<?php echo $datos; ?>';
  let arrDatos2 = JSON.parse(arrDatos);
  window.onload = function () {
	var chart = new CanvasJS.Chart("chartContainer", {
		title:{
			text: "Núm. de Inscritos x Carrera"              
		},
		data: [              
		{
			// Change type to "doughnut", "line", "splineArea", etc.
			type: "column",
			dataPoints: arrDatos2
		}
		]
	});
	chart.render();
}
</script>
</body>
</html>