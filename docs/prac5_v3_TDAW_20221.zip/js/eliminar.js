$(document).ready(()=>{
  $("form#formEliminar").validetta({
    bubblePosition: 'bottom',
    bubbleGapTop: 10,
    bubbleGapLeft: -5
  });
});