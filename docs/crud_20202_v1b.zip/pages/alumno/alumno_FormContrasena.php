<p>&nbsp;</p>
<div class="row">
    <form id="formCambiarContrasena">
    <div class="col s12 m4 input-field">
        <label for="contrasenaAct">Contrase&ntilde;a actual</label>
        <input type="password" id="contrasenaAct" name="contrasenaAct">
    </div>
    <div class="col s12 m4 input-field">
        <label for="contrasenaNva">Contrase&ntilde;a nueva</label>
        <input type="password" id="contrasenaNva" name="contrasenaNva">
    </div>
    <div class="col s12 m4 input-field">
        <label for="contrasenaNva2">Confirmar contrase&ntilde;a</label>
        <input type="password" id="contrasenaNva2" name="contrasenaNva2">
    </div>
    <div class="col s12 input-field">
        <input type="submit" class="btn deep-orange accent-2" style="width:100%" value="Cambiar contrase&ntilde;a">
    </div>
    </form>
</div>