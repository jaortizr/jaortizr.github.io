$(document).ready(function(){
    $('.tabs').tabs();
    $('.fixed-action-btn').floatingActionButton();
});