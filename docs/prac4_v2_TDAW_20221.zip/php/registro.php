<?php
  $boleta = $_POST["boleta"];
  $nombre = $_POST["nombre"];
  $primerApe = $_POST["primerApe"];
  $segundoApe = $_POST["segundoApe"];
  $correo = $_POST["correo"];
  $telcel = $_POST["telcel"];
  $contrasena = md5($_POST["contrasena"]);

  $conexion = mysqli_connect("localhost","root","","sem20221");
  $sqlCheckBoleta = "SELECT * FROM alumno where boleta = '$boleta'";
  $resCheckBoleta = mysqli_query($conexion, $sqlCheckBoleta);
  if(mysqli_num_rows($resCheckBoleta) == 1){
    echo "Error. El número de boleta ya está registrado. Favor de intentarlo nuevamente <a href='./../registro.html'>REGRESAR</a>";
  }else{
    $sqlInsAlumno = "INSERT INTO alumno VALUE('$boleta','$nombre','$primerApe','$segundoApe','$correo','$telcel','$contrasena',NOW())";
    $resInsAlumno = mysqli_query($conexion, $sqlInsAlumno);
    if(mysqli_affected_rows($conexion) == 1){
      echo "Gracias. Tu registro se realizó correctamente. <a href='./../index.html'>ACCEDER</a>";
    }else{
      echo "Error. No se pudo guardar tu información. Favor de intentarlo nuevamente. <a href='./../registro.html'>REGRESAR</a>";
    }
  }
  
?>