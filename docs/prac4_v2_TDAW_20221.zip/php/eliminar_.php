<?php
  $boleta = $_POST["boleta"];
  
  $conexion = mysqli_connect("localhost","root","","sem20221");
  $sqlDelAlumno = "DELETE FROM alumno WHERE boleta='$boleta'";
  $resDelAlumno = mysqli_query($conexion,$sqlDelAlumno);  
  if(mysqli_affected_rows($conexion) == 1){
    echo "Gracias. El registro se ha eliminado. <a href='./../eliminar.php'>REGRESAR</a>";
  }else{
    echo "Error. No se pudo eliminar el registro. Favor de intentarlo nuevamente. <a href='./../eliminar.php'>REGRESAR</a>";
  }
?>