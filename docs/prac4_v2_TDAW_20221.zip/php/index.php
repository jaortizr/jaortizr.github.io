<?php
  $boleta = $_POST["boleta"];
  $contrasena = md5($_POST["contrasena"]);

  $conexion = mysqli_connect("localhost","root","","sem20221");
  $sql = "SELECT * FROM alumno WHERE boleta = '$boleta' AND contrasena = '$contrasena'";
  $res = mysqli_query($conexion,$sql);
  $infAlumno = mysqli_fetch_row($res);
  if(mysqli_num_rows($res) == 1){
    echo "Bienvenido ".$infAlumno[1]."!!!";
  }else{
    echo "<p>Error. No coinciden datos. Favor de intentarlo nuevamente <a href='./../index.html'>Regresar</a></p>";
  }
?>