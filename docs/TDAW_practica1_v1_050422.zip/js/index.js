$(document).ready(function(){
    $('.slider').slider();
    $('.sidenav').sidenav();
    $('.fixed-action-btn').floatingActionButton();
    $('.tooltipped').tooltip();
    $('textarea#mensaje').characterCounter();
    $("form#formEjemplo").validetta({
      bubblePosition: 'bottom',
      bubbleGapTop: 10,
      bubbleGapLeft: -5
  });
  });