/*
SQLyog Community v13.1.9 (64 bit)
MySQL - 10.4.25-MariaDB : Database - uaopts_231
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`uaopts_231` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `uaopts_231`;

/*Table structure for table `carrera` */

DROP TABLE IF EXISTS `carrera`;

CREATE TABLE `carrera` (
  `idCarrera` varchar(4) NOT NULL,
  `nombre` varchar(64) NOT NULL,
  `version` varchar(4) NOT NULL,
  PRIMARY KEY (`idCarrera`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `carrera` */

insert  into `carrera`(`idCarrera`,`nombre`,`version`) values 
('IIA','Ingeniería en Inteligencia Artificial','2020'),
('ISC','Ingeniería en Sistemas Computacinales','2009'),
('LCD','Licenciatura en Ciecia de Datos','2020');

/*Table structure for table `encuesta` */

DROP TABLE IF EXISTS `encuesta`;

CREATE TABLE `encuesta` (
  `boleta` varchar(10) NOT NULL,
  `idUAO` varchar(8) DEFAULT NULL,
  `auditoria` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `encuesta` */

insert  into `encuesta`(`boleta`,`idUAO`,`auditoria`) values 
('2023630001','uaoisc04','2022-12-26 23:56:07'),
('2023630001','uaoisc10','2022-12-26 23:56:07');

/*Table structure for table `estudiante` */

DROP TABLE IF EXISTS `estudiante`;

CREATE TABLE `estudiante` (
  `boleta` varchar(10) NOT NULL,
  `curp` varbinary(18) NOT NULL,
  `nombre` varchar(64) NOT NULL,
  `primerApe` varchar(32) NOT NULL,
  `segundoApe` varchar(32) DEFAULT NULL,
  `correo` varchar(128) NOT NULL,
  `carrera` varchar(4) NOT NULL,
  `status` varchar(2) NOT NULL,
  `auditoria` datetime DEFAULT NULL,
  PRIMARY KEY (`boleta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `estudiante` */

insert  into `estudiante`(`boleta`,`curp`,`nombre`,`primerApe`,`segundoApe`,`correo`,`carrera`,`status`,`auditoria`) values 
('2023630001','ABCD123456EFGHIJ78','Juan','Pérez','Pérez','juan@juan.com','ISC','1','2022-12-26 23:56:07');

/*Table structure for table `uaoptativa` */

DROP TABLE IF EXISTS `uaoptativa`;

CREATE TABLE `uaoptativa` (
  `idUA` varchar(24) DEFAULT NULL,
  `nombre` varchar(384) DEFAULT NULL,
  `pacad` varchar(24) DEFAULT NULL,
  `semestre` varchar(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `uaoptativa` */

insert  into `uaoptativa`(`idUA`,`nombre`,`pacad`,`semestre`) values 
('uaoiia01','Aplicaciones de Lenguaje Natural','IIA','6'),
('uaoiia02','Cómputo en la Nube','IIA','6'),
('uaoiia03','Innovación y Emprendimiento Tecnológico','IIA','6'),
('uaoiia04','Interacción Humano-Máquina','IIA','6'),
('uaoiia05','Minería de Datos','IIA','6'),
('uaoiia06','Programación de Dispositivos Móviles','IIA','6'),
('uaoiia07','Sistemas Multiagentes','IIA','6'),
('uaoiia08','Aplicaciones de Inteligencia Artificial en Sistemas Embebidos','IIA','7'),
('uaoiia09','Aplicaciones de Sistemas Multiagentes','IIA','7'),
('uaoiia10','Big Data','IIA','7'),
('uaoiia11','Propiedad Intelectual','IIA','7'),
('uaoiia12','Técnicas de Programación para Robots Móviles','IIA','7'),
('uaoiia13','Temas Selectos de Inteligencia Artificial','IIA','7'),
('uaoiia14','Tópicos Selectos de Algoritmos Bioinspirados','IIA','7'),
('uaoisc01','Cellular Automata','ISC','6'),
('uaoisc02','Computer Graphics','ISC','6'),
('uaoisc03','Computer Security','ISC','6'),
('uaoisc04','Computing Selected Topics I','ISC','6'),
('uaoisc05','Economic Engineering','ISC','6'),
('uaoisc06','Embedded Systems','ISC','6'),
('uaoisc07','Genetic Algorithms','ISC','6'),
('uaoisc08','Introduction to Cryptography','ISC','6'),
('uaoisc09','Machine Learning','ISC','6'),
('uaoisc10','Non-Relational Databases','ISC','6'),
('uaoisc11','Software Quality Assurance and Design Patterns','ISC','6'),
('uaoisc12','Statistical Tools for Data Analytics','ISC','6'),
('uaoisc13','Virtual Instrumentation','ISC','6'),
('uaoisc14','Big Data','ISC','7'),
('uaoisc15','Bioinformatics','ISC','7'),
('uaoisc16','Complex Systems','ISC','7'),
('uaoisc17','Computing Selected Topics II','ISC','7'),
('uaoisc18','Data Mining','ISC','7'),
('uaoisc19','High Technology Enterprise Management','ISC','7'),
('uaoisc20','Image Analysis','ISC','7'),
('uaoisc21','Internet of Things','ISC','7'),
('uaoisc22','IT Governance','ISC','7'),
('uaoisc23','Natural Language Processing','ISC','7'),
('uaoisc24','Selected Topics in Cryptography','ISC','7'),
('uaoisc25','Virtual and Augmented Reality','ISC','7'),
('uaoisc26','Virtual Instrumentation Applications','ISC','7'),
('uaoisc27','Web Client and Backend Development Frameworks','ISC','7'),
('uaolcd01','Bioinformática Básica','LCD','6'),
('uaolcd02','Ciberseguridad','LCD','6'),
('uaolcd03','Estadística Avanzada','LCD','6'),
('uaolcd04','Innovación y Emprendimiento Tecnológico','LCD','6'),
('uaolcd05','Simulación Básica','LCD','6'),
('uaolcd06','Sistemas de Información Geográfica','LCD','6'),
('uaolcd07','Temas Selectos de Inteligencia Artificial','LCD','6'),
('uaolcd08','Bioinformática Avanzada','LCD','7'),
('uaolcd09','Propiedad Intelectual','LCD','7'),
('uaolcd10','Protección de Datos','LCD','7'),
('uaolcd11','Simulación Avanzada','LCD','7'),
('uaolcd12','Temas Selectos de Aprendizaje Profundo','LCD','7'),
('uaolcd13','Temas Selectos de Procesamiento de Lenguaje Natural','LCD','7');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
