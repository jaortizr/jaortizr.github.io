<?php
  session_start();
  include("./configBD.php");

  $boleta = $_POST["boleta"];
  $curp = $_POST["curp"];
  $respAX = [];

  $sqlGetEstudiante = "SELECT * FROM estudiante WHERE boleta = '$boleta' AND curp = '$curp'";
  $resGetEstudiante = mysqli_query($conexion, $sqlGetEstudiante);
  if(mysqli_num_rows($resGetEstudiante) == 1){
    $respAX["cod"] = 1;
    $respAX["msj"] = "Bienvenido!";
    $respAX["icono"] = "success";
    $_SESSION["boleta"] = $boleta;
  }else{
    $respAX["cod"] = 0;
    $respAX["msj"] = "Error. Favor de revisar tu información";
    $respAX["icono"] = "error";
  }

  echo json_encode($respAX);
?>