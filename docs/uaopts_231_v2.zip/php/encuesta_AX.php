<?php
  session_start();
  include("./configBD.php");

  $boleta = $_SESSION["boleta"];
  $idUAO1 = $_POST["uao1"];
  $idUAO2 = $_POST["uao2"];
  $respAX = [];

  $sqlInsUAO = "INSERT INTO encuesta(boleta,idUAO,auditoria)VALUES('$boleta','$idUAO1',NOW()),('$boleta','$idUAO2',NOW())";
  $resInsUAO = mysqli_query($conexion, $sqlInsUAO);
  if(mysqli_affected_rows($conexion) == 2){
    $sqlUpdEstudiante = "UPDATE estudiante SET status = '1', auditoria = NOW() WHERE boleta = '$boleta'";
    $resUpdEstudiante = mysqli_query($conexion, $sqlUpdEstudiante);
    if(mysqli_affected_rows($conexion) == 1){
      $respAX["cod"] = 1;
      $respAX["msj"] = "Gracias. Se han registrado sus intentenciones de inscripción.";
      $respAX["icono"] = "success";
    }else{
      $respAX["cod"] = 2;
      $respAX["msj"] = "Error(Est). Favor de intentarlo nuevamente.";
      $respAX["icono"] = "error";
    }
  }else{
    $respAX["cod"] = 0;
    $respAX["msj"] = "Error(Enc). Favor de intentarlo nuevamente.";
    $respAX["icono"] = "error";
  }

  echo json_encode($respAX);
?>