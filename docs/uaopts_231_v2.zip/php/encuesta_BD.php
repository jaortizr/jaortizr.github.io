<?php
  include("./configBD.php");

  $boleta = $_SESSION["boleta"];
  $optsUAO = "";
  $lisUAO = "";

  $sqlGetEstudiante = "SELECT * FROM estudiante WHERE boleta = '$boleta'";
  $resGetEstudiante = mysqli_query($conexion, $sqlGetEstudiante);
  $infGetEstudiante = mysqli_fetch_row($resGetEstudiante);

  $sqlGetUAO = "SELECT uao.nombre FROM encuesta AS enc, estudiante AS est, uaoptativa AS uao WHERE enc.boleta = est.boleta AND enc.idUAO = uao.idUA AND enc.boleta = '$boleta'";
  $resGetUAO = mysqli_query($conexion, $sqlGetUAO);
  while($filas = mysqli_fetch_array($resGetUAO)){
    $lisUAO .= "<li>$filas[0]</li>";
  }

  $sqlGetUAO = "SELECT * FROM uaoptativa WHERE pacad = '$infGetEstudiante[6]' AND semestre = '6' ORDER BY nombre";
  $resGetUAO = mysqli_query($conexion, $sqlGetUAO);
  while($filas = mysqli_fetch_array($resGetUAO)){
    $optsUAO .= "<option value='$filas[0]'>$filas[1]</option>";
  }
?>