<?php
  session_start();
  if(isset($_SESSION["boleta"])){
    include("./configBD.php");
    
    $boleta = $_SESSION["boleta"];

    $sqlGetEstudiante = "SELECT * FROM estudiante WHERE boleta= '$boleta'";
    $resGetEstudiante = mysqli_query($conexion, $sqlGetEstudiante);
    $infGetEstudiante = mysqli_fetch_row($resGetEstudiante);

    $txtUAO = "";
    $sqlGetUAO = "SELECT uao.nombre FROM encuesta AS enc, estudiante AS est, uaoptativa AS uao WHERE enc.boleta = est.boleta AND enc.idUAO = uao.idUA AND enc.boleta = '$boleta'";
    $resGetUAO = mysqli_query($conexion, $sqlGetUAO);
    while($filas = mysqli_fetch_array($resGetUAO)){
      $txtUAO .= "$filas[0] <br>";
    }

    $firma = md5($boleta);
  
    $estilos = "
        <style>
            body{font-family:verdana}
            .txtAzul{color:#006699;}
        </style>
    ";

    $header = "
        <table width='100%'>
            <tr><td><img src='./../imgs/header.jpg'></td></tr>
        </table>
    ";

    $html = "";
    $html .= $estilos;
    $html .= "<h2>Encuesta UA Optativas</h2><h4>$infGetEstudiante[2] $infGetEstudiante[3] $infGetEstudiante[4]</h4>";
    $html .= $txtUAO;

    $pie = "
      <p align='center'>$firma</p>
    ";

    include("./mpdfV8/vendor/autoload.php");
    $mpdf = new \Mpdf\Mpdf([
      "mode"=>"c",
      "orientation"=>"P",
      "format"=>"Letter",
      "default_font_size"=>12,
      "default_font"=>"dejavusans",
      "margin_left"=>15,
      "margin_right"=>10,
      "margin_top"=>30,
      "margin_bottom"=>10,
      "margin_header"=>5,
      "margin_footer"=>5
    ]);
    $mpdf->SetWatermarkText("[T]DAW - 20231");
    $mpdf->SetHTMLHeader($header);
    $mpdf->WriteHTML($html);
    $mpdf->SetHTMLFooter($pie);
    $mpdf->showWatermarkText = true;
    $mpdf->output();

  }else{
    header("location:./../");
  }
  
?>