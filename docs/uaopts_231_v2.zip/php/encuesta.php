<?php
  session_start();
  if(isset($_SESSION["boleta"])){
    include("./encuesta_BD.php");
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Encuesta</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
  <link href="./../js/materialize/css/materialize.min.css" rel="stylesheet">
  <link href="./../css/general.css" rel="stylesheet">
  <script src="./../js/jquery-3.6.1.min.js"></script>
  <script src="./../js/materialize/js/materialize.min.js"></script>
  <script src="./../js/plugins/justValidate.js"></script>
  <script src="./../js/plugins/sweetAlert.js"></script>
  <script src="./../js/encuesta.js"></script>
</head>
<body>
  <header>
    <img src="./../imgs/header.jpg" class="responsive-img">
    <div class="fixed-action-btn">
      <a class="btn-floating btn-large blue-grey">
        <i class="fas fa-ellipsis"></i>
      </a>
      <ul>
        <li><a href="./cerrarSesion.php?nombreSesion=boleta" class="btn-floating red"><i class="fas fa-power-off"></i></a></li>
      </ul>
    </div>
  </header>
  <main class="valign-wrapper">
    <div class="container">
      <div class="row">
        <h3>Encuesta</h3>
        <h4><?php echo "$infGetEstudiante[2] $infGetEstudiante[3] $infGetEstudiante[4]"; ?></h4>
      </div>
      <?php
        if($infGetEstudiante[7] == 0){
      ?>
      <form id="formUAO" autocomplete="off">
        <div class="row">
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nisi quisquam sint, at maiores natus nam inventore repellendus ratione voluptatum quia animi dignissimos aspernatur nihil officiis! Alias asperiores, ratione sit, velit officia dolorem totam neque, veritatis error nam nostrum enim minus magni quibusdam rerum voluptatum! Ipsum doloremque illo deserunt repellat! Nesciunt.</p>
          <div class="col s12 m6 input-field">
            <i class="fas fa-cog prefix"></i>
            <select id="uao1" name="uao1">
              <option value="">--- Seleccionar ---</option>
              <?php echo $optsUAO; ?>
            </select>
            <label for="uao1">UA Optativa 1</label>
          </div>
          <div class="col s12 m6 input-field">
            <i class="fas fa-cog prefix"></i>
            <select id="uao2" name="uao2">
              <option value="">--- Seleccionar ---</option>
              <?php echo $optsUAO; ?>
            </select>
            <label for="uao2">UA Optativa 2</label>
          </div>
          <div class="col s12 input-field">
            <button type="submit" class="btn blue" style="width:100%">Registrar</button>
          </div>
        </div>
      </form>
      <?php
        }else{
      ?>
      <div class="row">
        <h5>Gracias! Ya has contestado la encuesta sobre tus intenciones de inscripción a UA Optativas.</h5>
        <ul>
          <?php
            echo $lisUAO;
          ?>
        </ul>
        <a href="./pdfUAO.php"><i class="fas fa-file-pdf"></i> Comprobante</a>
      </div>
      <?php
        }
      ?>
    </div>
  </main>
  <footer class="page-footer blue">
    <div class="container">
      <div class="footer-copyright blue">
        <div class="container">
          © 2022 Copyright ESCOM-LCD
          <a class="grey-text text-lighten-4 right" href="https://www.escom.ipn.mx">escom.ipn.mx</a>
        </div>
    </div>
  </footer>
</body>
</html>
<?php
  }else{
    header("location:./../");
  }
?>