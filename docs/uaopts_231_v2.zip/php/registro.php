<?php
  include("./configBD.php");

  $boleta = $_POST["boleta"];
  $curp = $_POST["curp"];
  $nombre = $_POST["nombre"];
  $primerApe = $_POST["primerApe"];
  $segundoApe = $_POST["segundoApe"];
  $correo = $_POST["correo"];
  $carrera = $_POST["carrera"];

  $conexion = mysqli_connect($servidorBD, $usuarioBD, $contrasenaBD, $nombreBD);
  $sql = "INSERT INTO estudiante VALUES('$boleta','$curp','$nombre','$primerApe','$segundoApe','$correo','$carrera','0',NOW())";
  $res = mysqli_query($conexion, $sql);
  $filasAfectadas = mysqli_affected_rows($conexion);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registro - UAOpts</title>
  <script src="./../js/plugins/sweetAlert.js"></script>
</head>
<body>
  <?php
    if($filasAfectadas == 1){
  ?>
    <script>
      Swal.fire({
        icon: "success",
        title: "ESCOM-LCD 20231",
        text: "Gracias. Tus datos se registraron correctamente",
        didDestroy: ()=>{
          window.location.href = "./../html/registro.html";
        }
      });
    </script>
  <?php
    }else{
  ?>
    <script>
      Swal.fire({
        icon: "error",
        title: "ESCOM-LCD 20231",
        text: "Error. Favor de intentarlo nuevamente",
        didDestroy: ()=>{
          window.location.href = "./../html/registro.html";
        }
      });
    </script>
  <?php
    }
  ?>
</body>
</html>