$(document).ready(()=>{
  const validaLogin = new JustValidate("#formLogin",{
    tooltip:{position:"bottom"}
  });
  
  validaLogin
    .addField("#boleta",[
      {rule:"required", errorMessage:"Falta tu boleta"},
      {rule:"number", errorMessage:"Solo números"},
      {rule:"minLength", value:8, errorMessage:"Mínimo 8 digitos"},
      {rule:"maxLength", value:10, errorMessage:"Máximo 10 digitos"}
    ])
    .addField("#curp",[
      {rule:"required", errorMessage:"Falta tu CURP"},
      {rule:"minLength", value:18, errorMessage:"Formato incorrecto"},
      {rule:"maxLength", value:18, errorMessage:"Formato incorrecto"}
    ])
    .onSuccess((e)=>{
      e.preventDefault();
      $.ajax({
        url:"./php/index_AX.php",
        method:"POST",
        data:$("#formLogin").serialize(),
        cache:false,
        success:(respServ)=>{
          console.log(respServ);
          const AX = JSON.parse(respServ);
          Swal.fire({
            title:"ESCOM [T]DAW",
            text:AX.msj,
            icon:AX.icono,
            didDestroy:()=>{
              if(AX.cod == 1)
                window.location.href="./php/encuesta.php";
              else
                location.reload();
            }
          });
        }
      });
    });
});