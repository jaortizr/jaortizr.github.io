$(document).ready(()=>{
  $("select").formSelect();
  $(".fixed-action-btn").floatingActionButton();

  const validaUAO = new JustValidate("#formUAO");

  validaUAO
    .addField("#uao1",[
      {rule:"required", errorMessage:"Falta seleccionar UAO"}
    ])
    .addField("#uao2",[
      {rule:"required", errorMessage:"Falta seleccionar UAO"}
    ])
    .onSuccess((e)=>{
      e.preventDefault();
      let uao1 = $("#uao1").val();
      let uao2 = $("#uao2").val();
      if(uao1 == uao2){
        Swal.fire({
          title:"ESCOM [T]DAW",
          text:"No puede seleccionar la misma UA Optativa",
          icon:"warning"
        });
      }else{
        $.ajax({
          url:"./encuesta_AX.php",
          method:"POST",
          data:$("#formUAO").serialize(),
          cache:false,
          success:(respServ)=>{
            const AX = JSON.parse(respServ);
            Swal.fire({
              title:"ESCOM [T]DAW",
              text:AX.msj,
              icon:AX.icono,
              didDestroy:()=>{
                if(AX.cod == 1){
                  location.reload();
                }
              }
            });
          }
        });
      }
    });
});