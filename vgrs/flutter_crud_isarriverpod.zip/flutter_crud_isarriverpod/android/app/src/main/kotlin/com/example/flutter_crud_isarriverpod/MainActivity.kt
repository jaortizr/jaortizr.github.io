package com.example.flutter_crud_isarriverpod

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
