import 'package:isar/isar.dart';
import 'user_role.dart';

part 'app_user.g.dart';

@collection
class AppUser {
  Id id = Isar.autoIncrement;

  @Index(unique: true)
  late String email;
  late String name;
  
  @enumerated
  late UserRole role;

  late DateTime createdAt;
}