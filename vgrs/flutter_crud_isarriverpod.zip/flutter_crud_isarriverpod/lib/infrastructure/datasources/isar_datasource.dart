import 'package:isar/isar.dart';
import 'package:path_provider/path_provider.dart';
import '../../domain/models/app_user.dart';

class IsarDatasource {
  static Future<Isar> openDB() async {
    final dir = await getApplicationDocumentsDirectory();
    if (Isar.instanceNames.isEmpty) {
      return await Isar.open(
        [AppUserSchema],
        directory: dir.path,
      );
    }
    return Isar.getInstance()!;
  }
}