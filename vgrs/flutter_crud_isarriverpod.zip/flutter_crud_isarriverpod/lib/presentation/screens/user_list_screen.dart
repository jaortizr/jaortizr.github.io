import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/user_provider.dart';
import '../providers/user_form_provider.dart';
import 'user_form_screen.dart';

class UserListScreen extends ConsumerWidget {
  const UserListScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final usersAsync = ref.watch(userNotifierProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('CRUD Ingenieros')),
      body: usersAsync.when(
        data: (users) => ListView.builder(
          itemCount: users.length,
          itemBuilder: (context, index) {
            final user = users[index];
            return ListTile(
              title: Text(user.name),
              subtitle: Text("${user.email} - ${user.role.name}"),
              onTap: () {
                ref.read(userFormProvider.notifier).setFormUser(user);
                Navigator.push(context, MaterialPageRoute(builder: (_) => const UserFormScreen()));
              },
              trailing: IconButton(
                icon: const Icon(Icons.delete_outline, color: Colors.red),
                onPressed: () => ref.read(userNotifierProvider.notifier).deleteUser(user.id),
              ),
            );
          },
        ),
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, __) => Center(child: Text('Error: $e')),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          ref.invalidate(userFormProvider);
          Navigator.push(context, MaterialPageRoute(builder: (_) => const UserFormScreen()));
        },
        child: const Icon(Icons.person_add),
      ),
    );
  }
}