import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:isar/isar.dart';
import '../providers/user_form_provider.dart';
import '../providers/user_provider.dart';
import '../../domain/models/user_role.dart';

class UserFormScreen extends ConsumerStatefulWidget {
  // Cambiamos a ConsumerStatefulWidget
  const UserFormScreen({super.key});

  @override
  ConsumerState<UserFormScreen> createState() => _UserFormScreenState();
}

class _UserFormScreenState extends ConsumerState<UserFormScreen> {
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    // IMPORTANTE: Usamos ref.read para obtener los valores inicialES una sola vez
    // o usamos select para solo observar cambios críticos (como el ID).
    final userNotifier = ref.read(userFormProvider.notifier);
    final initialUser = ref.read(userFormProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Formulario de Usuario')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(
              // Usamos initialValue solo la primera vez
              initialValue: initialUser.name,
              decoration: const InputDecoration(labelText: 'Nombre'),
              // NO usamos ref.watch aquí para el valor, solo notificamos el cambio
              onChanged: (value) => userNotifier.updateName(value),
              validator: (v) => v!.isEmpty ? 'Requerido' : null,
            ),
            const SizedBox(height: 10),
            TextFormField(
              initialValue: initialUser.email,
              decoration: const InputDecoration(labelText: 'Email'),
              onChanged: (value) => userNotifier.updateEmail(value),
              validator: (v) => !v!.contains('@') ? 'Email inválido' : null,
            ),
            const SizedBox(height: 10),
            // Para el Dropdown sí podemos usar un watch específico
            Consumer(
              builder: (context, ref, child) {
                final role = ref.watch(userFormProvider.select((u) => u.role));
                return DropdownButtonFormField<UserRole>(
                  value: role,
                  items: UserRole.values
                      .map(
                        (r) => DropdownMenuItem(
                          value: r,
                          child: Text(r.name.toUpperCase()),
                        ),
                      )
                      .toList(),
                  onChanged: (r) => userNotifier.updateRole(r!),
                );
              },
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                if (_formKey.currentState!.validate()) {
                  // Obtenemos el estado actual del form antes de guardar
                  final currentUser = ref.read(userFormProvider);
                  ref.read(userNotifierProvider.notifier).saveUser(currentUser);
                  Navigator.pop(context);
                }
              },
              child: const Text('Guardar'),
            ),
          ],
        ),
      ),
    );
  }
}



// class UserFormScreen extends ConsumerWidget {
//   const UserFormScreen({super.key});

//   @override
//   Widget build(BuildContext context, WidgetRef ref) {
//     final user = ref.watch(userFormProvider);
//     final formKey = GlobalKey<FormState>();

//     return Scaffold(
//       appBar: AppBar(title: Text(user.id == Isar.autoIncrement ? 'Nuevo' : 'Editar')),
//       body: Form(
//         key: formKey,
//         child: ListView(
//           padding: const EdgeInsets.all(16),
//           children: [
//             TextFormField(
//               initialValue: user.name,
//               decoration: const InputDecoration(labelText: 'Nombre'),
//               onChanged: ref.read(userFormProvider.notifier).updateName,
//               validator: (v) => v!.isEmpty ? 'Requerido' : null,
//             ),
//             TextFormField(
//               initialValue: user.email,
//               decoration: const InputDecoration(labelText: 'Email'),
//               onChanged: ref.read(userFormProvider.notifier).updateEmail,
//               validator: (v) => !v!.contains('@') ? 'Inválido' : null,
//             ),
//             DropdownButtonFormField<UserRole>(
//               value: user.role,
//               items: UserRole.values.map((r) => DropdownMenuItem(value: r, child: Text(r.name))).toList(),
//               onChanged: (r) => ref.read(userFormProvider.notifier).updateRole(r!),
//             ),
//             const SizedBox(height: 20),
//             ElevatedButton(
//               onPressed: () {
//                 if (formKey.currentState!.validate()) {
//                   ref.read(userNotifierProvider.notifier).saveUser(user);
//                   Navigator.pop(context);
//                 }
//               },
//               child: const Text('Guardar'),
//             )
//           ],
//         ),
//       ),
//     );
//   }
// }