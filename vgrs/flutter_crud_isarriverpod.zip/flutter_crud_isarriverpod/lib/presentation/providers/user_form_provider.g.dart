// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user_form_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$userFormHash() => r'79a4c5109812ab24642319719a72aa8f7dc88e3b';

/// See also [UserForm].
@ProviderFor(UserForm)
final userFormProvider =
    AutoDisposeNotifierProvider<UserForm, AppUser>.internal(
  UserForm.new,
  name: r'userFormProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$userFormHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$UserForm = AutoDisposeNotifier<AppUser>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
