import 'package:riverpod_annotation/riverpod_annotation.dart';
import '../../domain/models/app_user.dart';
import '../../domain/models/user_role.dart';

part 'user_form_provider.g.dart';

@riverpod
class UserForm extends _$UserForm {
  @override
  AppUser build() {
    return AppUser()
      ..name = ''
      ..email = ''
      ..role = UserRole.viewer
      ..createdAt = DateTime.now();
  }

  void setFormUser(AppUser user) => state = user;

  void updateName(String name) => state = _copy(name: name);
  void updateEmail(String email) => state = _copy(email: email);
  void updateRole(UserRole role) => state = _copy(role: role);

  AppUser _copy({String? name, String? email, UserRole? role}) {
    return AppUser()
      ..id = state.id
      ..name = name ?? state.name
      ..email = email ?? state.email
      ..role = role ?? state.role
      ..createdAt = state.createdAt;
  }
}