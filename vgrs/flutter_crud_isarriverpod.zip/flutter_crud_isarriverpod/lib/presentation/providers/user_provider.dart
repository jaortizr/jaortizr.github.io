import 'package:riverpod_annotation/riverpod_annotation.dart';
import '../../domain/models/app_user.dart';
import '../../infrastructure/datasources/isar_datasource.dart';
import 'package:isar/isar.dart';

part 'user_provider.g.dart';

@riverpod
class UserNotifier extends _$UserNotifier {
  @override
  Future<List<AppUser>> build() async {
    final isar = await IsarDatasource.openDB();
    return await isar.appUsers.where().findAll();
  }

  Future<void> saveUser(AppUser user) async {
    final isar = await IsarDatasource.openDB();
    await isar.writeTxn(() => isar.appUsers.put(user));
    ref.invalidateSelf(); // Refresca la lista automáticamente
  }

  Future<void> deleteUser(int id) async {
    final isar = await IsarDatasource.openDB();
    await isar.writeTxn(() => isar.appUsers.delete(id));
    ref.invalidateSelf();
  }
}