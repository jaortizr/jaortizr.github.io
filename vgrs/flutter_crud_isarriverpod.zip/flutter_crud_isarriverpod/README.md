# flutter_crud_isarriverpod

A new Flutter project.
