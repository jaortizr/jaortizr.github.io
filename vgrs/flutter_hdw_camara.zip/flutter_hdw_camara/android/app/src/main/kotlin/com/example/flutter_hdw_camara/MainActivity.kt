package com.example.flutter_hdw_camara

/*
import io.flutter.embedding.android.FlutterActivity
class MainActivity : FlutterActivity()
*/

import io.flutter.embedding.android.FlutterFragmentActivity

class MainActivity: FlutterFragmentActivity() {
}