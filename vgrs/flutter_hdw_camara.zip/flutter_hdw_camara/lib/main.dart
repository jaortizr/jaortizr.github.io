import 'package:flutter/material.dart';
import 'core/theme/theme.dart';
import 'features/home/screens/home_screen.dart';

void main() {
  // Asegura que los bindings nativos de los sensores estén listos antes de arrancar la app
  WidgetsFlutterBinding.ensureInitialized();
  
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Ingeniería de Sensores Móviles',
      theme: AppTheme.lightTheme,
      home: const HomeScreen(),
    );
  }
}