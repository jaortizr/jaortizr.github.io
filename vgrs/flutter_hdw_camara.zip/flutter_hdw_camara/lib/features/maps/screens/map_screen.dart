import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import 'dart:async';

class MapScreen extends StatefulWidget {
  const MapScreen({super.key});

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  // Coordenadas iniciales por defecto (por ejemplo, Ciudad de México)
  LatLng _currentLatLng = const LatLng(19.4326, -99.1332);
  
  // Controlador para manipular la cámara del mapa (Zoom y Centro)
  final MapController _mapController = MapController();
  
  StreamSubscription<Position>? _gpsStreamSubscription;
  bool _isGpsReady = false;
  String _loadingText = "Inicializando mapa y buscando satélites...";

  @override
  void initState() {
    super.initState();
    _initMapWithGps();
  }

  // 1. Algoritmo de inicialización combinada: Permisos + Obtención de Coordenadas
  Future<void> _initMapWithGps() async {
    bool serviceEnabled;
    LocationPermission permission;

    // Verificar si el hardware de ubicación global está activo
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      setState(() { _loadingText = "Por favor, enciende el GPS del teléfono."; });
      return;
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        setState(() { _loadingText = "Permiso de ubicación denegado."; });
        return;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      setState(() { _loadingText = "Permisos bloqueados permanentemente en Ajustes."; });
      return;
    }

    // Obtener la primera posición del satélite de forma síncrona para centrar el mapa
    try {
      Position position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(accuracy: LocationAccuracy.high)
      );

      setState(() {
        _currentLatLng = LatLng(position.latitude, position.longitude);
        _isGpsReady = true;
      });

      // Mover la cámara del mapa a las coordenadas reales con un zoom de 16 (nivel calle)
      _mapController.move(_currentLatLng, 16.0);

      // 2. Encender el Stream para actualizar el marcador reactivamente si el usuario camina
      _startLiveTracking();

    } catch (e) {
      setState(() { _loadingText = "Error al conectar con el sensor GPS: $e"; });
    }
  }

  // 3. Monitoreo reactivo de movimiento para actualizar el marcador en el mapa
  void _startLiveTracking() {
    const LocationSettings settings = LocationSettings(
      accuracy: LocationAccuracy.high,
      distanceFilter: 3, // Se actualiza si el alumno se mueve más de 3 metros
    );

    _gpsStreamSubscription = Geolocator.getPositionStream(locationSettings: settings)
        .listen((Position position) {
      if (!mounted) return;
      
      setState(() {
        _currentLatLng = LatLng(position.latitude, position.longitude);
      });
      
      // Opcional: Centrar el mapa automáticamente en cada paso del usuario
      _mapController.move(_currentLatLng, _mapController.camera.zoom);
    });
  }

  @override
  void dispose() {
    // CRUCIAL: Apagar el GPS y limpiar el controlador del mapa para evitar fugas de RAM
    _gpsStreamSubscription?.cancel();
    _mapController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mapa Open Source & GPS')),
      body: Stack(
        children: [
          // Capa Base: Renderizador del mapa interactivo
          FlutterMap(
            mapController: _mapController,
            options: MapOptions(
              initialCenter: _currentLatLng,
              initialZoom: 13.0,
              maxZoom: 18.0,
              minZoom: 3.0,
            ),
            children: [
              // Capa 1: Descarga de mosaicos desde el servidor gratuito de OpenStreetMap
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.example.mi_app_sensores',
              ),
              
              // Capa 2: Marcador dinámico que sigue la posición del GPS
              if (_isGpsReady)
                MarkerLayer(
                  markers: [
                    Marker(
                      point: _currentLatLng,
                      width: 50,
                      height: 50,
                      alignment: Alignment.topCenter, // Asegura que la punta del pin apunte exacto a la coordenada
                      child: const Icon(
                        Icons.location_on,
                        color: Colors.red,
                        size: 45,
                      ),
                    ),
                  ],
                ),
            ],
          ),

          // Capa de bloqueo superior (Pantalla de carga mientras el chip GPS engancha los satélites)
          if (!_isGpsReady)
            Container(
              color: Colors.white,
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const CircularProgressIndicator(),
                    const SizedBox(height: 20),
                    Text(
                      _loadingText,
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ),
            
          // Botón flotante para re-centrar el mapa manualmente en la ubicación del alumno
          if (_isGpsReady)
            Positioned(
              bottom: 20,
              right: 20,
              child: FloatingActionButton(
                onPressed: () {
                  _mapController.move(_currentLatLng, 16.0);
                },
                backgroundColor: Colors.blueAccent,
                child: const Icon(Icons.my_location, color: Colors.white),
              ),
            ),
        ],
      ),
    );
  }
}