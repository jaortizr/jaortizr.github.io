import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'dart:async';

class GpsScreen extends StatefulWidget {
  const GpsScreen({super.key});

  @override
  State<GpsScreen> createState() => _GpsScreenState();
}

class _GpsScreenState extends State<GpsScreen> {
  String _currentPositionText = "Presiona el botón para obtener ubicación";
  String _livePositionText = "Escuchando cambios en tiempo real...";

  // El StreamSubscription nos permite pausar o cancelar la escucha del GPS
  StreamSubscription<Position>? _positionStreamSubscription;
  bool _isListening = false;

  @override
  void initState() {
    super.initState();
    // Opcional: Podríamos verificar permisos desde el inicio aquí
  }

  // 1. Lógica rigurosa para verificar y solicitar permisos de hardware
  Future<bool> _handlePermission() async {
    bool serviceEnabled;
    LocationPermission permission;

    // Verificar si los servicios de ubicación del dispositivo están encendidos
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      setState(() {
        _currentPositionText =
            'Los servicios de ubicación están desactivados en el teléfono.';
      });
      return false;
    }

    // Verificar el estado de los permisos de la app
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      // Solicitar permisos por primera vez
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        setState(() {
          _currentPositionText =
              'Permisos de ubicación denegados por el usuario.';
        });
        return false;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      // El usuario bloqueó los permisos permanentemente de forma manual
      setState(() {
        _currentPositionText =
            'Los permisos están denegados permanentemente. Configúralos en ajustes.';
      });
      return false;
    }

    return true;
  }

  // 2. Obtener la ubicación actual (Una sola vez - Ideal para check-ins o publicaciones)
  Future<void> _getCurrentLocation() async {
    final hasPermission = await _handlePermission();
    if (!hasPermission) return;

    setState(() {
      _currentPositionText = "Obteniendo coordenadas...";
    });

    try {
      // LocationAccuracy.high usa el hardware GPS. medium usa redes/Wi-Fi (gasta menos batería).
      Position position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
        ),
      );

      setState(() {
        _currentPositionText =
            "Latitud: ${position.latitude}\n"
            "Longitud: ${position.longitude}\n"
            "Altitud: ${position.altitude} metros\n"
            "Precisión: ±${position.accuracy.toStringAsFixed(1)} m";
      });
    } catch (e) {
      setState(() {
        _currentPositionText = "Error al obtener ubicación: $e";
      });
    }
  }

  // 3. Escuchar la ubicación en tiempo real (Stream - Ideal para apps de navegación/Uber)
  void _toggleLiveLocation() async {
    final hasPermission = await _handlePermission();
    if (!hasPermission) return;

    if (_isListening) {
      // Si ya está escuchando, cancelamos la suscripción para liberar el GPS
      await _positionStreamSubscription?.cancel();
      setState(() {
        _isListening = false;
        _livePositionText = "Escucha en tiempo real detenida.";
      });
    } else {
      setState(() {
        _isListening = true;
      });

      // Configuramos los ajustes del stream:
      // distanceFilter: 2 significa que solo emitirá un evento si el usuario se mueve más de 2 metros.
      const LocationSettings locationSettings = LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 2,
      );

      _positionStreamSubscription =
          Geolocator.getPositionStream(
            locationSettings: locationSettings,
          ).listen((Position position) {
            setState(() {
              _livePositionText =
                  "MOVIMIENTO DETECTADO:\n"
                  "Lat: ${position.latitude}\n"
                  "Lng: ${position.longitude}\n"
                  "Velocidad: ${(position.speed * 3.6).toStringAsFixed(1)} km/h"; // Convertido de m/s a km/h
            });
          });
    }
  }

  @override
  void dispose() {
    // CRUCIAL: Apagar el Stream al salir de la pantalla para evitar fugas de memoria y drenado de batería
    _positionStreamSubscription?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sensor: GPS y Ubicación')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Sección 1: Ubicación Única
            Card(
              elevation: 4,
              color: Colors.blue.withValues(alpha: 0.05),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    const Text(
                      'Lectura Única (Bajo Demanda)',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(_currentPositionText, textAlign: TextAlign.center),
                    const SizedBox(height: 12),
                    ElevatedButton.icon(
                      onPressed: _getCurrentLocation,
                      icon: const Icon(Icons.location_searching),
                      label: const Text('Obtener Coordenadas'),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Sección 2: Ubicación en Tiempo Real
            Card(
              elevation: 4,
              color: _isListening
                  ? Colors.green.withValues(alpha: 0.05)
                  : Colors.grey.withValues(alpha: 0.05),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    const Text(
                      'Flujo Continuo (Streams)',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      _livePositionText,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: _isListening ? Colors.green[800] : Colors.black,
                      ),
                    ),
                    const SizedBox(height: 12),
                    ElevatedButton.icon(
                      onPressed: _toggleLiveLocation,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _isListening
                            ? Colors.redAccent
                            : Colors.teal,
                        foregroundColor: Colors.white,
                      ),
                      icon: Icon(_isListening ? Icons.stop : Icons.play_arrow),
                      label: Text(
                        _isListening
                            ? 'Detener Rastreo'
                            : 'Iniciar Rastreo en Vivo',
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
