import 'package:flutter/material.dart';
import 'package:flutter_hdw_camara/features/biometrics/screens/biometric_screen.dart';
import 'package:flutter_hdw_camara/features/bluetooth/screens/bluetooth_screen.dart';
import 'package:flutter_hdw_camara/features/camera/screens/camera_screen.dart';
import 'package:flutter_hdw_camara/features/delivery_tracker/screens/tracker_screen.dart';
import 'package:flutter_hdw_camara/features/gps/screens/gps_screen.dart';
import 'package:flutter_hdw_camara/features/maps/screens/map_screen.dart';
import 'package:flutter_hdw_camara/features/microphone/screens/microphone_screen.dart';
import 'package:flutter_hdw_camara/features/wifi/screens/wifi_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Laboratorio de Sensores')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: GridView.count(
          crossAxisCount: 2, // 2 columnas
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          children: [
            // Tarjeta para el Sensor 1: Cámara
            _SensorCard(
              title: 'Cámara',
              icon: Icons.camera_alt,
              color: Colors.blue,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const CameraScreen()),
                );
              },
            ),

            // Tarjetas inactivas que se activarán en las siguientes clases:
            _SensorCard(
              title: 'GPS / Ubicación',
              icon: Icons.location_on,
              color: Colors
                  .green, // Cambiamos de gris a verde para indicar que ya está activo
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const GpsScreen()),
                );
              },
            ),
            _SensorCard(
              title: 'Wi-Fi',
              icon: Icons.wifi,
              color: Colors.purple.shade200,
              onTap: () => {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const WifiScreen()),
                ),
              },
            ),

            _SensorCard(
              title: 'Bluetooth BLE',
              icon: Icons.bluetooth,
              color: Colors
                  .blue, // Cambiamos de gris a azul indicando que está activo
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const BluetoothScreen(),
                  ),
                );
              },
            ),

            _SensorCard(
              title: 'Micrófono / Audio',
              icon: Icons.mic,
              color: Colors
                  .red, // Cambiamos de gris a rojo indicando la activación del módulo
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const MicrophoneScreen(),
                  ),
                );
              },
            ),

            _SensorCard(
              title: 'Mapas Libres & GPS',
              icon: Icons.map,
              color: Colors
                  .brown, // Asignamos color púrpura para este nuevo laboratorio
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const MapScreen()),
                );
              },
            ),

            _SensorCard(
              title: 'Biometría (Huella/Rostro)',
              icon: Icons.fingerprint,
              color: Colors.indigo, // Color índigo representativo de seguridad
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const BiometricScreen(),
                  ),
                );
              },
            ),

            _SensorCard(
              title: 'PROYECTO INTEGRADOR: Ruta Segura',
              icon: Icons.local_shipping,
              color: Colors.green, // Destacado en verde de éxito comercial
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const TrackerScreen(),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showComingSoon(BuildContext context, String sensor) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'La práctica de $sensor se habilitará en la siguiente sesión.',
        ),
      ),
    );
  }
}

class _SensorCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const _SensorCard({
    required this.title,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Ink(
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.15),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color, width: 2),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 48, color: color),
            const SizedBox(height: 12),
            Text(
              title,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: color.withValues(alpha: 0.9),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
