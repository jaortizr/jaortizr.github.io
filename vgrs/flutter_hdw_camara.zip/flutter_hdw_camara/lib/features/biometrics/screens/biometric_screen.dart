import 'package:flutter/material.dart';
import 'package:local_auth/local_auth.dart';
import 'package:flutter/services.dart';

class BiometricScreen extends StatefulWidget {
  const BiometricScreen({super.key});

  @override
  State<BiometricScreen> createState() => _BiometricScreenState();
}

class _BiometricScreenState extends State<BiometricScreen> {
  // Controlador central de la API de Autenticación Local
  final LocalAuthentication _auth = LocalAuthentication();

  String _hardwareStatus = "Verificando sensores...";
  String _authStatus = "Estado: Esperando acción";
  bool _canCheckBiometrics = false;
  List<BiometricType> _availableBiometrics = [];

  @override
  void initState() {
    super.initState();
    _checkHardwareCapabilities();
  }

  // 1. Auditoría de Hardware: ¿Qué sensores tiene físicamente este teléfono?
  Future<void> _checkHardwareCapabilities() async {
    bool canCheckBiometrics = false;
    bool isDeviceSupported = false;
    List<BiometricType> availableBiometrics = [];

    try {
      // Evalúa si el chip del teléfono soporta biometría o tiene bloqueo de pantalla activo
      isDeviceSupported = await _auth.isDeviceSupported();
      // Evalúa si el sensor físico está disponible para usarse en este momento
      canCheckBiometrics = await _auth.canCheckBiometrics;

      if (canCheckBiometrics) {
        // Extrae la lista de tecnologías biométricas enroladas en el sistema operativo
        availableBiometrics = await _auth.getAvailableBiometrics();
      }
    } on PlatformException catch (e) {
      debugPrint("Error de plataforma al auditar hardware: $e");
    }

    if (!mounted) return;

    setState(() {
      _canCheckBiometrics = canCheckBiometrics && isDeviceSupported;
      _availableBiometrics = availableBiometrics;

      _hardwareStatus = _canCheckBiometrics
          ? "Sensores Disponibles: ${_parseBiometricsList()}"
          : "❌ Este dispositivo no cuenta con biometría activa.";
    });
  }

  String _parseBiometricsList() {
    if (_availableBiometrics.isEmpty) {
      return "Ninguno (Usa PIN/Patrón de respaldo)";
    }
    return _availableBiometrics
        .map((e) => e.toString().split('.').last.toUpperCase())
        .join(", ");
  }

  // 2. Disparar el flujo asíncrono de Autenticación Criptográfica
  Future<void> _authenticateUser() async {
    if (!_canCheckBiometrics) {
      setState(() {
        _authStatus = "Acción cancelada: Hardware no disponible.";
      });
      return;
    }

    setState(() {
      _authStatus = "Estado: Autenticando...";
    });

    try {
      // Lanzamos la interfaz nativa del Sistema Operativo (BiometricPrompt / FaceID)

      bool authenticated = await _auth.authenticate(
        localizedReason:
            'Escanea tu huella o rostro para validar el laboratorio',
      );

      setState(() {
        _authStatus = authenticated
            ? "🔒 ACCESO CONCEDIDO - Identidad Verificada"
            : "❌ ACCESO DENEGADO - Intento Fallido";
      });
    } on PlatformException catch (e) {
      setState(() {
        _authStatus = "Error de autenticación: ${e.message}";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sensor: Autenticación Biométrica')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Panel 1: Estado del Hardware del Dispositivo
            Card(
              elevation: 4,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    const Text(
                      'Auditoría de Capacidades Físicas',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      _hardwareStatus,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontFamily: 'monospace',
                        color: Colors.blueGrey,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 25),

            // Panel 2: Consola de Control de Seguridad
            Card(
              elevation: 4,
              color: _authStatus.contains("CONCEDIDO")
                  ? Colors.green.withValues(alpha: 0.05)
                  : Colors.red.withValues(alpha: 0.05),
              child: Padding(
                padding: const EdgeInsets.all(24.0),
                child: Column(
                  children: [
                    Icon(
                      _authStatus.contains("CONCEDIDO")
                          ? Icons.lock_open
                          : Icons.lock,
                      size: 64,
                      color: _authStatus.contains("CONCEDIDO")
                          ? Colors.green
                          : Colors.redAccent,
                    ),
                    const SizedBox(height: 16),
                    Text(
                      _authStatus,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 35),

            // Botón de acción central
            ElevatedButton.icon(
              onPressed: _canCheckBiometrics ? _authenticateUser : null,
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                backgroundColor: Colors.indigo,
                foregroundColor: Colors.white,
              ),
              icon: const Icon(Icons.fingerprint),
              label: const Text(
                'Disparar Validación Biométrica',
                style: TextStyle(fontSize: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
