import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'dart:async';

class BluetoothScreen extends StatefulWidget {
  const BluetoothScreen({super.key});

  @override
  State<BluetoothScreen> createState() => _BluetoothScreenState();
}

class _BluetoothScreenState extends State<BluetoothScreen> {
  List<ScanResult> _scanResults = [];
  bool _isScanning = false;

  // Suscripciones a los Streams globales de la librería
  StreamSubscription<List<ScanResult>>? _scanResultsSubscription;
  StreamSubscription<bool>? _isScanningSubscription;

  @override
  void initState() {
    super.initState();
    _initBluetoothListeners();
  }

  // 1. Inicializar la escucha reactiva del adaptador de hardware
  void _initBluetoothListeners() {
    // Escuchar los resultados que el escáner va encontrando en el aire en tiempo real
    _scanResultsSubscription = FlutterBluePlus.scanResults.listen((results) {
      setState(() {
        _scanResults = results;
      });
    });

    // Monitorear si el hardware sigue buscando o ya se detuvo el temporizador
    _isScanningSubscription = FlutterBluePlus.isScanning.listen((scanning) {
      setState(() {
        _isScanning = scanning;
      });
    });
  }

  // 2. Control del ciclo de Escaneo de Periféricos
  Future<void> _toggleScan() async {
    // Validar primero si el Bluetooth físico del teléfono está encendido
    if (await FlutterBluePlus.adapterState.first != BluetoothAdapterState.on) {
      _showSnackBar("Por favor, enciende el Bluetooth de tu dispositivo.");
      return;
    }

    try {
      if (_isScanning) {
        // Detener el hardware de forma manual
        await FlutterBluePlus.stopScan();
      } else {
        // Limpiar la lista previa antes de iniciar un nuevo ciclo
        setState(() {
          _scanResults.clear();
        });

        // Iniciar el escaneo con un timeout de 15 segundos para no agotar la batería
        // (En ingeniería móvil, nunca se deja un escaneo de radio corriendo indefinidamente)
        await FlutterBluePlus.startScan(timeout: const Duration(seconds: 15));
      }
    } catch (e) {
      _showSnackBar("Error al interactuar con el hardware: $e");
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  void dispose() {
    // CRUCIAL: Detener el escaneo si el usuario sale abruptamente de la pantalla
    if (_isScanning) {
      FlutterBluePlus.stopScan();
    }
    // Cancelar las suscripciones para evitar fugas de memoria críticas
    _scanResultsSubscription?.cancel();
    _isScanningSubscription?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sensor: Redes Bluetooth BLE')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Panel de Control del Escáner
            Card(
              elevation: 4,
              color: _isScanning
                  ? Colors.blue.withValues(alpha: 0.05)
                  : Colors.grey.withValues(alpha: 0.05),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Text(
                      _isScanning
                          ? '📡 Escaneando el Entorno...'
                          : 'Antena en Espera',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Busca paquetes de publicidad (Advertising) emitidos por dispositivos BLE cercanos.',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 12, color: Colors.grey),
                    ),
                    const SizedBox(height: 12),
                    ElevatedButton.icon(
                      onPressed: _toggleScan,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _isScanning
                            ? Colors.redAccent
                            : Colors.blueAccent,
                        foregroundColor: Colors.white,
                      ),
                      icon: Icon(
                        _isScanning
                            ? Icons.bluetooth_disabled
                            : Icons.bluetooth_searching,
                      ),
                      label: Text(
                        _isScanning
                            ? 'Detener Búsqueda'
                            : 'Iniciar Escaneo BLE',
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),

            const Text(
              'Dispositivos Detectados:',
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),

            // Lista Dinámica de Dispositivos Encontrados en el Aire
            Expanded(
              child: _scanResults.isEmpty
                  ? Center(
                      child: Text(
                        _isScanning
                            ? 'Buscando señales...'
                            : 'Lista vacía. Inicia un escaneo.',
                        style: const TextStyle(color: Colors.grey),
                      ),
                    )
                  : ListView.builder(
                      itemCount: _scanResults.length,
                      itemBuilder: (context, index) {
                        final result = _scanResults[index];
                        final deviceName =
                            result.advertisementData.advName.isNotEmpty
                            ? result.advertisementData.advName
                            : "Dispositivo no nombrado";

                        return Card(
                          margin: const EdgeInsets.symmetric(vertical: 4),
                          child: ListTile(
                            leading: Icon(
                              Icons.devices,
                              color: result.rssi > -70
                                  ? Colors.green
                                  : Colors.orange,
                            ),
                            title: Text(
                              deviceName,
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            subtitle: Text(
                              'ID: ${result.device.remoteId}\nRSSI: ${result.rssi} dBm',
                            ),
                            trailing: Text(
                              result.advertisementData.connectable
                                  ? "Conectable"
                                  : "Solo Adv",
                              style: TextStyle(
                                fontSize: 11,
                                color: result.advertisementData.connectable
                                    ? Colors.teal
                                    : Colors.grey,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
