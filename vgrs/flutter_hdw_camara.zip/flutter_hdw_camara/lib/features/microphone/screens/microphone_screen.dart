import 'package:flutter/material.dart';
import 'package:record/record.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';

class MicrophoneScreen extends StatefulWidget {
  const MicrophoneScreen({super.key});

  @override
  State<MicrophoneScreen> createState() => _MicrophoneScreenState();
}

class _MicrophoneScreenState extends State<MicrophoneScreen> {
  // El controlador principal del ciclo de vida del micrófono
  late final AudioRecorder _audioRecorder;

  bool _isRecording = false;
  String _statusText = "Micrófono listo para grabar";
  String? _lastRecordedPath;

  @override
  void initState() {
    super.initState();
    // Instanciamos el grabador al iniciar la pantalla
    _audioRecorder = AudioRecorder();
  }

  // 1. Control de flujo: Iniciar la captura de audio
  Future<void> _startRecording() async {
    try {
      if (await _audioRecorder.hasPermission()) {
        // CAMBIO AQUÍ: Usamos el almacenamiento externo del dispositivo
        final directory = await getExternalStorageDirectory();

        if (directory != null) {
          // Buscamos la ruta base quitando los subdirectorios privados de Android
          // para poder meterlo en la carpeta raíz de descargas
          String pathDestino =
              '${directory.path.split('/Android')[0]}/Download';

          // Creamos el archivo dentro de la carpeta Descargas (Download)
          final String filePath =
              '$pathDestino/Prueba_Audio_${DateTime.now().millisecondsSinceEpoch}.m4a';

          const RecordConfig config = RecordConfig(
            encoder: AudioEncoder.aacLc,
            bitRate: 128000,
            sampleRate: 44100,
          );

          await _audioRecorder.start(config, path: filePath);

          setState(() {
            _isRecording = true;
            _lastRecordedPath = filePath;
            _statusText = "🔴 GRABANDO EN CARPETA DOWNLOADS...";
          });
        }
      } else {
        setState(() {
          _statusText = "Permiso de micrófono denegado.";
        });
      }
    } catch (e) {
      setState(() {
        _statusText = "Error al inicializar el hardware: $e";
      });
    }
  }

  // 2. Control de flujo: Detener la captura de audio
  Future<void> _stopRecording() async {
    try {
      // Al detener, el paquete cierra el archivo y retorna la ruta exacta donde se guardó
      final path = await _audioRecorder.stop();

      setState(() {
        _isRecording = false;
        _statusText = "Audio guardado con éxito.";
      });

      if (path != null) {
        // Validamos el tamaño del archivo binario generado para comprobar que tiene datos
        final file = File(path);
        final int fileBytes = await file.length();
        final double fileKiloBytes = fileBytes / 1024;

        setState(() {
          _statusText =
              "✅ Grabación finalizada.\n"
              "Ruta: ...${path.substring(path.length - 30)}\n"
              "Tamaño: ${fileKiloBytes.toStringAsFixed(1)} KB";
        });
      }
    } catch (e) {
      setState(() {
        _statusText = "Error al detener la grabación: $e";
      });
    }
  }

  @override
  void dispose() {
    // CRUCIAL: Destruir la instancia del grabador al salir de la pantalla
    // Esto garantiza liberar el hardware y apagar el daemon de grabación del S.O.
    _audioRecorder.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sensor: Captura de Audio')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Consola de Estado del Hardware
            Card(
              elevation: 4,
              color: _isRecording
                  ? Colors.red.withValues(alpha: 0.05)
                  : Colors.blue.withValues(alpha: 0.05),
              child: Padding(
                padding: const EdgeInsets.all(24.0),
                child: Column(
                  children: [
                    Icon(
                      _isRecording ? Icons.mic : Icons.mic_none,
                      size: 64,
                      color: _isRecording ? Colors.red : Colors.blue,
                    ),
                    const SizedBox(height: 16),
                    Text(
                      _statusText,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontFamily: 'monospace',
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 40),

            // Controles de Acción Centralizados
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (!_isRecording)
                  FloatingActionButton.large(
                    onPressed: _startRecording,
                    backgroundColor: Colors.blueAccent,
                    foregroundColor: Colors.white,
                    child: const Icon(Icons.play_arrow),
                  ),
                if (_isRecording)
                  FloatingActionButton.large(
                    onPressed: _stopRecording,
                    backgroundColor: Colors.redAccent,
                    foregroundColor: Colors.white,
                    child: const Icon(Icons.stop),
                  ),
              ],
            ),
            const SizedBox(height: 20),
            const Text(
              'Nota: El archivo se almacena en el directorio temporal del sistema operativo, ideal para procesamiento y optimización de memoria.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 11, color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}
