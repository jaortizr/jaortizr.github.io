import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import 'package:local_auth/local_auth.dart';
import 'dart:async';

class TrackerScreen extends StatefulWidget {
  const TrackerScreen({super.key});

  @override
  State<TrackerScreen> createState() => _TrackerScreenState();
}

class _TrackerScreenState extends State<TrackerScreen> {
  // Inicializadores de controladores de Hardware
  final MapController _mapController = MapController();
  final LocalAuthentication _auth = LocalAuthentication();
  StreamSubscription<Position>? _gpsStreamSubscription;

  // Estados de la UI
  LatLng _currentPosition = const LatLng(19.4326, -99.1332); // CDMX por defecto
  bool _isGpsReady = false;
  bool _isPackageDelivered = false;
  String _statusMessage = "Enganchando satélites GPS...";

  @override
  void initState() {
    super.initState();
    _initIntegratorService();
  }

  // 1. Inicialización e interconexión de servicios de localización
  Future<void> _initIntegratorService() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      setState(() {
        _statusMessage = "Activa el interruptor de GPS en tu teléfono.";
      });
      return;
    }

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        setState(() {
          _statusMessage = "Permiso de ubicación denegado.";
        });
        return;
      }
    }

    try {
      // Capturar la posición actual inicial
      Position position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
        ),
      );

      setState(() {
        _currentPosition = LatLng(position.latitude, position.longitude);
        _isGpsReady = true;
        _statusMessage = "Ruta de entrega activa";
      });

      _mapController.move(_currentPosition, 16.0);
      _startLiveTracking();
    } catch (e) {
      setState(() {
        _statusMessage = "Error de enlace de hardware: $e";
      });
    }
  }

  // 2. Transmisión reactiva de coordenadas del GPS al Mapa
  void _startLiveTracking() {
    const LocationSettings settings = LocationSettings(
      accuracy: LocationAccuracy.high,
      distanceFilter: 2, // Actualiza la UI cada 2 metros de movimiento
    );

    _gpsStreamSubscription =
        Geolocator.getPositionStream(locationSettings: settings).listen((
          Position position,
        ) {
          if (!mounted) return;
          setState(() {
            _currentPosition = LatLng(position.latitude, position.longitude);
          });
          // Desplazamiento suave de la cámara del mapa persiguiendo al marcador
          _mapController.move(_currentPosition, _mapController.camera.zoom);
        });
  }

  // 3. Orquestador de Seguridad Biométrica para Cierre de Proceso
  Future<void> _confirmDeliveryBiometrically() async {
    // Comprobar primero si el dispositivo tiene capacidades biométricas activas
    bool canAuthenticate =
        await _auth.canCheckBiometrics || await _auth.isDeviceSupported();

    if (!canAuthenticate) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Código de respaldo: No hay sensores biométricos configurados.',
          ),
        ),
      );
      return;
    }

    try {
      // Disparar la validación nativa criptográfica
      bool authenticated = await _auth.authenticate(
        localizedReason:
            'Verifica tu identidad con tu huella o rostro para firmar la entrega.',
      );

      if (authenticated) {
        setState(() {
          _isPackageDelivered = true;
          _statusMessage = "Entrega Finalizada Exitosamente";
        });
        _gpsStreamSubscription
            ?.cancel(); // Apagar el GPS ya que la ruta concluyó
      }
    } on PlatformException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error de seguridad: ${e.message}')),
      );
    }
  }

  @override
  void dispose() {
    _gpsStreamSubscription?.cancel();
    _mapController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Proyecto Integrador: Logística Segura'),
      ),
      body: Stack(
        children: [
          // Capa de Fondo: Cartografía e hilos de renderizado de mapas
          FlutterMap(
            mapController: _mapController,
            options: MapOptions(
              initialCenter: _currentPosition,
              initialZoom: 15.0,
            ),
            children: [
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.example.mi_app_sensores',
              ),
              if (_isGpsReady)
                MarkerLayer(
                  markers: [
                    Marker(
                      point: _currentPosition,
                      width: 60,
                      height: 60,
                      alignment: Alignment.topCenter,
                      child: Icon(
                        Icons.local_shipping,
                        color: _isPackageDelivered
                            ? Colors.green
                            : Colors.blueAccent,
                        size: 45,
                      ),
                    ),
                  ],
                ),
            ],
          ),

          // Capa de Estado Superior: Indicador de Telemetría
          Positioned(
            top: 15,
            left: 15,
            right: 15,
            child: Card(
              color: Colors.white.withValues(alpha: 0.95),
              elevation: 6,
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  vertical: 12,
                  horizontal: 16,
                ),
                child: Row(
                  children: [
                    Icon(
                      _isPackageDelivered
                          ? Icons.check_circle
                          : Icons.radio_button_checked,
                      color: _isPackageDelivered ? Colors.green : Colors.red,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        _statusMessage,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Capa de Bloqueo Inicial (Mientras se engancha el satélite)
          if (!_isGpsReady)
            Container(
              color: Colors.white,
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const CircularProgressIndicator(color: Colors.blueAccent),
                    const SizedBox(height: 20),
                    Text(_statusMessage, style: const TextStyle(fontSize: 16)),
                  ],
                ),
              ),
            ),

          // Capa Inferior: Panel de Operaciones de Carga
          if (_isGpsReady)
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black26,
                      blurRadius: 10,
                      offset: Offset(0, -2),
                    ),
                  ],
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(20),
                    topRight: Radius.circular(20),
                  ),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      _isPackageDelivered
                          ? 'Paquete Entregado'
                          : 'Orden de Envío: #40921',
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      _isPackageDelivered
                          ? 'Token criptográfico guardado en hardware seguro.'
                          : 'Destino: Ubicación actual del operador (Validación de cercanía).',
                      style: const TextStyle(color: Colors.grey, fontSize: 13),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton.icon(
                      onPressed: _isPackageDelivered
                          ? null
                          : _confirmDeliveryBiometrically,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _isPackageDelivered
                            ? Colors.grey
                            : Colors.green,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 15),
                      ),
                      icon: Icon(
                        _isPackageDelivered
                            ? Icons.done_all
                            : Icons.fingerprint,
                      ),
                      label: Text(
                        _isPackageDelivered
                            ? 'ENTREGA CONCLUIDA'
                            : 'CONFIRMAR ENTREGA CON BIOMETRÍA',
                        style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
