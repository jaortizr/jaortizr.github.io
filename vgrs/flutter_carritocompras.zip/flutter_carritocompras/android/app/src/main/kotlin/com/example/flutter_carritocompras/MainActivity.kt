package com.example.flutter_carritocompras

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
