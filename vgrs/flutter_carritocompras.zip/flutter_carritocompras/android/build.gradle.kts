allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

val newBuildDir: Directory =
    rootProject.layout.buildDirectory
        .dir("../../build")
        .get()
rootProject.layout.buildDirectory.value(newBuildDir)

subprojects {
    val newSubprojectBuildDir: Directory = newBuildDir.dir(project.name)
    project.layout.buildDirectory.value(newSubprojectBuildDir)
}
subprojects {
    project.evaluationDependsOn(":app")
}
subprojects {
    val proyecto = this
    // Aplicamos la configuración a cada subproyecto (librería)
    proyecto.plugins.withType<com.android.build.gradle.api.AndroidBasePlugin> {
        proyecto.extensions.configure<com.android.build.gradle.BaseExtension> {
            if (proyecto.name == "isar_flutter_libs") {
                namespace = "dev.isar.isar_flutter_libs"
            }
            // Opcional: Si path_provider también falla, descomenta la siguiente línea:
            // if (proyecto.name == "path_provider_android") { namespace = "io.flutter.plugins.pathprovider" }
        }
    }
}

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}
