import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'services/db_service.dart';
import 'screens/tienda_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await DBService.init();
  runApp(const ProviderScope(child: CarritoApp()));
}

class CarritoApp extends StatelessWidget {
  const CarritoApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo), useMaterial3: true),
      home: const TiendaScreen(),
    );
  }
}

/*  https://inspect.isar.dev/3.1.0+1/#/64578/iOYtWdCyrjo  */