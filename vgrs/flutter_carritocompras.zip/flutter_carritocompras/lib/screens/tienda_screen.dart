import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/catalogo_provider.dart';
import '../providers/carrito_provider.dart';

class TiendaScreen extends ConsumerWidget {
  const TiendaScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final catalogoAsync = ref.watch(catalogoProvider);
    final carritoAsync = ref.watch(carritoProvider);
    final total = ref.watch(carritoTotalProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Ingeniería Store'),
        actions: [
          Center(child: Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Text('Total: \$${total.toStringAsFixed(2)}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ))
        ],
      ),
      body: Column(
        children: [
          _SectionTitle(title: 'Catálogo de Productos'),
          Expanded(
            flex: 2,
            child: catalogoAsync.when(
              data: (prods) => ListView.builder(
                itemCount: prods.length,
                itemBuilder: (_, i) => ListTile(
                  title: Text(prods[i].nombre),
                  subtitle: Text('\$${prods[i].precio}'),
                  trailing: IconButton(icon: const Icon(Icons.add_shopping_cart, color: Colors.green), 
                    onPressed: () => ref.read(carritoProvider.notifier).agregarProducto(prods[i])),
                ),
              ),
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (e, _) => Center(child: Text('Error: $e')),
            ),
          ),
          const Divider(),
          _CartHeader(onClear: () => ref.read(carritoProvider.notifier).vaciarCarrito()),
          Expanded(
            flex: 1,
            child: carritoAsync.when(
              data: (items) => items.isEmpty 
                ? const Center(child: Text('Carrito vacío'))
                : ListView.builder(
                    itemCount: items.length,
                    itemBuilder: (_, i) => ListTile(
                      leading: CircleAvatar(child: Text('${items[i].cantidad}')),
                      title: Text(items[i].producto.value?.nombre ?? '...'),
                      trailing: IconButton(icon: const Icon(Icons.delete, color: Colors.red), 
                        onPressed: () => ref.read(carritoProvider.notifier).eliminarItem(items[i].id)),
                    ),
                  ),
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (e, _) => const SizedBox(),
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  const _SectionTitle({required this.title});
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.all(8), child: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)));
}

class _CartHeader extends StatelessWidget {
  final VoidCallback onClear;
  const _CartHeader({required this.onClear});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 16),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        const Text('Tu Carrito', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        TextButton.icon(onPressed: onClear, icon: const Icon(Icons.delete_sweep, color: Colors.red), label: const Text('Vaciar', style: TextStyle(color: Colors.red)))
      ],
    ),
  );
}