// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'carrito_item.dart';

// **************************************************************************
// IsarCollectionGenerator
// **************************************************************************

// coverage:ignore-file
// ignore_for_file: duplicate_ignore, non_constant_identifier_names, constant_identifier_names, invalid_use_of_protected_member, unnecessary_cast, prefer_const_constructors, lines_longer_than_80_chars, require_trailing_commas, inference_failure_on_function_invocation, unnecessary_parenthesis, unnecessary_raw_strings, unnecessary_null_checks, join_return_with_assignment, prefer_final_locals, avoid_js_rounded_ints, avoid_positional_boolean_parameters, always_specify_types

extension GetCarritoItemCollection on Isar {
  IsarCollection<CarritoItem> get carritoItems => this.collection();
}

const CarritoItemSchema = CollectionSchema(
  name: r'CarritoItem',
  id: -5661705203540134179,
  properties: {
    r'cantidad': PropertySchema(
      id: 0,
      name: r'cantidad',
      type: IsarType.long,
    )
  },
  estimateSize: _carritoItemEstimateSize,
  serialize: _carritoItemSerialize,
  deserialize: _carritoItemDeserialize,
  deserializeProp: _carritoItemDeserializeProp,
  idName: r'id',
  indexes: {},
  links: {
    r'producto': LinkSchema(
      id: -1456538048230299387,
      name: r'producto',
      target: r'Producto',
      single: true,
    )
  },
  embeddedSchemas: {},
  getId: _carritoItemGetId,
  getLinks: _carritoItemGetLinks,
  attach: _carritoItemAttach,
  version: '3.1.0+1',
);

int _carritoItemEstimateSize(
  CarritoItem object,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  var bytesCount = offsets.last;
  return bytesCount;
}

void _carritoItemSerialize(
  CarritoItem object,
  IsarWriter writer,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  writer.writeLong(offsets[0], object.cantidad);
}

CarritoItem _carritoItemDeserialize(
  Id id,
  IsarReader reader,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  final object = CarritoItem();
  object.cantidad = reader.readLong(offsets[0]);
  object.id = id;
  return object;
}

P _carritoItemDeserializeProp<P>(
  IsarReader reader,
  int propertyId,
  int offset,
  Map<Type, List<int>> allOffsets,
) {
  switch (propertyId) {
    case 0:
      return (reader.readLong(offset)) as P;
    default:
      throw IsarError('Unknown property with id $propertyId');
  }
}

Id _carritoItemGetId(CarritoItem object) {
  return object.id;
}

List<IsarLinkBase<dynamic>> _carritoItemGetLinks(CarritoItem object) {
  return [object.producto];
}

void _carritoItemAttach(
    IsarCollection<dynamic> col, Id id, CarritoItem object) {
  object.id = id;
  object.producto.attach(col, col.isar.collection<Producto>(), r'producto', id);
}

extension CarritoItemQueryWhereSort
    on QueryBuilder<CarritoItem, CarritoItem, QWhere> {
  QueryBuilder<CarritoItem, CarritoItem, QAfterWhere> anyId() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(const IdWhereClause.any());
    });
  }
}

extension CarritoItemQueryWhere
    on QueryBuilder<CarritoItem, CarritoItem, QWhereClause> {
  QueryBuilder<CarritoItem, CarritoItem, QAfterWhereClause> idEqualTo(Id id) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IdWhereClause.between(
        lower: id,
        upper: id,
      ));
    });
  }

  QueryBuilder<CarritoItem, CarritoItem, QAfterWhereClause> idNotEqualTo(
      Id id) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(
              IdWhereClause.lessThan(upper: id, includeUpper: false),
            )
            .addWhereClause(
              IdWhereClause.greaterThan(lower: id, includeLower: false),
            );
      } else {
        return query
            .addWhereClause(
              IdWhereClause.greaterThan(lower: id, includeLower: false),
            )
            .addWhereClause(
              IdWhereClause.lessThan(upper: id, includeUpper: false),
            );
      }
    });
  }

  QueryBuilder<CarritoItem, CarritoItem, QAfterWhereClause> idGreaterThan(Id id,
      {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.greaterThan(lower: id, includeLower: include),
      );
    });
  }

  QueryBuilder<CarritoItem, CarritoItem, QAfterWhereClause> idLessThan(Id id,
      {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.lessThan(upper: id, includeUpper: include),
      );
    });
  }

  QueryBuilder<CarritoItem, CarritoItem, QAfterWhereClause> idBetween(
    Id lowerId,
    Id upperId, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IdWhereClause.between(
        lower: lowerId,
        includeLower: includeLower,
        upper: upperId,
        includeUpper: includeUpper,
      ));
    });
  }
}

extension CarritoItemQueryFilter
    on QueryBuilder<CarritoItem, CarritoItem, QFilterCondition> {
  QueryBuilder<CarritoItem, CarritoItem, QAfterFilterCondition> cantidadEqualTo(
      int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'cantidad',
        value: value,
      ));
    });
  }

  QueryBuilder<CarritoItem, CarritoItem, QAfterFilterCondition>
      cantidadGreaterThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'cantidad',
        value: value,
      ));
    });
  }

  QueryBuilder<CarritoItem, CarritoItem, QAfterFilterCondition>
      cantidadLessThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'cantidad',
        value: value,
      ));
    });
  }

  QueryBuilder<CarritoItem, CarritoItem, QAfterFilterCondition> cantidadBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'cantidad',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<CarritoItem, CarritoItem, QAfterFilterCondition> idEqualTo(
      Id value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<CarritoItem, CarritoItem, QAfterFilterCondition> idGreaterThan(
    Id value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<CarritoItem, CarritoItem, QAfterFilterCondition> idLessThan(
    Id value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<CarritoItem, CarritoItem, QAfterFilterCondition> idBetween(
    Id lower,
    Id upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'id',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }
}

extension CarritoItemQueryObject
    on QueryBuilder<CarritoItem, CarritoItem, QFilterCondition> {}

extension CarritoItemQueryLinks
    on QueryBuilder<CarritoItem, CarritoItem, QFilterCondition> {
  QueryBuilder<CarritoItem, CarritoItem, QAfterFilterCondition> producto(
      FilterQuery<Producto> q) {
    return QueryBuilder.apply(this, (query) {
      return query.link(q, r'producto');
    });
  }

  QueryBuilder<CarritoItem, CarritoItem, QAfterFilterCondition>
      productoIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.linkLength(r'producto', 0, true, 0, true);
    });
  }
}

extension CarritoItemQuerySortBy
    on QueryBuilder<CarritoItem, CarritoItem, QSortBy> {
  QueryBuilder<CarritoItem, CarritoItem, QAfterSortBy> sortByCantidad() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'cantidad', Sort.asc);
    });
  }

  QueryBuilder<CarritoItem, CarritoItem, QAfterSortBy> sortByCantidadDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'cantidad', Sort.desc);
    });
  }
}

extension CarritoItemQuerySortThenBy
    on QueryBuilder<CarritoItem, CarritoItem, QSortThenBy> {
  QueryBuilder<CarritoItem, CarritoItem, QAfterSortBy> thenByCantidad() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'cantidad', Sort.asc);
    });
  }

  QueryBuilder<CarritoItem, CarritoItem, QAfterSortBy> thenByCantidadDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'cantidad', Sort.desc);
    });
  }

  QueryBuilder<CarritoItem, CarritoItem, QAfterSortBy> thenById() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'id', Sort.asc);
    });
  }

  QueryBuilder<CarritoItem, CarritoItem, QAfterSortBy> thenByIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'id', Sort.desc);
    });
  }
}

extension CarritoItemQueryWhereDistinct
    on QueryBuilder<CarritoItem, CarritoItem, QDistinct> {
  QueryBuilder<CarritoItem, CarritoItem, QDistinct> distinctByCantidad() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'cantidad');
    });
  }
}

extension CarritoItemQueryProperty
    on QueryBuilder<CarritoItem, CarritoItem, QQueryProperty> {
  QueryBuilder<CarritoItem, int, QQueryOperations> idProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'id');
    });
  }

  QueryBuilder<CarritoItem, int, QQueryOperations> cantidadProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'cantidad');
    });
  }
}
