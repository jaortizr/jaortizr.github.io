import 'package:isar/isar.dart';
part 'producto.g.dart';

@collection
class Producto {
  Id id = Isar.autoIncrement;
  @Index(unique: true)
  late String nombre;
  late double precio;
  late String categoria;
}