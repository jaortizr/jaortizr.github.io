import 'package:isar/isar.dart';
import 'producto.dart';
part 'carrito_item.g.dart';

@collection
class CarritoItem {
  Id id = Isar.autoIncrement;
  final producto = IsarLink<Producto>();
  late int cantidad;
}