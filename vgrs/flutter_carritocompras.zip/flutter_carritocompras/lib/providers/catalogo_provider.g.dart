// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'catalogo_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$catalogoHash() => r'bd39979b05565e88f4348ea78c4ecfda399c5bff';

/// See also [Catalogo].
@ProviderFor(Catalogo)
final catalogoProvider =
    AutoDisposeAsyncNotifierProvider<Catalogo, List<Producto>>.internal(
  Catalogo.new,
  name: r'catalogoProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$catalogoHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$Catalogo = AutoDisposeAsyncNotifier<List<Producto>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
