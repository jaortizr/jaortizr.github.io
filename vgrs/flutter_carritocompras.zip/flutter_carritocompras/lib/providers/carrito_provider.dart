import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:isar/isar.dart';
import '../models/producto.dart';
import '../models/carrito_item.dart';
import '../services/db_service.dart';

part 'carrito_provider.g.dart';

@riverpod
class Carrito extends _$Carrito {
  @override
  Future<List<CarritoItem>> build() async {
    final items = await DBService.isar.carritoItems.where().findAll();
    for (var item in items) {
      await item.producto.load();
    }
    return items;
  }

  Future<void> agregarProducto(Producto producto) async {
    await DBService.isar.writeTxn(() async {
      final existente = await DBService.isar.carritoItems
          .filter()
          .producto((q) => q.idEqualTo(producto.id))
          .findFirst();

      if (existente != null) {
        existente.cantidad++;
        await DBService.isar.carritoItems.put(existente);
      } else {
        final nuevoItem = CarritoItem()..cantidad = 1;
        nuevoItem.producto.value = producto;
        await DBService.isar.carritoItems.put(nuevoItem);
        await nuevoItem.producto.save();
      }
    });
    ref.invalidateSelf();
  }

  Future<void> eliminarItem(int id) async {
    await DBService.isar.writeTxn(
      () async => await DBService.isar.carritoItems.delete(id),
    );
    ref.invalidateSelf();
  }

  Future<void> vaciarCarrito() async {
    await DBService.isar.writeTxn(
      () async => await DBService.isar.carritoItems.clear(),
    );
    ref.invalidateSelf();
  }
}

@riverpod
double carritoTotal(Ref ref) {
  final carritoAsync = ref.watch(carritoProvider);
  return carritoAsync.maybeWhen(
    data: (items) => items.fold(
      0,
      (sum, item) => sum + (item.producto.value!.precio * item.cantidad),
    ),
    orElse: () => 0.0,
  );
}
