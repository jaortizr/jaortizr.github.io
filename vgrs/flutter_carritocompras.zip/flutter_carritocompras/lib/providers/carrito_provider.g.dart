// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'carrito_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$carritoTotalHash() => r'4acb4f1494efc16c10b5594a14b29bdb4dc7c42f';

/// See also [carritoTotal].
@ProviderFor(carritoTotal)
final carritoTotalProvider = AutoDisposeProvider<double>.internal(
  carritoTotal,
  name: r'carritoTotalProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$carritoTotalHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef CarritoTotalRef = AutoDisposeProviderRef<double>;
String _$carritoHash() => r'58241fb23c714caec10f0de4e5272e04987fa985';

/// See also [Carrito].
@ProviderFor(Carrito)
final carritoProvider =
    AutoDisposeAsyncNotifierProvider<Carrito, List<CarritoItem>>.internal(
  Carrito.new,
  name: r'carritoProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$carritoHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$Carrito = AutoDisposeAsyncNotifier<List<CarritoItem>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
