import 'package:riverpod_annotation/riverpod_annotation.dart';
import '../models/producto.dart';
import '../services/db_service.dart';
import 'package:isar/isar.dart';

part 'catalogo_provider.g.dart';

@riverpod
class Catalogo extends _$Catalogo {
  @override
  Future<List<Producto>> build() async => await DBService.isar.productos.where().findAll();
}