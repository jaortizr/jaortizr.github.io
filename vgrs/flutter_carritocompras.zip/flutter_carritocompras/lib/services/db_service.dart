import 'package:isar/isar.dart';
import 'package:path_provider/path_provider.dart';
import '../models/producto.dart';
import '../models/carrito_item.dart';

class DBService {
  static late Isar isar;

  static Future<void> init() async {
    final dir = await getApplicationDocumentsDirectory();
    isar = await Isar.open([
      ProductoSchema,
      CarritoItemSchema,
    ], directory: dir.path);
    await _seedDatabase();
  }

  static Future<void> _seedDatabase() async {
    final count = await isar.productos.count();
    if (count > 0) return;

    final catalogo = [
      Producto()
        ..nombre = 'Monitor 4K'
        ..precio = 350.0
        ..categoria = 'Hardware',
      Producto()
        ..nombre = 'Teclado Mecánico'
        ..precio = 85.0
        ..categoria = 'Periféricos',
      Producto()
        ..nombre = 'Mouse Gamer'
        ..precio = 45.0
        ..categoria = 'Periféricos',
      Producto()
        ..nombre = 'Laptop i7'
        ..precio = 1200.0
        ..categoria = 'Equipos',
      Producto()
        ..nombre = 'Impresora'
        ..precio = 900.0
        ..categoria = 'Equipos',
      Producto()
        ..nombre = 'Papel 100 hojas'
        ..precio = 50.0
        ..categoria = 'Consumibles',
    ];

    await isar.writeTxn(() async => await isar.productos.putAll(catalogo));
  }
}
