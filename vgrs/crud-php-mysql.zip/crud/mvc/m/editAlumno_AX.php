<?php
  include("./../db.php");

  extract($_REQUEST);

  $respAX = [];

  $sql_EditAlumno = "UPDATE alumno SET nombre = ?, apellidos = ?, correo = ?, auditoria = now() WHERE boleta = ?";
  $stmt_EditAlumno = $conn -> prepare($sql_EditAlumno);
  $stmt_EditAlumno -> bind_param("ssss", $nombre, $apellidos, $correo, $boleta);
  $stmt_EditAlumno -> execute();
  if($stmt_EditAlumno -> affected_rows > 0){
    $respAX["cod"] = 1;
    $respAX["msj"] = "Se actualizó el registro solicitado";
    $respAX["icono"] = "success";
    $respAX["data"] = "";
  }else{
    $respAX["cod"] = 0;
    $respAX["msj"] = "Error. Favor de intentarlo nuevamente.";
    $respAX["icono"] = "error";
    $respAX["data"] = "";
  }

  $stmt_EditAlumno -> close();
  $conn -> close();
  echo json_encode($respAX);

?>