<?php
  include("./../db.php");

  extract($_REQUEST);
  $contrasena = md5($contrasena);
  $respAX = [];

  $sqlAddAlumno = "INSERT INTO alumno VALUES(?,?,?,?,?,now())";
  $stmt_addAlumno = $conn -> prepare($sqlAddAlumno);
  $stmt_addAlumno -> bind_param("sssss", $boleta, $nombre, $apellidos, $correo, $contrasena);
  $stmt_addAlumno -> execute();
  $res_addAlumno = $stmt_addAlumno -> get_result();

  if($stmt_addAlumno -> affected_rows == 1){
    $respAX["cod"] = 1;
    $respAX["msj"] = "Alumno agregado";
    $respAX["icono"] = "success";
    $respAX["data"] = "";
  }else{
    http_response_code(500);
    $respuesta["cod"] =  0;
    $respuesta["msj"] = "Error: $stmt_addAlumno -> error";
    $respAX["icono"] = "error";
    $respAX["data"] = "";
  }

  $stmt_addAlumno -> close();
  $conn -> close();
  
  echo json_encode($respAX);
?>