<?php
  include("./../db.php");

  extract($_REQUEST);

  $respAX = [];

  $sql_GetAlumno = "SELECT * FROM alumno WHERE boleta = ?";
  $stmt_GetAlumno = $conn -> prepare($sql_GetAlumno);
  $stmt_GetAlumno -> bind_param("s", $boleta);
  $stmt_GetAlumno -> execute();
  $res_GetAlumno = $stmt_GetAlumno -> get_result();
  if($res_GetAlumno -> num_rows == 1){
    $respAX["cod"] = 1;
    $respAX["msj"] = "Bienvenido :)";
    $respAX["icono"] = "success";
    $respAX["data"] = $res_GetAlumno -> fetch_assoc();
  }else{
    $respAX["cod"] = 0;
    $respAX["msj"] = "No hay alumnos registrados";
    $respAX["icono"] = "error";
    $respAX["data"] = "";
  }

  $stmt_GetAlumno -> close();
  $conn -> close();
  echo json_encode($respAX);

?>