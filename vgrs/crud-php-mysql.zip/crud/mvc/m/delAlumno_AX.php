<?php
  include("./../db.php");

  extract($_REQUEST);
  $respAX = [];

  $sqlDelAlumno = "DELETE FROM alumno WHERE boleta = ?";
  $stmt = $conn -> prepare($sqlDelAlumno);
  $stmt -> bind_param("s", $boleta);

  if($stmt -> execute()){
    if($stmt -> affected_rows > 0){
      $respAX["cod"] = 1;
      $respAX["msj"] = "El registro del alumno se ha eliminado";
      $respAX["icono"] = "success";
      $respAX["data"] = "";
    }else{
      http_response_code(500);
      $respAX["cod"] = 0;
      $respAX["msj"] = "Error: $stmt -> error";
      $respAX["icono"] = "error";
      $respAX["data"] = "";
    }
  }

  $stmt -> close();
  $conn -> close();
  echo json_encode($respAX);
?>