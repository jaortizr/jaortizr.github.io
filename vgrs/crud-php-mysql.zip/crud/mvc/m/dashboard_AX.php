<?php
  include("./../db.php");

  $respAX = [];

  $sqlDashSelUsuarios = "SELECT * FROM alumno";
  $resDashSelUsuarios = $conn -> query($sqlDashSelUsuarios);
  if($resDashSelUsuarios -> num_rows > 0){
    $respAX["cod"] = 1;
    $respAX["msj"] = "Alumnos registrados";
    $respAX["icono"] = "success";
    $respAX["data"] = $resDashSelUsuarios -> fetch_all(MYSQLI_ASSOC);
  }else{
    $respAX["cod"] = 0;
    $respAX["msj"] = "No hay alumnos registrados.";
    $respAX["icono"] = "error";
    $respAX["data"] = "";
  }

  $conn -> close();
  echo json_encode($respAX);
?>