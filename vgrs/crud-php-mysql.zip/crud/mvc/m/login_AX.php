<?php
  session_start();
  include("./../db.php");

  extract($_REQUEST);

  $contrasena = md5($contrasena);
  $respAX = [];

  $sql_login = "SELECT usuario, correo, nombre, apellidos FROM administracion WHERE usuario = ? AND contrasena = ? AND activo = 1";
  $stmt_login = $conn -> prepare($sql_login);
  $stmt_login -> bind_param("ss", $usuario, $contrasena);
  $stmt_login -> execute();
  $res_login = $stmt_login -> get_result();
  if($res_login -> num_rows == 1){
    $respAX["cod"] = 1;
    $respAX["msj"] = "Bienvenido :)";
    $respAX["icono"] = "success";
    $respAX["data"] = $res_login -> fetch_assoc();
    $_SESSION["admin"] = $usuario;
  }else{
    $respAX["cod"] = 0;
    $respAX["msj"] = $usuario;
    $respAX["icono"] = "error";
    $respAX["data"] = "";
  }

  $stmt_login -> close();
  $conn -> close();
  echo json_encode($respAX);

?>