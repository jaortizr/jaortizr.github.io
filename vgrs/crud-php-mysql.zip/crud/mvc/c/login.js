$(document).ready(() => {

  const validarFormLogin = new JustValidate("#formLogin", {
    errorFieldCssClass: "is-invalid",
    successFieldCssClass: "is-valid"
  });

  validarFormLogin
    .addField("#usuario", [
      {
        rule: "required",
        errorMessage: "Falta el usuario"
      }
    ])
    .addField("#contrasena", [
      {
        rule: "required",
        errorMessage: "Falta la contraseña"
      }
    ])
    .onSuccess((e) => {
      $.ajax({
        url: "./../m/login_AX.php",
        type: "POST",
        data: $("#formLogin").serialize(),
        cache: "false",
        success: (respAX) => {
          Swal.fire({
            title: "TDAW 20262",
            text: respAX.msj,
            icon: respAX.icono,
            didDestroy: () => {
              respAX.cod ? window.location.href = "./dashboard.php" : window.location.reload();
            }
          });
        }
      });
    });

});