$(document).ready(() => {
  const parametrosURL = new URLSearchParams(window.location.search);
  let boletEditar = parametrosURL.get("boleta");

  $.ajax({
    url: "./../m/editAlumno_BD.php",
    type: "POST",
    data: { boleta: boletEditar },
    cache: false,
    success: (respAX) => {
      $("#nombre").val(respAX.data.nombre);
      $("#apellidos").val(respAX.data.apellidos);
      $("#correo").val(respAX.data.correo);
    }
  });




  const validarFormEditAlumno = new JustValidate("#formEditAlumno", {
    errorFieldCssClass: "is-invalid",
    successFieldCssClass: "is-valid"
  });

  validarFormEditAlumno
    .addField("#boleta", [
      {
        rule: "required",
        errorMessage: "Falta boleta"
      }
    ])
    .addField("#nombre", [
      {
        rule: "required",
        errorMessage: "Falta nombre"
      }
    ])
    .addField("#apellidos", [
      {
        rule: "required",
        errorMessage: "Faltan apellidos"
      }
    ])
    .addField("#correo", [
      {
        rule: "required",
        errorMessage: "Falta correo"
      }
    ])
    .onSuccess((e) => {
      $.ajax({
        url: "./../m/editAlumno_AX.php",
        type: "POST",
        data: $("#formEditAlumno").serialize(),
        cache: "false",
        success: (respAX) => {
          console.info()
          Swal.fire({
            title: "TDAW 20262",
            text: respAX.msj,
            icon: respAX.icono,
            didDestroy: () => {
              respAX.cod ? window.location.href = "./dashboard.php" : window.location.reload();
            }
          });
        }
      });
    });

});