$(document).ready(() => {

  const validarFormAddAlumno = new JustValidate("#formAddAlumno", {
    errorFieldCssClass: "is-invalid",
    successFieldCssClass: "is-valid"
  });

  validarFormAddAlumno
    .addField("#boleta", [
      {
        rule: "required",
        errorMessage: "Falta boleta"
      }
    ])
    .addField("#nombre", [
      {
        rule: "required",
        errorMessage: "Falta nombre"
      }
    ])
    .addField("#apellidos", [
      {
        rule: "required",
        errorMessage: "Faltan apellidos"
      }
    ])
    .addField("#correo", [
      {
        rule: "required",
        errorMessage: "Falta correo"
      }
    ])
    .addField("#contrasena", [
      {
        rule: "required",
        errorMessage: "Falta contraseña"
      }
    ])
    .onSuccess((e) => {
      $.ajax({
        url: "./../m/addAlumno_AX.php",
        type: "POST",
        data: $("#formAddAlumno").serialize(),
        cache: "false",
        success: (respAX) => {
          Swal.fire({
            title: "TDAW 20262",
            text: respAX.msj,
            icon: respAX.icono,
            didDestroy: () => {
              respAX.cod ? window.location.href = "./dashboard.php" : window.location.reload();
            }
          });
        }
      });
    });

});