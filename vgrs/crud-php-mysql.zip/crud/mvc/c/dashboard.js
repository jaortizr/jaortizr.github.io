$(document).ready(() => {
  $.ajax({
    url: "./../m/dashboard_AX.php",
    type: "GET",
    cache: false,
    success: (respAX) => {
      let alumnos = Array.from(respAX.data);
      let trsAlumnos = "";
      alumnos.forEach((item, indice) => {
        trsAlumnos += `
        <tr>
          <td>${item.boleta}</td>
          <td>${item.nombre}</td>
          <td>${item.apellidos}</td>
          <td>${item.correo}</td>
          <td>
            <i class="fa-solid fa-trash delAlumno" data-boleta="${item.boleta}"></i>
            &nbsp;&nbsp;&nbsp;
            <i class="fa-solid fa-pen-to-square editAlumno" data-boleta="${item.boleta}"></i>
          </td>
        </tr>
        `;
      });
      $("#trsAlumnos").html(trsAlumnos);
    }
  });

  $("#trsAlumnos").on("click", ".delAlumno", function () {
    let boleta = $(this).attr("data-boleta");

    Swal.fire({
      title: "TDAW - 20262",
      text: `¿Está seguro de eliminar la boleta ${boleta}?`,
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Sí",
      cancelButtonText: "No"
    }).then((result) => {
      if (result.isConfirmed) {
        $.ajax({
          url: "./../m/delAlumno_AX.php",
          type: "POST",
          data: { boleta: boleta },
          cache: false,
          success: (respAX) => {
            Swal.fire({
              title: "TDAW 20262",
              text: respAX.msj,
              icon: respAX.icono,
              didDestroy: () => {
                window.location.reload();
              }
            });
          }
        });
      }
    });

  });

  $("#trsAlumnos").on("click", ".editAlumno", function () {
    let boleta = $(this).attr("data-boleta");

    window.location.href = "./editAlumno.php?boleta=" + boleta;


  });



}); /* /document.ready */