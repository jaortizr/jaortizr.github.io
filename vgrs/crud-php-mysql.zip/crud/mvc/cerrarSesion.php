<?php
  session_start();
  extract($_REQUEST);

  unset($_SESSION[$nombreSesion]);
  header("location: /crud");
?>