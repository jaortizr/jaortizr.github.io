<?php
  session_start();
  if(isset($_SESSION["admin"])){
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Agregar Alumno</title>
  <link href="./../../js/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="./../../js/vendor/jquery/jquery-4.0.min.js"></script>
  <script src="./../../js/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="./../../js/libs/JustValidate/justValidate.min.js"></script>
  <script src="./../../js/libs/SweetAlert/sweetalert2.all.min.js"></script>
  <script src="./../c/addAlumno.js"></script>
</head>

<body>
  <header></header>
  <main>
    <div class="container">
      <div class="row">
        <h1>Agregar Alumno</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio maxime eius, libero distinctio commodi pariatur reprehenderit exercitationem corporis voluptas hic minima perferendis. Vero veritatis unde error nulla ipsum ipsam libero.</p>
      </div>
      <form class="row" id="formAddAlumno" autocomplete="off">
        <div class="col-xs-12 col-md-6 mb-3">
          <label for="boleta" class="form-label">Boleta</label>
          <input type="text" class="form-control" id="boleta" name="boleta">
        </div>
        <div class="col-xs-12 col-md-6 mb-3">
          <label for="nombre" class="form-label">Nombre</label>
          <input type="text" class="form-control" id="nombre" name="nombre">
        </div>
        <div class="col-xs-12 col-md-6 mb-3">
          <label for="apellidos" class="form-label">Apellidos</label>
          <input type="text" class="form-control" id="apellidos" name="apellidos">
        </div>
        <div class="col-xs-12 col-md-6 mb-3">
          <label for="correo" class="form-label">Correo</label>
          <input type="text" class="form-control" id="correo" name="correo">
        </div>
        <div class="col-xs-12 col-md-6 mb-3">
          <label for="contrasena" class="form-label">Contraseña</label>
          <input type="password" class="form-control" id="contrasena" name="contrasena">
        </div>
        <div class="row">
          <div class="col-xs-12 col-md-6 d-grid">
            <a href="./dashboard.php" class="btn btn-warning">Cancelar</a>
          </div>
          <div class="col-xs-12 col-md-6 d-grid">
            <button type="submit" class="btn btn-primary">Agregar</button>
          </div>
        </div>
      </form>
    </div>
  </main>
  <footer></footer>
</body>

</html>
<?php
  }else{
    header("location: /crud");
  }
?>
