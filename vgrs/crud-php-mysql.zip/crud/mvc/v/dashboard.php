<?php
  session_start();
  if(isset($_SESSION["admin"])){

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Editar Alumno - TDAW 20262</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css">
  <link href="/crud/js/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="/crud/js/vendor/jquery/jquery-4.0.min.js"></script>
  <script src="/crud/js/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="/crud/js/libs/SweetAlert/sweetalert2.all.min.js"></script>
  <script src="./../c/dashboard.js"></script>
  <style>
    .delAlumno, .editAlumno{
      cursor:pointer;
    }
  </style>
</head>
<body>
  <header></header>
  <main>
    <div class="container">
      <div class="row mb-3">
        <h1>Dashboard</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptas odit dolorem in. Consequatur maiores beatae hic ut doloribus facere, libero odio nam harum delectus laudantium dolore modi laboriosam itaque voluptatem?</p>
      </div>
      <div class="row mb-3">
        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th>Boleta</th><th>Nombre</th><th>Apellidos</th><th>Correo</th><th>Opciones</th>
              </tr>
            </thead>
            <tbody id="trsAlumnos">

            </tbody>
          <table>
        </div>
      </div>
      <div class="row mb-3">
        <a href="./addAlumno.php">Agregar Alumno</a>
        <br>
        <a href="./../cerrarSesion.php?nombreSesion=admin">Cerrar Sesión <i class="fa-solid fa-right-from-bracket"></i></a>

      </div>
    </div>
  </main>
  <footer></footer>
</body>
</html>
<?php
  }else{
    header("location: /crud");
  }
?>