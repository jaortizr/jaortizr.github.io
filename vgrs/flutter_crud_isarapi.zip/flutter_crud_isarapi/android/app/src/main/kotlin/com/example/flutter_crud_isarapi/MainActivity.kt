package com.example.flutter_crud_isarapi

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
