allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

val newBuildDir: Directory =
    rootProject.layout.buildDirectory
        .dir("../../build")
        .get()
rootProject.layout.buildDirectory.value(newBuildDir)

subprojects {
    val newSubprojectBuildDir: Directory = newBuildDir.dir(project.name)
    project.layout.buildDirectory.value(newSubprojectBuildDir)
}
subprojects {
    project.evaluationDependsOn(":app")
}
// --- BLOQUE DE COMPATIBILIDAD PARA LIBRERÍAS ANTIGUAS ---
subprojects {
    val proyecto = this
    proyecto.plugins.withType<com.android.build.gradle.api.AndroidBasePlugin> {
        proyecto.extensions.configure<com.android.build.gradle.BaseExtension> {
            // Mapeo de librerías conflictivas y su namespace requerido
            val bibliotecasConError = mapOf(
                "isar_flutter_libs" to "dev.isar.isar_flutter_libs",
                "path_provider_android" to "io.flutter.plugins.pathprovider",
                "shared_preferences_android" to "io.flutter.plugins.sharedpreferences"
            )
            
            if (bibliotecasConError.containsKey(proyecto.name)) {
                namespace = bibliotecasConError[proyecto.name]
            }
        }
    }
}
// -------------------------------------------------------

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}
