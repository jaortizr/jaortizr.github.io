import 'package:flutter_crud_isarapi/infrastructure/datasources/isar_datasource.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import '../../domain/models/app_user.dart';
import '../../infrastructure/repositories/user_repository_impl.dart';

part 'user_provider.g.dart';

@riverpod
class UserNotifier extends _$UserNotifier {
  final _repo = UserRepositoryImpl();

  @override
  Future<List<AppUser>> build() async => await _repo.getAndSyncUsers();

  Future<void> createUser(String name, String email) async {
    final newUser = AppUser()
      ..name = name
      ..email = email
      ..avatar = 'https://reqres.in/img/faces/7-image.jpg';

    await _repo.saveLocal(newUser);
    final total = await (await IsarDatasource.openDB()).appUsers.count();
    print("Total de usuarios en base de datos: $total");
    ref.invalidateSelf();

  }
}
