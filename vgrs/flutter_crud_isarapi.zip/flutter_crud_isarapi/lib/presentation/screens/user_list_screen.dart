import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/user_provider.dart';

class UserListScreen extends ConsumerWidget {
  const UserListScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final usersAsync = ref.watch(userNotifierProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('DAMN: 20262')),
      body: usersAsync.when(
        data: (users) => ListView.builder(
          itemCount: users.length,
          itemBuilder: (context, i) => ListTile(
            leading: CircleAvatar(
              backgroundImage: NetworkImage(users[i].avatar),
            ),
            title: Text(users[i].name),
            subtitle: Text(users[i].email),
          ),
        ),
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) =>
            Center(child: Text('Modo Offline: Datos locales cargados.')),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          ref
              .read(userNotifierProvider.notifier)
              .createUser('Diana Cazadora', 'diana@diana.com');
        },
        child: const Icon(Icons.person_add),
      ),
    );
  }
}
