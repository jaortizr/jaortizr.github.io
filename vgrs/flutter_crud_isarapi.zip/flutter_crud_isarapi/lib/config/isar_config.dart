import 'package:isar/isar.dart';
import 'package:path_provider/path_provider.dart';
import '../domain/models/app_user.dart';

class IsarConfig {
  static Future<Isar> openDB() async {
    if (Isar.instanceNames.isNotEmpty) return Isar.getInstance()!;
    final dir = await getApplicationDocumentsDirectory();
    return await Isar.open([AppUserSchema], directory: dir.path);
  }
}