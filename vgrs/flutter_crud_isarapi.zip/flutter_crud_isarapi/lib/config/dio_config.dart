import 'package:dio/dio.dart';

class DioConfig {
  static Dio get dio => Dio(
    BaseOptions(
      baseUrl: 'https://reqres.in/api',
      headers: {
        'x-api-key': 'free_user_3DYrMZb3OFdbENDI1tUVBpGvaAa',
        'Content-Type': 'application/json',
      },
    ),
  );
}