import '../../domain/models/app_user.dart';
import '../datasources/isar_datasource.dart';
import '../datasources/remote_user_datasource.dart';
import 'package:isar/isar.dart';

class UserRepositoryImpl {
  final _remote = RemoteUserDatasource();

  Future<List<AppUser>> getAndSyncUsers() async {
    final isar = await IsarDatasource.openDB();

    try {
      // 1. Obtenemos datos de la API (Nube)
      final remoteUsers = await _remote.fetchRemoteUsers();

      // 2. Los guardamos en Isar sin borrar lo que ya existe
      await isar.writeTxn(() async {
        // Usamos putAll. Si el serverId ya existe, se actualiza.
        // Si no existe, se inserta. Los locales creados a mano NO se tocan.
        await isar.appUsers.putAll(remoteUsers);
      });
    } catch (e) {
      print("Modo Offline: No se pudo sincronizar con ReqRes");
    }

    // 3. ¡ESTA ES LA CLAVE!
    // No retornamos 'remoteUsers'. Retornamos Todo lo que hay en Isar.
    return await isar.appUsers.where().findAll();
  }

  Future<void> saveLocal(AppUser user) async {
    final isar = await IsarDatasource.openDB();
    await isar.writeTxn(() => isar.appUsers.put(user));
  }
}
