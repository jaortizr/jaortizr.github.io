import '../../config/dio_config.dart';
import '../../domain/models/app_user.dart';

class RemoteUserDatasource {
  final _dio = DioConfig.dio;

  Future<List<AppUser>> fetchRemoteUsers() async {
    final response = await _dio.get('/users');
    final List data = response.data['data'];
    return data.map((json) => AppUser.fromJson(json)).toList();
  }
}