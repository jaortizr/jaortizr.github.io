import '../../config/isar_config.dart';
import 'package:isar/isar.dart';

class IsarDatasource {
  static Future<Isar> openDB() => IsarConfig.openDB();
}
