import 'package:isar/isar.dart';
import 'package:json_annotation/json_annotation.dart';

part 'app_user.g.dart';

@collection
@JsonSerializable()
class AppUser {
  
  @JsonKey(includeFromJson: false, includeToJson: false)
  Id id = Isar.autoIncrement; 
  @Index(unique: true, replace: true)

  @JsonKey(name: 'id')
  int? serverId; 

  @JsonKey(name: 'first_name')
  late String name;
  late String email;
  late String avatar;

  AppUser();

  factory AppUser.fromJson(Map<String, dynamic> json) => _$AppUserFromJson(json);
  Map<String, dynamic> toJson() => _$AppUserToJson(this);
}