<?php

  $contrasena = $_REQUEST["contrasena"];
  $usuario = $_GET["usuario"];

  echo $usuario;
?>