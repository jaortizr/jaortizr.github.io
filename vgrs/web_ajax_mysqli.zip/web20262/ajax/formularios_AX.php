<?php

  $contrasena = md5($_REQUEST["contrasena"]);
  $usuario = $_REQUEST["usuario"];

  /* Proceso los datos recibidos desde el frontend y preparo una respuesta en formato JSON */

  $respAX = [];
  $respAX["cod"] = 0;
  $respAX["msj"] = "OK. Tu operación se realizó correctamente";
  $respAX["icono"] = "error";
  $respAX["data"] = "$usuario - TDAW20262 - $contrasena";

  echo json_encode($respAX);

?>