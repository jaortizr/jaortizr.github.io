<?php
  header("Content-Type: application/json; charset=utf-8");

  $host = "localhost";
  $user = "root";
  $pass = "";
  $db = "web20262";

  mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

  try{
    $conn = new mysqli($host, $user, $pass, $db);
    $conn -> set_charset("utf8mb4");
  } catch(Exception $e){
    http_response_code(500);
    echo json_encode(["error" => "Error de conexión: " . $e->getMessage()]);
    exit;
  }
?>