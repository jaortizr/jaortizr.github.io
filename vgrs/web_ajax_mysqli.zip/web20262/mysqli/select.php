<?php
  include("./db.php");

  $query = "SELECT * FROM alumno";
  $resultado = $conn -> query($query);

  $alumnos = [];
  while($fila = $resultado -> fetch_assoc()){
    $alumnos[] = $fila;
  }

  echo json_encode($alumnos);
?>