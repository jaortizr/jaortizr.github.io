<?php
  include("./db.php");

  $boleta = "2026630002";
  $nombre = "Diana";
  $apellidos = "Cazadora";
  $correo = "diana@diana.com";
  $contrasena = md5("qwerty1234");
  $respuesta = [];

  $stmt = $conn -> prepare("INSERT INTO alumno VALUES(?,?,?,?,?,now())");
  $stmt -> bind_param("sssss", $boleta, $nombre, $apellidos, $correo, $contrasena);

  if($stmt -> execute()){
    $respuesta["cod"] = 1;
    $respuesta["msj"] = "Alumno agregado";
  }else{
    http_response_code(500);
    $respuesta["cod"] = 0;
    $respuesta["msj"] = "Error: $stmt -> error";
  }

  $stmt -> close();
  
  echo json_encode($respuesta);
?>