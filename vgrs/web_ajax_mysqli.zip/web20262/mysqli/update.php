<?php
  include("./db.php");

  $boleta = "2026630002";
  $correo = "diana@gmail.com";
  $respuesta = [];

  $stmt = $conn -> prepare("UPDATE alumno SET correo = ?, auditoria = now() WHERE boleta = ?");
  $stmt -> bind_param("ss", $correo, $boleta);
  
  if($stmt -> execute()){
    $respuesta["cod"] = 1;
    $respuesta["msj"] = "Se actualizó el correo del alumno";
  }else{
    http_response_code(500);
    $respuesta["cod"] = 0;
    $respuesta["msj"] = "Error: $stmt -> error";
  }

  $stmt -> close();
  echo json_encode($respuesta);
?>