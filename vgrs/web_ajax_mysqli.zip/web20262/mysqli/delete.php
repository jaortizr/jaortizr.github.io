<?php
  include("./db.php");

  $boleta = "2026630002";
  $respuesta = [];

  $stmt = $conn -> prepare("DELETE FROM alumno WHERE boleta = ?");
  $stmt -> bind_param("s", $boleta);

  if($stmt -> execute()){
    if($stmt -> affected_rows > 0){
      $respuesta["cod"] = 1;
      $respuesta["msj"] = "El registro del alumno se ha eliminado";
    }else{
      http_response_code(500);
      $respuesta["cod"] = 0;
      $respuesta["msj"] = "Error: $stmt -> error";
    }
  }

  $stmt -> close();
  echo json_encode($respuesta);
?>