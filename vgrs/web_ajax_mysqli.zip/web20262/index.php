<?php
  $nombre = "Ing. José Antonio Ortiz Ramírez";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tecnologías para el Desarrollo de Aplicaciones Web / 20262</title>
  <style>
    .row{
      width: 100%;
      clear:both;
    }
    img {
      max-width: 100%;
      height: auto;
    }

    .texto-centrado {
      text-align: center;
    }
  </style>
</head>
<body>
  
    <div class="row texto-centrado">
      <img src="./backgroundCSI.jpg">
    </div>
    <div class="row texto-centrado">
      <h2>
        <?php echo $nombre; ?>
      </h2>
    </div>

</body>
</html>