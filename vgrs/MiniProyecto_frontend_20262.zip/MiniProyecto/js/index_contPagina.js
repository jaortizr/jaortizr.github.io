let contenidosJSON = `{
  "carreras":[
    {
      "nombre":"Sistemas",
      "descripcion":"Some representative placeholder content for the three columns of text below the carousel. This is the first column."
    },
    {
      "nombre":"Inteligencia",
      "descripcion":"Another exciting bit of representative placeholder content. This time, we've moved on to the second column."
    },
    {
      "nombre":"Datos",
      "descripcion":"And lastly this, the third column of representative placeholder content."
    }
  ],
  "bienvenida":"<p>Reciban la más cordial bienvenida al espacio virtual de la <b>Escuela Superior de Cómputo</b>, una comunidad vibrante y comprometida con la excelencia, la innovación y la transformación social a través del conocimiento. Nos complace enormemente que hayas decidido explorar nuestro portal, una puerta digital diseñada para conectar a estudiantes, docentes, investigadores y a la sociedad en general con las actividades, recursos y oportunidades que definen nuestra identidad académica.</p>"
}
`;

let contenidosObj = JSON.parse(contenidosJSON);