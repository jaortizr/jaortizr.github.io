$(document).ready(()=>{
  /* ***** Sticky Chat ***** */
  $('body').stickyChat({
    phoneNumber: "1234567890", // Your country code + number (no + sign)
    message: "Necesitas ayuda? Contáctanos",
    position: "right", // or "left"
    backgroundColor: "#25D366", // Optional: button color
    defaultText: "Hola! Me pueden ayudar por favor..."
  });

  /* ***** Validación de Formulario ***** */
  let validarFormLogin = new window.JustValidate("#formContacto",{
    errorFieldCssClass:"is-invalid",
    successFieldCssClass:"is-valid"
  });
  validarFormLogin
  .addField("#correo",[
    {
      rule: 'required',
      errorMessage:"Falta tu correo"
    },
    {
      rule:"email",
      errorMessage:"Formato incorrecto"
    }
  ])
  .addField("#nombre",[
    {
      rule:"required",
      errorMessage:"Falta tu nombre"
    }
  ])
  .addField("#comentarios",[
    {
      rule:"required",
      errorMessage:"Faltan tus comentarios"
    }
  ])
  .onSuccess((event)=>{
    Swal.fire({
      title:"TDAW 2026-2",
      text:"Se ha validado correctamente el formulario.",
      icon:"success",
      didDestroy:()=>{
        window.location.href = "https://www.ipn.mx";
      }
    });
  })

  /* ***** Carga Dinamica de Contenidos desde un JSON ***** */
  let isc = document.querySelector("#isc");
  isc.append(contenidosObj.carreras[0].descripcion);
  let iia = document.querySelector("#iia");
  iia.append(contenidosObj.carreras[1].descripcion);

  /*
  let lcd = document.querySelector("#lcd");
  lcd.append(contenidosObj.carreras[2].descripcion);
  let bienvenida = document.querySelector("#bienvenida");
  bienvenida.innerHTML = contenidosObj.bienvenida;
  */

  $("#lcd").text(contenidosObj.carreras[2].descripcion);
  $("#bienvenida").html(contenidosObj.bienvenida);
});